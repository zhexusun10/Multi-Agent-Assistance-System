"""Build a frozen human-rating pool from real snapshot rows; no network or model calls.

Requires Python 3.12 and pydantic 2.x. See Coordinator/README.txt for reproduction.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import sqlite3
import sys
from collections import Counter, defaultdict

PIN = "d5af7e1b58b2e7064bf781f2a7a2eb19afc6de57"
DATASET = "G42-REL-2026-10-23-v1"
SEED = DATASET + ":pool-and-order"
SNAPSHOT_DATE = "2026-10-09"
NUS_ID = "OSM:way:54519165"
FIELDS = ["listing_id", "listing_type", "title", "property_type", "price", "currency",
          "price_type", "bedrooms", "bathrooms", "floor_area_sqft", "land_area_sqft",
          "build_year", "full_address", "district_code", "district_text", "postal_code",
          "latitude", "longitude", "nearest_mrt", "mrt_distance_m", "mrt_walking_mins",
          "url", "updated_at"]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields):
    with Path(path).open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            record = {}
            for k in fields:
                v = row.get(k)
                if isinstance(v, (list, dict)):
                    v = json.dumps(v, ensure_ascii=False, separators=(",", ":"))
                # Protect spreadsheet import without modifying the authoritative JSON.
                if isinstance(v, str) and v.startswith(("=", "+", "-", "@")):
                    v = "'" + v
                record[k] = v
            w.writerow(record)


def stable(namespace, value):
    return hashlib.sha256(f"{SEED}|{namespace}|{value}".encode()).hexdigest()


def scenarios():
    units = {"price": "SGD/month", "floor_area_sqft": "sqft", "distance": "m", "lease_months": "months"}

    def c(field, operator, value, strength="hard", weight=1, utility="threshold"):
        d = dict(field=field, operator=operator, value=value, strength=strength,
                 weight=weight, utility=utility, unit=units.get(field))
        if field == "distance":
            d.update(destination_id=NUS_ID, distance_type="straight_line")
        return d

    def rent(maximum): return c("price", "lte", maximum)
    def beds(minimum): return c("bedrooms", "gte", minimum)
    def district(value): return c("district_code", "eq", value)
    def cheap(w=1): return c("price", "lte", 20000, "soft", w, "minimize")
    def large(w=1): return c("floor_area_sqft", "gte", 0, "soft", w, "maximize")
    def size(n, w=1): return c("floor_area_sqft", "gte", n, "soft", w)
    def place(d, w=1): return c("district_code", "eq", d, "soft", w)
    def close(w=1): return c("distance", "lte", 3000, "soft", w, "proximity")
    rows = []

    def add(title, prompt, hard, soft, criteria, focus, group="primary", baseline="price", pair=None, turns=None):
        sid = f"S{len(rows)+1:02d}"
        for i, criterion in enumerate(criteria, 1):
            criterion["criterion_id"] = f"{sid}-R{i:02d}"
        rows.append(dict(scenario_id=sid, title=title, user_prompt=prompt,
                         turns=turns or [prompt], final_hard_requirements=hard,
                         preference_order=soft, evaluation_focus=focus, analysis_group=group,
                         baseline_sort=baseline, paired_scenario=pair,
                         requirements={"listing_type": "RENT", "criteria": criteria}))

    add("Budget first, with a size preference",
        "My monthly rent must be at most SGD 2,000, with at least one reported bedroom. Among qualifying listings, lower rent is my first priority; at least 500 sqft would be a bonus.",
        "Rent <= SGD 2,000/month; bedrooms >= 1.", "Primary: lower rent. Secondary: floor area >= 500 sqft.",
        [rent(2000), beds(1), cheap(3), size(500)], "Budget boundary and price-versus-space trade-off")
    add("An exact rent requirement",
        "For this comparison, rent must be exactly SGD 1,800 per month, with at least one reported bedroom. Among qualifying listings, I prefer a larger floor area.",
        "Rent = SGD 1,800/month (not a ceiling); bedrooms >= 1.", "Prefer larger floor area.",
        [c("price", "eq", 1800), beds(1), large()], "Exact value versus maximum interpretation")
    add("District is a preference",
        "I need at least two reported bedrooms for no more than SGD 2,500 per month. District D05 is my first preference, but other districts are acceptable. Lower rent is my second priority.",
        "Rent <= SGD 2,500/month; bedrooms >= 2. No mandatory district.", "Primary: D05. Secondary: lower rent.",
        [rent(2500), beds(2), place("D05", 3), cheap()], "Soft location versus mandatory filtering")
    add("District is mandatory",
        "I must be in D05, with at least two reported bedrooms and rent no higher than SGD 4,000 per month. I prefer more floor area first, then lower rent.",
        "Rent <= SGD 4,000/month; bedrooms >= 2; district = D05.", "Primary: larger floor area. Secondary: lower rent.",
        [rent(4000), beds(2), district("D05"), large(3), cheap()], "Mandatory district and space trade-off")
    add("Space preference in D10",
        "I need D10, at least three reported bedrooms, and monthly rent at most SGD 6,500. I strongly prefer at least 1,500 sqft; lower rent is my secondary preference.",
        "Rent <= SGD 6,500/month; bedrooms >= 3; district = D10.", "Primary: floor area >= 1,500 sqft. Secondary: lower rent.",
        [rent(6500), beds(3), district("D10"), size(1500, 3), cheap()], "Large-area preference with missing-size evidence")
    add("Exactly two bedrooms in two districts",
        "I want exactly two reported bedrooms, rent up to SGD 5,000 per month, and either D09 or D10. I prefer a condominium first and a larger floor area second.",
        "Rent <= SGD 5,000/month; bedrooms = 2; district in {D09, D10}.", "Primary: Condominium. Secondary: larger floor area.",
        [rent(5000), c("bedrooms", "eq", 2), c("district_code", "in", ["D09", "D10"]), c("property_type", "eq", "Condominium", "soft", 3), large()], "Exact bedroom count and district union")
    add("HDB is mandatory, D18 is preferred",
        "Only HDB flats are acceptable. I need at least two reported bedrooms for up to SGD 3,500 per month. I prefer D18 first, then lower rent.",
        "Rent <= SGD 3,500/month; bedrooms >= 2; property type = HDB Flat.", "Primary: D18. Secondary: lower rent.",
        [rent(3500), beds(2), c("property_type", "eq", "HDB Flat"), place("D18", 3), cheap()], "Mandatory property type versus location preference")
    add("One-bedroom apartment or condominium",
        "I need exactly one reported bedroom in an apartment or condominium, at no more than SGD 3,000 per month. D03 or D05 is my first preference; at least 500 sqft is my second preference.",
        "Rent <= SGD 3,000/month; bedrooms = 1; type in {Apartment, Condominium}.", "Primary: district in {D03, D05}. Secondary: floor area >= 500 sqft.",
        [rent(3000), c("bedrooms", "eq", 1), c("property_type", "in", ["Apartment", "Condominium"]), c("district_code", "in", ["D03", "D05"], "soft", 3), size(500)], "Property-type union and preferred district union")
    add("A minimum floor area is mandatory",
        "I need at least three reported bedrooms and at least 1,000 sqft, with monthly rent at most SGD 4,500. I prefer D18 first, then lower rent.",
        "Rent <= SGD 4,500/month; bedrooms >= 3; floor area >= 1,000 sqft.", "Primary: D18. Secondary: lower rent.",
        [rent(4500), beds(3), c("floor_area_sqft", "gte", 1000), place("D18", 3), cheap()], "Size threshold and unknown hard attributes")
    add("Two acceptable landed property types",
        "I need a terraced house or a semi-detached house, at least three reported bedrooms, and monthly rent no higher than SGD 7,000. I prefer more floor area first, then lower rent.",
        "Rent <= SGD 7,000/month; bedrooms >= 3; type in {Terraced House, Semi-Detached House}.", "Primary: larger floor area. Secondary: lower rent.",
        [rent(7000), beds(3), c("property_type", "in", ["Terraced House", "Semi-Detached House"]), large(3), cheap()], "Landed-type matching and measured floor area")
    add("A strict NUS distance limit",
        "I need at least one reported bedroom for up to SGD 3,500 per month, within 3,000 metres straight-line distance of the supplied NUS reference point. Among qualifying listings, I prefer closer to that point first, then lower rent.",
        "Rent <= SGD 3,500/month; bedrooms >= 1; NUS straight-line distance <= 3,000 m.", "Primary: closer to the NUS reference point. Secondary: lower rent.",
        [rent(3500), beds(1), c("distance", "lte", 3000), close(3), cheap()], "Geographic hard limit and missing coordinates", baseline="distance")
    add("A wider NUS radius with more space",
        "I need at least two reported bedrooms, rent up to SGD 4,500 per month, and a location within 5,000 metres straight-line distance of the supplied NUS reference point. I prefer at least 900 sqft first, then lower rent.",
        "Rent <= SGD 4,500/month; bedrooms >= 2; NUS straight-line distance <= 5,000 m.", "Primary: floor area >= 900 sqft. Secondary: lower rent.",
        [rent(4500), beds(2), c("distance", "lte", 5000), size(900, 3), cheap()], "Distance eligibility combined with size preference", baseline="distance")
    add("Closer to NUS matters more",
        "I need at least one reported bedroom for up to SGD 3,000 per month. There is no mandatory distance limit. Being closer to the supplied NUS reference point matters more to me than saving rent, although lower rent is still desirable.",
        "Rent <= SGD 3,000/month; bedrooms >= 1. No mandatory distance or district.", "Primary: closer to NUS (straight-line). Secondary: lower rent.",
        [rent(3000), beds(1), close(3), cheap()], "Paired priority reversal: proximity first", baseline="distance", pair="S14")
    add("Lower rent matters more",
        "I need at least one reported bedroom for up to SGD 3,000 per month. There is no mandatory distance limit. Saving rent matters more to me than proximity to the supplied NUS reference point, although closer is still desirable.",
        "Rent <= SGD 3,000/month; bedrooms >= 1. No mandatory distance or district.", "Primary: lower rent. Secondary: closer to NUS (straight-line).",
        [rent(3000), beds(1), cheap(3), close()], "Paired priority reversal: price first", pair="S13")
    add("D05 matters more than extra space",
        "I need at least two reported bedrooms for up to SGD 5,000 per month. I prefer D05 more strongly than having at least 1,000 sqft. Both are preferences, so neither should exclude an otherwise qualifying listing.",
        "Rent <= SGD 5,000/month; bedrooms >= 2. District and size are not mandatory.", "Primary: D05. Secondary: floor area >= 1,000 sqft.",
        [rent(5000), beds(2), place("D05", 3), size(1000)], "Paired priority reversal: district first", pair="S16")
    add("Extra space matters more than D05",
        "I need at least two reported bedrooms for up to SGD 5,000 per month. I prefer at least 1,000 sqft more strongly than D05. Both are preferences, so neither should exclude an otherwise qualifying listing.",
        "Rent <= SGD 5,000/month; bedrooms >= 2. District and size are not mandatory.", "Primary: floor area >= 1,000 sqft. Secondary: D05.",
        [rent(5000), beds(2), size(1000, 3), place("D05")], "Paired priority reversal: space first", pair="S15")
    turns17 = ["I need D05, at least two reported bedrooms, and rent up to SGD 5,000 per month. I prefer larger floor area.", "Reduce the maximum rent to SGD 3,000 per month. Keep my district, bedroom requirement and size preference."]
    add("Lower the budget in a follow-up",
        "Turn 1: " + turns17[0] + "\nTurn 2: " + turns17[1],
        "Final: rent <= SGD 3,000/month; bedrooms >= 2; district = D05.", "Retained preference: larger floor area.",
        [rent(3000), beds(2), district("D05"), large()], "Multi-turn update preserves unchanged constraints", turns=turns17)
    turns18 = ["I need D05, at least two reported bedrooms, and rent up to SGD 3,000 per month. I prefer lower rent.", "Remove my D05 requirement. Keep my budget, bedroom requirement and preference for lower rent."]
    add("Remove the district in a follow-up",
        "Turn 1: " + turns18[0] + "\nTurn 2: " + turns18[1],
        "Final: rent <= SGD 3,000/month; bedrooms >= 2. No mandatory or preferred district.", "Retained preference: lower rent. Do not retain D05 as a preference.",
        [rent(3000), beds(2), cheap()], "Multi-turn removal does not silently become a soft preference", turns=turns18)
    add("Evidence missing for mandatory features",
        "I need at least two reported bedrooms for up to SGD 3,500 per month. The property must be fully furnished and available on a six-month lease. Lower rent is a preference.",
        "Rent <= SGD 3,500/month; bedrooms >= 2; fully furnished; lease duration = 6 months.", "Prefer lower rent, only after all mandatory requirements are verified.",
        [rent(3500), beds(2), c("furnishing", "eq", "fully furnished"), c("lease_months", "eq", 6), cheap()], "Unsupported mandatory evidence control", group="evidence_control")
    add("No verified match under tight limits",
        "I need D10, at least four reported bedrooms and at least 1,500 sqft, for no more than SGD 800 per month. Keep every requirement; do not relax them silently.",
        "Rent <= SGD 800/month; bedrooms >= 4; floor area >= 1,500 sqft; district = D10.", "No additional soft preferences. Keep all mandatory requirements.",
        [rent(800), beds(4), c("floor_area_sqft", "gte", 1500), district("D10")], "Empty eligible set and transparent abstention control", group="no_verified_match_control")
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True, help="Source export or checkout at the pinned commit")
    p.add_argument("--database", type=Path, required=True, help="Unmodified propertyguru SQLite snapshot")
    p.add_argument("--output", type=Path, required=True, help="Package directory containing Coordinator/Source_Manifest.json")
    args = p.parse_args()
    coord = args.output / "Coordinator"
    coord.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((coord / "Source_Manifest.json").read_text())
    assert manifest["source_commit"] == PIN
    assert sha(args.database) == manifest["sqlite_sha256"], "SQLite snapshot hash differs"
    for rel, record in manifest["source_files"].items():
        assert sha(args.source / rel) == record["sha256"], f"Pinned source differs: {rel}"
    sys.path.insert(0, str(args.source.resolve()))
    from recommendation.repositories.listing_repository import normalize
    from recommendation.contracts.requirements import Requirements
    from recommendation.contracts.evidence import Evidence
    from recommendation.validation.rules import evaluate
    from recommendation.ranking.ranker import score
    from recommendation.config import ScoringPolicy

    conn = sqlite3.connect(args.database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    raw = [dict(r) for r in conn.execute("SELECT " + ",".join(FIELDS) + " FROM properties WHERE listing_type='RENT' ORDER BY listing_id")]
    conn.close()
    assert len(raw) == 21431
    raw_by_id = {str(r["listing_id"]): r for r in raw}
    canonical = {i: normalize(r, "sqlite:properties:snapshot-2026-10-09") for i, r in raw_by_id.items()}
    places = json.loads((args.source / "data/datasets/singapore_places.json").read_text())
    place_rows = places["places"]
    nus = next(x for x in place_rows if x["place_id"] == NUS_ID)
    assert nus["coordinate_status"] == "valid"

    def distance(r):
        if r.latitude is None or r.longitude is None:
            return None
        la, lb = math.radians(r.latitude), math.radians(nus["latitude"])
        dl = math.radians(nus["longitude"] - r.longitude)
        a = math.sin((lb-la)/2)**2 + math.cos(la)*math.cos(lb)*math.sin(dl/2)**2
        return 6371008.8 * 2 * math.asin(math.sqrt(min(1, max(0, a))))

    distances = {i: distance(r) for i, r in canonical.items()}
    ss = scenarios()
    native_policy = ScoringPolicy()
    all_results = {}
    references = {}
    full_counts = {}
    criteria_by_id = {}
    for s in ss:
        sid = s["scenario_id"]
        req = Requirements.model_validate(s["requirements"])
        s["requirements"] = req.model_dump(mode="json")
        criteria_by_id[sid] = req.criteria
        results = {}
        for i, listing in canonical.items():
            evidence = [Evidence(evidence_id=f"geo:{i}:{c.criterion_id}", listing_id=i,
                       criterion_id=c.criterion_id, source="frozen coordinates; derived haversine",
                       observed_at=SNAPSHOT_DATE, value=distances[i], unit="m", distance_type="straight_line",
                       method="haversine; Earth radius 6371008.8 m; OSM campus bbox centre",
                       destination_id=NUS_ID, mapping_status="known" if distances[i] is not None else "missing",
                       unknown_reason=None if distances[i] is not None else "Listing coordinates unavailable",
                       snapshot_hash=manifest["sqlite_sha256"]) for c in req.criteria if c.field == "distance"]
            rule_results = evaluate(listing, req.criteria, evidence)
            hard_ids = {c.criterion_id for c in req.criteria if c.strength == "hard"}
            failures = [r.criterion_id for r in rule_results if r.criterion_id in hard_ids and r.outcome == "fail"]
            unknowns = [r.criterion_id for r in rule_results if r.criterion_id in hard_ids and r.outcome in ("unknown", "unsupported")]
            state = "known_hard_failure" if failures else ("hard_evidence_unknown" if unknowns else "hard_qualified")
            results[i] = dict(hard_state=state, failed_criteria=failures, unknown_hard_criteria=unknowns,
                              criterion_results=[r.model_dump() for r in rule_results])
            if state == "hard_qualified":
                breakdown = score(listing, req.criteria, evidence, [], policy=native_policy)
                results[i].update(reference_score=breakdown.combined_score, soft_evidence_coverage=breakdown.evidence_coverage)
        eligible = [i for i, r in results.items() if r["hard_state"] == "hard_qualified"]
        native = sorted(eligible, key=lambda i: (-results[i]["reference_score"], i))
        baseline = sorted(eligible, key=lambda i: ((distances[i] if distances[i] is not None else math.inf) if s["baseline_sort"] == "distance" else canonical[i].price, i))
        for rank, i in enumerate(native, 1):
            results[i]["reference_rank"] = rank
        for rank, i in enumerate(baseline, 1):
            results[i]["baseline_rank"] = rank
        references[sid] = {"native_top4": native[:4], "baseline_top4": baseline[:4], "baseline_sort": s["baseline_sort"]}
        full_counts[sid] = dict(Counter(r["hard_state"] for r in results.values()))
        all_results[sid] = results
        print(sid, s["title"], full_counts[sid], flush=True)
    assert full_counts["S20"].get("hard_qualified", 0) == 0
    assert full_counts["S19"].get("hard_qualified", 0) == 0

    def severity(sid, i):
        """Sampling distance to a hard boundary, never a human relevance label."""
        r = all_results[sid][i]
        total = 0
        for c in criteria_by_id[sid]:
            if c.criterion_id not in r["failed_criteria"]:
                continue
            v = distances[i] if c.field == "distance" else getattr(canonical[i], c.field, None)
            if isinstance(c.value, (int, float)) and isinstance(v, (int, float)):
                total += abs(v-c.value) / max(c.value, 1)
            else:
                total += 1
        return len(r["failed_criteria"]), total, len(r["unknown_hard_criteria"]), stable(sid+":near", i)

    pools, origins = {}, {}
    for s in ss:
        sid = s["scenario_id"]
        if sid in pools:
            continue
        group = [sid, s["paired_scenario"]] if s["paired_scenario"] else [sid]
        result = all_results[sid]
        qualified = [i for i, r in result.items() if r["hard_state"] == "hard_qualified"]
        unknown = [i for i, r in result.items() if r["hard_state"] == "hard_evidence_unknown"]
        failed = [i for i, r in result.items() if r["hard_state"] == "known_hard_failure"]
        selected = []
        why = defaultdict(list)

        def take(items, number, reason):
            n = 0
            for i in items:
                if i not in selected:
                    if n >= number:
                        break
                    selected.append(i)
                    n += 1
                    why[i].append(reason)
            return n

        for gs in group:
            for role in ("native_top4", "baseline_top4"):
                for i in references[gs][role]:
                    if i not in selected:
                        selected.append(i)
                    why[i].append(gs + ":" + role)
        n_unknown = min(3, len(unknown)) if qualified else (min(20, len(unknown)) if s["analysis_group"] == "evidence_control" else 0)
        n_failed = 5 if qualified or n_unknown else 25
        n_qualified = 25 - n_unknown - n_failed
        assert len(selected) <= n_qualified, (sid, len(selected), n_qualified)
        # Stratify variety across available policy-score bins to avoid a top-score-only pool.
        buckets = defaultdict(list)
        for i in qualified:
            buckets[min(4, int(result[i]["reference_score"] * 5))].append(i)
        for b in buckets:
            buckets[b].sort(key=lambda i: stable(sid + ":qualified", i))
        mixed = []
        while any(buckets.values()):
            for b in sorted(buckets):
                if buckets[b]:
                    mixed.append(buckets[b].pop())
        take(mixed, max(0, n_qualified - len(selected)), "qualified_score_strata")
        take(sorted(unknown, key=lambda i: (len(result[i]["unknown_hard_criteria"]), stable(sid+":unknown", i))), n_unknown, "missing_hard_evidence")
        # Cover distinct failure criteria before filling the nearest-boundary candidates.
        failures_by_first = defaultdict(list)
        for i in failed:
            failures_by_first[result[i]["failed_criteria"][0]].append(i)
        for values in failures_by_first.values():
            values.sort(key=lambda i: severity(sid, i), reverse=True)
        near = []
        while any(failures_by_first.values()):
            for field in sorted(failures_by_first):
                if failures_by_first[field]:
                    near.append(failures_by_first[field].pop())
        take(near, n_failed, "near_miss_hard_failure")
        if len(selected) < 25:
            take(near, 25-len(selected), "additional_near_misses_for_sparse_qualified_set")
        if len(selected) < 25:
            take(sorted(qualified + unknown, key=lambda i: stable(sid+":fill", i)), 25-len(selected), "deterministic_shortfall_fill")
        assert len(selected) == 25 and len(set(selected)) == 25
        for gs in group:
            assert all(i in selected for i in references[gs]["native_top4"] + references[gs]["baseline_top4"])
            pools[gs] = sorted(selected, key=lambda i: stable(gs+":review-order", i))
            origins[gs] = dict(why)

    unique_ids = sorted({i for values in pools.values() for i in values})
    def present(v): return "Unknown" if v is None else f"{v:,.2f}".rstrip("0").rstrip(".")
    facts = []
    for i in unique_ids:
        r, src = canonical[i], raw_by_id[i]
        bath = src["bathrooms"]
        if bath is not None and (not isinstance(bath, (int, float)) or not math.isfinite(bath) or bath < 0):
            bath = None
        notes = list(r.normalization_warnings)
        if r.floor_area_sqft is None: notes.append("Floor area unavailable")
        if distances[i] is None: notes.append("Coordinates unavailable; NUS distance unknown")
        assert src["url"] and "propertyguru.com.sg/" in src["url"]
        summary = (f"{src['title']} | ID {i}\n"
                   f"SGD {present(r.price)}/month | Beds: {present(r.bedrooms)} | Baths: {present(bath)}\n"
                   f"Area: {present(r.floor_area_sqft)} sqft | {src['property_type']} | {r.district_code}\n"
                   f"NUS straight-line: {present(distances[i])} m")
        facts.append(dict(listing_id=i, title=src["title"], rent_sgd_month=r.price,
                          bedrooms=r.bedrooms, bathrooms=bath, floor_area_sqft=r.floor_area_sqft,
                          property_type=src["property_type"], district_code=r.district_code,
                          address=src["full_address"], latitude=r.latitude, longitude=r.longitude,
                          nus_straight_line_m=distances[i], source_url=src["url"], snapshot_date=SNAPSHOT_DATE,
                          source_updated_at=src["updated_at"], evidence_notes="; ".join(notes) or "No normalization warning",
                          furnishing="Unknown - not evidenced in this assessment", lease_months=None,
                          candidate_summary=summary))
    facts_by_id = {r["listing_id"]: r for r in facts}
    tasks, provenance = [], []
    for s in ss:
        sid = s["scenario_id"]
        for j, i in enumerate(pools[sid], 1):
            tid = f"{sid}-C{j:02d}"
            task = dict(task_id=tid, scenario_id=sid, candidate_position=j, listing_id=i,
                        candidate_summary=facts_by_id[i]["candidate_summary"], grade="", rationale="", evidence_gap="")
            tasks.append(task)
            provenance.append(dict(task_id=tid, scenario_id=sid, listing_id=i,
                                   selection_origins=origins[sid][i], **all_results[sid][i]))
    assert len(tasks) == 500 and len({t["task_id"] for t in tasks}) == 500
    assert set(pools["S13"]) == set(pools["S14"])
    assert set(pools["S15"]) == set(pools["S16"])
    assert all(not t[k] for t in tasks for k in ("grade", "rationale", "evidence_gap"))
    assert all(i in raw_by_id for i in unique_ids)
    assert all(sum(full_counts[s["scenario_id"]].values()) == 21431 for s in ss)

    # Separate reviewer-facing inputs from coordinator-only rule-derived metadata.
    safe_scenarios = [{k: s[k] for k in ("scenario_id", "title", "user_prompt", "turns", "final_hard_requirements", "preference_order")} for s in ss]
    reviewer_data = dict(dataset_id=DATASET, source_commit=PIN, snapshot_date=SNAPSHOT_DATE,
                         scenario_count=20, candidate_count_per_scenario=25, task_count=500,
                         unique_listing_count=len(unique_ids), scenarios=safe_scenarios, tasks=tasks, listing_evidence=facts)
    dump(coord / "Reviewer_Input.json", reviewer_data)
    dump(coord / "Scenarios.json", dict(dataset_id=DATASET, scenarios=ss))
    dump(coord / "Selection_Provenance.json", dict(dataset_id=DATASET, entries=provenance))
    dump(coord / "Candidate_Pools.json", dict(dataset_id=DATASET, pools=pools))
    dump(coord / "Selected_Source_Rows.json", [raw_by_id[i] for i in unique_ids])
    write_csv(coord / "Scenarios.csv", ss, ["scenario_id", "title", "user_prompt", "final_hard_requirements", "preference_order", "evaluation_focus", "analysis_group", "paired_scenario"])
    write_csv(coord / "Candidate_Pools.csv", tasks, list(tasks[0]))
    write_csv(coord / "Listing_Evidence.csv", facts, [k for k in facts[0] if k != "candidate_summary"])
    write_csv(coord / "Selection_Provenance.csv", provenance, ["task_id", "scenario_id", "listing_id", "selection_origins", "hard_state", "failed_criteria", "unknown_hard_criteria", "reference_score", "reference_rank", "baseline_rank", "soft_evidence_coverage"])
    judgments = [dict(task_id=t["task_id"], scenario_id=t["scenario_id"], listing_id=t["listing_id"], reviewer_1_grade="", reviewer_1_rationale="", reviewer_2_grade="", reviewer_2_rationale="", final_grade="", adjudication_reason="") for t in tasks]
    write_csv(coord / "Adjudication_Template.csv", judgments, list(judgments[0]))
    selected_counts = {sid: dict(Counter(all_results[sid][i]["hard_state"] for i in ids)) for sid, ids in pools.items()}
    validation = dict(dataset_id=DATASET, source_commit=PIN, scenario_count=20, tasks=500,
                      candidates_per_scenario=25, unique_listing_ids=len(unique_ids),
                      all_listing_ids_verified=True, all_per_scenario_ids_unique=True,
                      all_top4_reference_and_baseline_ids_in_pool=True, paired_candidate_sets_identical=True,
                      human_judgments_collected=0, real_model_calls=0, rule_metadata_is_not_ground_truth=True,
                      sqlite_hash_verified=True, pinned_source_files_verified=True,
                      full_snapshot_counts=full_counts, selected_counts=selected_counts,
                      reference_lists=references,
                      cjk_source_title_count=sum(any('\u4e00' <= ch <= '\u9fff' for ch in f["title"]) for f in facts))
    dump(coord / "Dataset_Validation.json", validation)
    manifest.update(selection_seed=SEED, source_population=21431, scenario_count=20,
                    candidate_count_per_scenario=25, task_count=500, unique_selected_listings=len(unique_ids),
                    priority_mapping="Primary soft criterion weight 3, secondary weight 1; single preference weight 1. Sampling reference only.",
                    native_scoring_policy=native_policy.model_dump(mode="json"), native_viewed_history=[],
                    native_reference_scope="Direct normalize/evaluate/score on supplied canonical requirements. Not an end-to-end application or model run.",
                    rating_unit="scenario-listing pair; IDs unique within scenario, may recur across scenarios",
                    geography=dict(destination=nus, formula="haversine", earth_radius_m=6371008.8,
                                   distance_type="straight_line", route_or_gate_distance=False),
                    dataset_status="Ready for independent annotation; no human labels or recommendation-quality metrics yet")
    dump(coord / "Source_Manifest.json", manifest)
    print(json.dumps({"tasks": 500, "unique_listings": len(unique_ids), "selected_counts": selected_counts,
                      "cjk_titles": validation["cjk_source_title_count"]}, indent=2))


if __name__ == "__main__":
    main()
