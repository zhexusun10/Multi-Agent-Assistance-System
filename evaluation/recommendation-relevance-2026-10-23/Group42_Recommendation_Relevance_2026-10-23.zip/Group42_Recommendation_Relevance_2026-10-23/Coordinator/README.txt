COORDINATOR NOTES - G42-REL-2026-10-23-v1

1. PURPOSE AND BOUNDARY

Prepare an independently judged relevance benchmark from the real frozen rental
snapshot. This package completes scenario definition and candidate/form creation.
It is not a completed recommendation-quality experiment or final UAT sign-off.
Human grade columns are blank. No model provider or network service is used by
the selection script.

The repository's normalize(), evaluate() and score() functions are loaded directly
from source pinned at d5af7e1b58b2e7064bf781f2a7a2eb19afc6de57. This is an offline
reference calculation on supplied structured requirements. It does not exercise
natural-language intake, orchestration, SQL service wiring, Neo4j, the browser,
model explanations or the complete application pipeline.

2. FILE MAP

Scenarios.json             Canonical criteria, English prompts and conversation turns.
Scenarios.csv              Readable flat scenario inventory.
Candidate_Pools.json       Exact ordered listing IDs for each of the 20 scenarios.
Candidate_Pools.csv        Flat 500-task pool with blank human-label fields.
Listing_Evidence.csv       Typed source facts for 387 distinct selected listing IDs.
Reviewer_Input.json        Reviewer-safe facts/tasks used to build the workbook.
Selected_Source_Rows.json  Allowlisted source rows before normalization, no contacts.
Selection_Provenance.json  Criterion outcomes and sampling origins, coordinator only.
Selection_Provenance.csv   Compact coordinator view of selection and reference ranks.
Source_Manifest.json       Commit, snapshot/source hashes, seed, policy and NUS anchor.
Dataset_Validation.json    Population counts, pool checks and frozen reference top 4.
Workbook_Validation.json   Grade/progress state checks before export; inputs restored.
Guide_Validation.json      PDF page/text checks and visual review record.
Package_Validation.json    Final independent checks across data, XLSX and package.
Adjudication_Template.csv  Blank independent-review/final-label comparison template.
select_candidates.py      Deterministic, offline pool reproduction script.

CSV is supplied for spreadsheet/data-tool use; JSON preserves types, nested
criteria and exact facts. These are alternate representations of the same frozen
dataset, not separate test runs. JSON is authoritative where CSV display differs.
Original source rows may retain original-language proper names in source metadata.

3. SCENARIO DESIGN

S01-S10: price ceiling/exact price, bedroom count, district hard/soft distinctions,
property-type unions, minimum area and price-versus-space preferences.
S11-S12: hard NUS straight-line distance with additional stated preferences.
S13-S14: same candidate membership; reverse proximity-versus-price priority.
S15-S16: same candidate membership; reverse district-versus-space priority.
S17: lower a rent cap while retaining the other requirements in a second turn.
S18: explicitly remove D05; do not retain it as a soft preference.
S19: missing evidence for mandatory furnishing and six-month lease terms.
S20: tight conditions with no verified eligible candidate in the full snapshot.

S01-S18 form the proposed primary relevance group. S19-S20 are uncertainty and
no-match controls and must be reported separately. These 20 cases provide diverse
coverage; they are not a probabilistic sample of user demand. Paired scenarios
and repeated listings are dependent observations; do not treat 500 tasks as 500
independent users when estimating confidence intervals or generalizing results.

4. DETERMINISTIC SELECTION

Population: all 21,431 rows with listing_type='RENT', ordered by listing_id.
The SQLite connection is read-only and immutable. Both the source SQLite SHA256
and every exported source-file hash are verified before candidate selection.

Each row is normalized using the pinned production function. The native rule
evaluator derives one of three sampling states, with failure taking precedence:
- known_hard_failure: at least one hard condition is known to fail;
- hard_evidence_unknown: no known hard failure, but unknown/unsupported hard evidence;
- hard_qualified: every hard condition is verified by the supplied snapshot evidence.
These are rule-derived states, not the human relevance labels 0-3/U.

For hard-qualified rows, a reference rank is calculated with the pinned weighted-v1
policy and no viewed-history input. Primary soft criteria receive weight 3 and
secondary criteria weight 1; a single preference receives weight 1. This is the
benchmark's declared canonical encoding for sampling, not an observed LLM output
or a rule that reviewers must reproduce. Native numeric scaling is kept intact.

The candidate pool includes the native-policy reference top 4 and a simple baseline
top 4 (lowest price, or closest straight-line distance for designated geographic
scenarios), then fills with hard-qualified score-stratum variety, unknown-hard
cases and near misses. IDs are de-duplicated within every scenario. A hash seed
chooses variety and independently shuffles reviewer order.

Deduplication is by source listing ID. Separate advertisements may describe the
same physical unit, and project/address identity alone cannot establish that.
Do not describe the 387 distinct listing IDs as 387 independently verified units.

Typical pool composition is 17 hard-qualified + 3 hard-unknown + 5 known failures.
Documented source-driven exceptions:
- S02: 16 qualified + 3 unknown + 6 failures (only 16 qualified in the population).
- S09: 19 qualified + 1 unknown + 5 failures (only 1 hard-unknown in the population).
- S17: 3 qualified + 3 unknown + 19 failures (only 3 qualified in the population).
- S19: 20 hard-unknown + 5 known failures; no hard-qualified candidate.
- S20: 25 known failures; all 21,431 source rows have a known hard failure.

For paired scenarios, both reference and baseline top-4 lists are pooled together
before filling to 25. Membership is identical within a pair; display order differs.
Extra slots when a qualified set is sparse use additional near misses. Failure
sampling rotates among first-failed criterion groups, then orders by failure count
and normalized distance from the hard boundary, with deterministic tie-breaking.

The pool deliberately mixes plausible matches, failures and incomplete evidence.
Do not present its label frequencies as market prevalence. Reference top-4 inclusion
reduces unjudged results for the offline reference; it does not guarantee that a
later end-to-end system will return only these IDs. Supplement and version any
out-of-pool judgments before scoring such a run.

5. SOURCE AND GEOGRAPHIC LIMITS

The source ZIP is the same Git blob as the pinned repository snapshot. Its extracted
SQLite database SHA256 is verified. The 1 GB database and 67 MB ZIP are not duplicated
inside this small review package. Selected source fields retain the original values;
negative/invalid normalized fields are clearly marked unknown for reviewers.

NUS anchor: OSM:way:54519165, latitude 1.29628285, longitude 103.77731155.
Source: data/datasets/singapore_places.json at the same commit.
Method: haversine, Earth radius 6,371,008.8 m, to the campus bounding-box centre.
Attribution: OpenStreetMap contributors, ODbL 1.0.
No street routing, gate location, journey time or updated geocoding is inferred.
These computed coordinate distances are new derived evidence, not a claim that
every listing-to-NUS edge already exists in the project's graph database.

Source facts are reported claims, not a property inspection. Bedroom and property
type fields do not establish room-versus-whole-unit availability, exclusive use,
tenancy permissions, furnishing, lease duration or present vacancy. Do not silently
repair suspicious records by inventing values. Log discrepancies and issue a new
version if evidence needs correction.

6. ANNOTATION AND METRIC HANDOFF

Distribute only Reviewer/ to independent raters. Use separate copies so one rater
cannot see another's work. Adjudicate disagreements after both submissions are
locked, preserving original grades and recording the final reason. Do not convert
U to 0. Rationale is required for every label; U also requires an evidence gap.

The PDF predeclares a proposed cutoff of grade >=2 for Precision/Recall and gain
2^grade-1 for NDCG, at K=1,3,4. Metrics require final human labels and observed ranked
outputs. Unknown/unjudged top-K items invalidate that scenario/K metric rather than
becoming negatives; retain positions and report coverage. Recall and the NDCG ideal
are restricted to the numerically judged pool, not the full source database.
Apply no unagreed quality threshold and claim no new metric result from this pack.

7. REPRODUCE THE POOL

Use Python 3.12 with pydantic 2.x (prepared with 2.14.1). Obtain a checkout at:
  d5af7e1b58b2e7064bf781f2a7a2eb19afc6de57
Extract the SQLite database from data/snapshots/propertyguru-2026-10-09.zip and
verify it against Source_Manifest.json. The script checks the hashes itself.
Create a new output directory with a Coordinator subdirectory, and copy the
original Source_Manifest.json into it. Run with your own absolute paths:

  python3 select_candidates.py --source /absolute/path/to/pinned-checkout \
    --database /absolute/path/to/propertyguru.db \
    --output /absolute/path/to/new-reproduction-package

This produces the machine-readable pool and validation files, not a second human
rating exercise. Candidate_Pools.json, Reviewer_Input.json, Scenarios.json and
Selection_Provenance.json should reproduce byte-for-byte under the same dependency
version. No paid API key is required. The original frozen package should not be
used as the reproduction output directory after annotation has begun.

8. RELEASE STATUS

Local preparation complete; ready for independent annotation. Human labels pending.
No new project acceptance sign-off, model run, GitHub push or PR update is included.
Use the package SHA256SUMS.txt to detect changes before distributing reviewer copies.
