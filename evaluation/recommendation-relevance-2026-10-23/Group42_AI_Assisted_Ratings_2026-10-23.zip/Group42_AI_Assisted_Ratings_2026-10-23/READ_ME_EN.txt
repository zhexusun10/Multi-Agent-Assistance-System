GROUP 42 - AI-ASSISTED RELEVANCE SCORING
Assessment: G42-REL-AI-2026-10-23-v1
Status: AI first pass complete; human review and adjudication pending.

500 scenario-listing tasks have been scored, with an English rationale for every
task. U rows identify the missing mandatory evidence. Grade counts:
  0: 135   1: 149   2: 74   3: 70   U: 72
These are labels for a deliberately mixed candidate pool, not a system pass rate.
No new recommendation run or Precision/Recall/NDCG result is claimed.

ASSESSOR AND METHOD
One AI-assisted assessor (AI-01), the current assistant, prepared this first pass.
The same assistant helped design the benchmark and already knows the project.
Therefore these labels are provisional assistance, not independent gold labels.
No external model API was called and no human reviewer was impersonated.
Do not describe this file as two independent ratings, participant feedback, or
completed human UAT.

Hard conditions were transcribed from the English reviewer scenarios and checked
against frozen reviewer facts, with known failure preceding unknown evidence.
The 135 grade-0 labels and 72 U labels follow those checks.
The remaining 293 preference grades were explicitly assigned by the assistant
after viewing all hard-qualified candidates, not copied from recommender scores.
The production ranker, its weights, reference ranks and sampling provenance were
not loaded or used by the rating scripts. The original qualitative rubric is kept:
primary preferences matter more, small soft-condition trade-offs can receive 2,
hard conditions are never relaxed, and no fixed grade distribution is imposed.
Reported attribute values remain unchanged.

SCORING CHOICES TO REVIEW
- Unmet primary categorical preferences generally receive 1 despite eligibility.
  S03 has no qualifying D05 candidate in its supplied pool; its eligible options
  therefore have weak primary preference fit. Do not manufacture grade-2 labels
  just to obtain a nonzero recall denominator.
- Small shortfalls in a numeric soft preference can receive 2 when the overall
  evidence supports a useful trade-off; this does not turn a soft target into a
  mandatory rule. The per-row reasons expose these judgments for revision.
- S17 has only three qualified candidates with 699-721 sqft. All receive 3 because
  the small size differences do not justify forcing artificial grade separation.
- Missing soft evidence does not automatically require U. No unverified benefit
  is awarded. Missing mandatory evidence does require U unless a hard failure
  already supports 0.
- Source facts are reported listing claims. Scores are conditional on those
  claims, not on verified whole-unit availability, current vacancy or an inspection.

DATA REVIEW ITEMS
26 task rows (9 distinct listing IDs) have explicit source-review flags:
reported floor area below 50 sqft; at least two reported bedrooms with floor area
below 200 sqft; or HDB floor area above 5,000 sqft. These are transparent review
triggers, not proof of a data error. They do not automatically alter source data
or grade values. Check the listing scope and units before relying on these labels.
The focused review queue has 142 rows covering mandatory unknowns,
missing relevant soft evidence and these source-review flags.

HOW TO USE THE FILES
1. Open the AI-scored workbook. The existing four tabs, 500 task identities,
   candidate order and source evidence are preserved. Progress means the AI entry
   is filled, not that a person has approved it.
2. Use Human_Review_Queue.csv for focused verification and
   Human_Verification_Template.csv for a human decision on any of the 500 rows.
   Human grade, reviewer identity and reviewed-date fields remain blank.
3. If two independent human ratings are required, give reviewers the original
   blank workbook and original guide before showing them the AI labels. The
   original unscored package is unchanged. A person editing this AI-scored copy
   provides an informed verification, not a blinded independent assessment.
4. Preserve original AI labels when recording later human corrections. Keep
   task ID, scenario ID and listing ID together. Obtain new evidence or retain U;
   do not convert missing evidence to a negative label.

FILES
Group42_AI_Assisted_Scoring_EN.xlsx: the completed English AI first-pass form.
AI_Ratings.csv / .json: per-task grades, reasons, evidence gaps and provenance.
Scenario_Summary.csv: counts by scenario, with zero completed human reviews.
Scoring_Audit.json: independently calculated hard checks and explicit AI decisions.
Human_Review_Queue.csv: focused evidence-verification queue.
Human_Verification_Template.csv: blank human verification fields for all 500 tasks.
Validation.json: source-preservation, completeness, consistency and export checks.

METRIC STATUS
No ranked application output was collected for this scoring task. Scenarios with
no AI grade 2 or 3 are S03, S19, S20. Their judged-pool recall denominator
is zero under these provisional labels; report N/A if using that definition.
Any later AI-label-based metric must be labeled as an AI-assisted diagnostic,
not human-validated recommendation quality. The original candidate-pool and
unknown-handling limits still apply.

FROZEN SOURCE
Main: d5af7e1b58b2e7064bf781f2a7a2eb19afc6de57
Listing snapshot: 2026-10-09.
NUS distances are straight-line distances to the frozen campus reference point.
No live property checks, paid model calls, GitHub writes or release sign-off were
performed as part of this scoring pass.
