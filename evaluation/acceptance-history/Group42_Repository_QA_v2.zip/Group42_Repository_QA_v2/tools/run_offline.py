"""Run repository checks with a clean environment. Never load .env or enable live suites."""
import argparse,subprocess,os,json,datetime,hashlib,re
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--node',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.repo=a.repo.resolve();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=True)
    env={k:os.environ[k] for k in ['SystemRoot','WINDIR','COMSPEC','PATHEXT','TEMP','TMP'] if k in os.environ}
    env.update({'PATH':str(Path(a.node).parent)+os.pathsep+os.defpath,'LLM_MODE':'rules','EXTERNAL_ACTION_MODE':'simulation'})
    results=[]
    commands=[('typecheck',[a.node,'node_modules/typescript/bin/tsc','--noEmit']),('recommendation_typecheck',[a.node,'node_modules/typescript/bin/tsc','-p','tsconfig.recommendation.json']),('typescript_tests',[a.node,'--import','tsx','--test','--test-reporter=tap',*[str(x.relative_to(a.repo)) for x in sorted((a.repo/'tests').glob('*.test.ts'))]])]
    for name,cmd in commands:
        r=subprocess.run(cmd,cwd=a.repo,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
        raw=r.stdout;(a.out/(name+'.log')).write_text(raw)
        result=dict(name=name,command=cmd,exit_code=r.returncode,passed=r.returncode==0,log=name+'.log',log_sha256=hashlib.sha256(raw.encode()).hexdigest())
        if name=='typescript_tests':
            result['counts']={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',raw,re.M)}
        results.append(result);print(json.dumps(result))
    (a.out/'offline_run.json').write_text(json.dumps(dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence_class='FRESH_OFFLINE',commit='907cfa839d2665b3702450eb40acd4c96fe9296c',source_line_endings='UTF-8 source fetched from the pinned commit, normalized to LF for local execution',environment='clean environment; rules; simulation; no credentials or LIVE flags; no .env loaded',node_version=subprocess.check_output([a.node,'--version'],text=True).strip(),results=results),indent=2))
    if not all(x['passed'] for x in results):raise SystemExit(1)
if __name__=='__main__':main()
