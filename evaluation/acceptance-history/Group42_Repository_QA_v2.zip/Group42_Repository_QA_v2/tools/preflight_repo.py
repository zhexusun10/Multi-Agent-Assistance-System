"""Read-only checks for repository paths moved from data to dataPreprocessing."""
import argparse,json,datetime,difflib
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();root=a.repo.resolve();a.out.mkdir(parents=True,exist_ok=True)
    findings=[]
    req=root/'requirements-dev.txt'
    missing=[line[3:].strip() for line in req.read_text().splitlines() if line.startswith('-r ') and not (root/line[3:].strip()).exists()]
    if missing:findings.append(dict(id='DEF01',severity='S2',status='OPEN',title='Development requirements reference moved files',files=['requirements-dev.txt'],actual='Missing include files: '+', '.join(missing),expected='All recursive requirements paths resolve from a clean checkout.',retest='Resolve requirements-dev.txt recursively, then install in a fresh disposable venv.'))
    launcher=[str(p.relative_to(root)) for p in [root/'scripts/start-app.ps1',root/'scripts/local-data.ps1'] if 'data/compose.yaml' in p.read_text() or 'data\\compose.yaml' in p.read_text()]
    if launcher and not (root/'data/compose.yaml').exists():findings.append(dict(id='DEF02',severity='S2',status='OPEN',title='Launchers reference removed compose and graph CLI paths',files=launcher,actual='data/compose.yaml is absent; canonical compose is dataPreprocessing/compose.yaml. local-data.ps1 also calls removed data/knowledge_graph.py.',expected='Fresh sample and full launch paths resolve before Docker or model operations.',retest='Validate both compose files with docker compose config, then start Sample and Full in disposable volumes. Verify import and read-only parity.'))
    entries=[str(p.relative_to(root)) for p in [root/'scripts/full_data_api.py',root/'scripts/sample_data_api.py',root/'scripts/bootstrap_sample.py',root/'dataPreprocessing/service/app.py'] if 'from data.' in p.read_text()]
    if entries and not (root/'data/service/app.py').exists():findings.append(dict(id='DEF03',severity='S2',status='OPEN',title='Data API and bootstrap import the former package namespace',files=entries,actual='Old data.core, data.service, data.graph and data.storage imports reference moved modules. Python test collection reproduces ModuleNotFoundError: data.core.',expected='Data services and bootstrap import the current dataPreprocessing package. The untouched commit collects its tests.',retest='Run pytest dataPreprocessing/tests tests/test_api.py tests/test_webhook_gateway.py in a clean test environment. Import entry points, then exercise /ready, capabilities and complete listing scans.'))
    report=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence_class='FRESH_STATIC',commit='907cfa839d2665b3702450eb40acd4c96fe9296c',method='Inspect committed file references and file existence. Launchers and Docker were not executed.',findings=findings)
    (a.out/'repository_preflight.json').write_text(json.dumps(report,indent=2))
    replacements={
        'requirements-dev.txt':[('data/graph_requirements.txt','dataPreprocessing/graph_requirements.txt'),('data/requirements.txt','dataPreprocessing/requirements.txt')],
        'scripts/start-app.ps1':[('data/compose.yaml','dataPreprocessing/compose.yaml')],
        'scripts/local-data.ps1':[('data\\compose.yaml','dataPreprocessing\\compose.yaml'),('data/graph_requirements.txt','dataPreprocessing/graph_requirements.txt'),('data/knowledge_graph.py','dataPreprocessing/knowledge_graph.py')],
        'scripts/full_data_api.py':[('from data.service.app','from dataPreprocessing.service.app')],
        'scripts/sample_data_api.py':[('from data.service.app','from dataPreprocessing.service.app')],
        'scripts/bootstrap_sample.py':[('from data.storage','from dataPreprocessing.storage'),('from data.graph','from dataPreprocessing.graph')],
        'dataPreprocessing/service/app.py':[('from data.core.contracts','from dataPreprocessing.core.contracts')],
        'README.md':[('data/compose.yaml','dataPreprocessing/compose.yaml'),('pytest data/tests','pytest dataPreprocessing/tests')],
    }
    patch=[]
    for name,pairs in replacements.items():
        with open(root/name,encoding='utf-8',newline='') as f:old=f.read()
        new=old
        for x,y in pairs:new=new.replace(x,y)
        patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
    with open(a.out/'proposed_startup_path_fix.patch','w',encoding='utf-8',newline='') as f:f.write(''.join(patch))
    print(json.dumps({'findings':len(findings),'open_S2':[f['id'] for f in findings],'patch':'proposed_startup_path_fix.patch','patch_applied':False}))
    if findings:raise SystemExit(1)
if __name__=='__main__':main()
