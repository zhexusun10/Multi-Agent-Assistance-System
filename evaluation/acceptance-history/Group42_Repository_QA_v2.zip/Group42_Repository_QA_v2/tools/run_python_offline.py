"""Run Python QA in a disposable checkout without .env or live configuration."""
import argparse,subprocess,os,datetime,json,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--python',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--variant',required=True);a=p.parse_args();root=a.repo.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    if (root/'.env').exists():raise SystemExit('Use a disposable checkout without .env. Project imports may load it automatically.')
    env={k:os.environ[k] for k in ['SystemRoot','WINDIR','COMSPEC','PATHEXT','TEMP','TMP'] if k in os.environ};env['PATH']=str(Path(a.python).resolve().parent)+os.pathsep+os.defpath
    xml=out/'python_results.xml';cmd=[a.python,'-m','pytest','dataPreprocessing/tests','tests/test_api.py','tests/test_webhook_gateway.py','-q','--junitxml='+str(xml)]
    r=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180);(out/'python_tests.log').write_text(r.stdout)
    suite=ET.parse(xml).getroot().find('testsuite');stats={k:int(suite.attrib.get(k,0)) for k in ['tests','errors','failures','skipped']}
    report=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),variant=a.variant,evidence_class='FRESH_OFFLINE',exit_code=r.returncode,counts=stats,command=cmd,log_sha256=hashlib.sha256(r.stdout.encode()).hexdigest(),environment='No .env or credentials, no live flags. Temporary SQLite and mocks only.')
    (out/'python_run.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));raise SystemExit(r.returncode)
if __name__=='__main__':main()
