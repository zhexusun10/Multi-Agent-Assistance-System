// Execute the repository's actual gateway against read-only canonical rows.
// HTTP, PostgreSQL and models are deliberately replaced by an in-memory data transport.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID,createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const args=Object.fromEntries(Array.from({length:Math.floor((process.argv.length-2)/2)},(_,i)=>[process.argv[2+i*2].slice(2),process.argv[3+i*2]]));
for(const key of ['repo','input','gold','out'])if(!args[key])throw Error('--'+key+' is required');
const repo=path.resolve(args.repo),out=path.resolve(args.out);await fs.mkdir(out,{recursive:true});
const {RecommendationGateway}=await import(pathToFileURL(path.join(repo,'src/adapters/recommendation.ts')));
const {DataHttpAdapter}=await import(pathToFileURL(path.join(repo,'src/adapters/data-http.ts')));
const {ToolExecutor}=await import(pathToFileURL(path.join(repo,'src/tools/executor.ts')));
const {recommendationRequestSchema}=await import(pathToFileURL(path.join(repo,'src/contracts/recommendation-v1.ts')));
const raw=await fs.readFile(args.input,'utf8'),rows=JSON.parse(raw),gold=JSON.parse(await fs.readFile(args.gold,'utf8'));
process.env.DATA_MODE='full';process.env.LLM_MODE='rules';process.env.EXTERNAL_ACTION_MODE='simulation';
const results=[];
const sourceIndex={};await fs.mkdir(path.join(out,'offline_sources'),{recursive:true});
for(const g of gold){
 let page=0,seq=0,pool=null;
 const save=async(ctx,body)=>{
  if(body&&typeof body==='object'&&'assessed' in body)pool=body;
  const rawBody=JSON.stringify(body),sha=createHash('sha256').update(rawBody).digest('hex'),ref='sha256:'+sha,file='offline_sources/'+sha+'.json';
  if(!sourceIndex[ref]){await fs.writeFile(path.join(out,file),rawBody);sourceIndex[ref]={file,sha256:sha,kind:body&&'assessed' in body?'complete_gateway_group_ids':'canonical_scan_page'};}
  seq++;return ref;
 };
 const adapter=new DataHttpAdapter('http://127.0.0.1:1',new ToolExecutor(),save);
 adapter.request=async(p,body)=>{
  if(p==='/api/v1/capabilities')return {canonical_assessment_scan:'/api/v1/listings/assessment/search',listing_snapshot:{expected_counts:{properties:rows.length}}};
  assert.equal(p,'/api/v1/listings/assessment/search');
  const start=page++*1000,items=rows.slice(start,start+1000).map(r=>({entity_id:'Listing:'+r.listing_id,label:'Listing',properties:r})),more=start+items.length<rows.length;
  return {items,next_cursor:more?String(page):null,has_more:more,page_size:1000,source:{store:'sqlite-readonly-memory-adapter',role:'canonical_listings'},warnings:[]};
 };
 const criteria=g.hard.map(([field,operator,value],i)=>({criterion_id:'hard-'+i,field:field==='district_code'?'district':field,operator,value,strength:'hard',...(['price','bedrooms','commute_time'].includes(field)?{unit:field==='price'?'SGD/month':field==='bedrooms'?'count':'min'}:{})}));
 if(g.case_id==='B04')criteria.push({criterion_id:'soft-bath',field:'amenities',operator:'eq',value:'private_bathroom',strength:'soft',weight:2},{criterion_id:'soft-rent',field:'price',operator:'lte',value:2500,unit:'SGD/month',strength:'soft',weight:1});
 const req=recommendationRequestSchema.parse({contract_version:'1.0',request_id:randomUUID(),conversation_id:'qa-'+g.case_id,requirements_version:1,requirements:{listing_type:'RENT',criteria},feedback:[],result_limit:5});
 const ctx={sessionId:req.conversation_id,operationId:randomUUID(),agent:'b',dataset:'2026-10-09',deadline:Date.now()+60000,calls:0};
 const started=Date.now();let result;
 try{
  const response=await new RecommendationGateway(adapter,save,'baseline',undefined).recommend(req,ctx);
  assert.deepEqual(response.state.counts,g.counts);
  assert.equal(response.state.coverage.complete_within_dataset,true);assert.equal(response.state.coverage.truncated,false);assert.equal(page,Math.ceil(rows.length/1000));
  for(const k of ['eligible','excluded','unverified'])assert.deepEqual([...pool[k]].sort(),[...g.ids[k]].sort(),k+' full ID set');
  for(const key of ['recommendations','unverified_candidates']){
   assert.deepEqual(response[key].map(c=>c.listing.listing_id),g[key].map(c=>c.listing_id));
   response[key].forEach((c,i)=>{assert(Math.abs(c.score-g[key][i].score)<1e-10);assert.equal(c.rank,i+1);});
  }
  if(g.case_id==='B07'){assert.equal(response.relaxation_suggestions[0]?.proposed_value,299);assert.equal(req.requirements.criteria[0].value,1);}
  if(g.case_id==='B05'){assert(rows.some(r=>r.price===5000));assert(pool.eligible.includes(rows.find(r=>r.price===5000).listing_id));}
  const body=JSON.stringify({request:req,response},null,2),file=g.case_id+'-response.json';await fs.writeFile(path.join(out,file),body);
  result={case_id:g.case_id,status:'PASS',counts:response.state.counts,top_ids:response.recommendations.map(c=>c.listing.listing_id),pages:page,elapsed_ms:Date.now()-started,evidence:file,evidence_sha256:createHash('sha256').update(body).digest('hex')};
 }catch(e){result={case_id:g.case_id,status:'FAIL',message:String(e),elapsed_ms:Date.now()-started};}
 results.push(result);console.log(JSON.stringify(result));
}
await fs.writeFile(path.join(out,'recommendation_oracle_run.json'),JSON.stringify({checked_at:new Date().toISOString(),commit:'907cfa839d2665b3702450eb40acd4c96fe9296c',evidence_class:'FRESH_OFFLINE',mode:'actual local baseline gateway and pagination adapter with in-memory SQLite rows; HTTP/SQL migration/Neo4j/LLM/UI not exercised',input_sha256:createHash('sha256').update(raw).digest('hex'),results},null,2));
await fs.writeFile(path.join(out,'offline_source_index.json'),JSON.stringify({scope:'Offline gateway evidence only. These content hashes resolve local data pages and complete actual classification pools, not deployed UUID evidence references.',references:sourceIndex},null,2));
if(results.some(r=>r.status!=='PASS'))process.exitCode=1;
