"""Independent, read-only SQLite audit and recommendation gold generation. Python stdlib only."""
import argparse,hashlib,json,sqlite3,zipfile,datetime,csv,shutil,math
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archive',type=Path,required=True)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--scratch',type=Path,required=True)
    a=ap.parse_args()
    for key in ['archive','repo','out','scratch']:setattr(a,key,getattr(a,key).resolve())
    a.out.mkdir(parents=True,exist_ok=True);a.scratch.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.archive) as z:
        members=[x for x in z.infolist() if x.filename.lower().endswith(('.db','.sqlite','.sqlite3')) and not x.filename.startswith('__MACOSX/')]
        if not members:raise ValueError('No SQLite database found in archive')
        member=max(members,key=lambda x:x.file_size)
        if member.file_size>4*1024**3:raise ValueError('Unexpectedly large database')
        bad=z.testzip()
        if bad:raise ValueError('Archive CRC failure '+bad)
        dbpath=a.scratch/'source_readonly.db'
        with z.open(member) as src,open(dbpath,'wb') as dst:shutil.copyfileobj(src,dst)
    db=sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
    integrity=[r[0] for r in db.execute('PRAGMA integrity_check')]
    tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    counts={t:db.execute('SELECT COUNT(*) FROM "'+t.replace('"','""')+'"').fetchone()[0] for t in tables}
    raw=[dict(r) for r in db.execute("SELECT * FROM properties WHERE UPPER(listing_type)='RENT' ORDER BY listing_id")]
    cols=[r[1] for r in db.execute('PRAGMA table_info(properties)')]
    fields=['price','currency','bedrooms','bathrooms','floor_area_sqft','district_code','postal_code','latitude','longitude','mrt_distance_m','mrt_walking_mins','build_year','raw_json']
    coverage={f:dict(present=sum(r.get(f) not in [None,''] for r in raw),missing=sum(r.get(f) in [None,''] for r in raw),negative=sum(isinstance(r.get(f),(int,float)) and r[f]<0 for r in raw)) for f in fields}
    absent=[f for f in ['amenities','private_bathroom','furnishing','rental_scope','lease_months','move_in_date','commute_time','current_availability'] if f not in cols]
    duplicate=db.execute('SELECT COUNT(*)-COUNT(DISTINCT listing_id) FROM properties').fetchone()[0]
    orphans=db.execute('SELECT COUNT(*) FROM property_images i LEFT JOIN properties p ON p.listing_id=i.listing_id WHERE p.listing_id IS NULL').fetchone()[0]
    listing_types={str(r[0]):r[1] for r in db.execute('SELECT listing_type,COUNT(*) FROM properties GROUP BY listing_type')}
    csvcounts={}
    for file in sorted((a.repo/'data/exports').glob('*.csv')):
        with open(file,encoding='utf-8-sig',newline='') as f:csvcounts[file.name]=sum(1 for _ in csv.DictReader(f))
    rows=[]
    keep=['listing_id','listing_type','currency','price','bedrooms','bathrooms','floor_area_sqft','district_code','latitude','longitude','property_type','title','url','thumbnail_url']
    for r in raw:
        p={k:r.get(k) for k in keep};p['listing_id']=str(p['listing_id']);p['listing_type']='RENT'
        for k in ['price','bedrooms','bathrooms','floor_area_sqft','latitude','longitude']:
            v=p[k];p[k]=v if isinstance(v,(int,float)) and math.isfinite(v) and v>=0 else None
        rows.append(p)
    def compare(v,op,w):
        if v is None:return 'unknown'
        return 'pass' if {'lte':lambda:v<=w,'gte':lambda:v>=w,'eq':lambda:v==w}[op]() else 'fail'
    scenarios=[('B01',[('price','lte',5000),('bedrooms','gte',2),('district_code','eq','D05')],[]),('B02',[('price','lte',3000),('amenities','eq','private_bathroom')],[]),('B03',[('price','lte',5500),('bedrooms','gte',2),('district_code','eq','D05')],[]),('B04',[('price','lte',3000)],[('amenities',2),('price',1)]),('B05',[('price','lte',5000)],[]),('B06',[('commute_time','lte',20)],[]),('B07',[('price','lte',1)],[])]
    gold=[]
    for cid,hard,soft in scenarios:
        groups={'eligible':[],'unverified':[],'excluded':[]}
        for p in rows:
            statuses=[compare(p.get(f) if f!='price' or p.get('currency')=='SGD' else None,op,w) for f,op,w in hard]
            group='excluded' if 'fail' in statuses else 'unverified' if 'unknown' in statuses else 'eligible'
            score=max(0,min(1,1-p['price']/5000))/3 if cid=='B04' and p['price'] is not None and p['currency']=='SGD' else 0
            groups[group].append(dict(listing_id=p['listing_id'],price=p['price'] if p['currency']=='SGD' else None,score=score))
        for group in groups:groups[group].sort(key=lambda p:(-p['score'],p['price'] if p['price'] is not None else float('inf'),int(p['listing_id'])))
        gold.append(dict(case_id=cid,hard=hard,soft=soft,counts=dict(assessed=len(rows),**{g:len(v) for g,v in groups.items()}),ids={g:[x['listing_id'] for x in v] for g,v in groups.items()},recommendations=groups['eligible'][:5],unverified_candidates=groups['unverified'][:5]))
    assert set(gold[0]['ids']['eligible']).issubset(gold[2]['ids']['eligible'])
    checks=[dict(check='SQLite integrity',passed=integrity==['ok']),dict(check='Unique listing IDs',passed=duplicate==0),dict(check='No orphan media',passed=orphans==0),dict(check='Full RENT count matches repository claim',passed=len(rows)==21431),dict(check='Archive CRC',passed=True)]
    report=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence_class='FRESH_OFFLINE',commit='907cfa839d2665b3702450eb40acd4c96fe9296c',archive_sha256=digest(a.archive),sqlite_sha256=digest(dbpath),archive_member=member.filename,sqlite_bytes=member.file_size,counts=counts,listing_types=listing_types,rental_rows=len(raw),coverage=coverage,absent_business_columns=absent,duplicate_listing_ids=duplicate,orphan_images=orphans,csv_rows=csvcounts,checks=checks,integrity=integrity)
    (a.out/'data_audit.json').write_text(json.dumps(report,indent=2));(a.out/'oracle_expectations.json').write_text(json.dumps(gold,indent=2));(a.scratch/'oracle_input.json').write_text(json.dumps(rows))
    print(json.dumps({k:report[k] for k in ['counts','rental_rows','archive_sha256','sqlite_bytes','checks']}))
    db.close()
    if not all(c['passed'] for c in checks):raise SystemExit(1)
if __name__=='__main__':main()
