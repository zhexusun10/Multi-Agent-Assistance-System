GROUP 42 LATEST ACCEPTANCE PACK
Version 3.3 with ClinePass live model evaluation

Tested commit 89131897f56bbc176c30246a451f118f7de0209f
Execution date 21 October 2026, Asia/Shanghai

Read 01_Latest_Testing_and_Acceptance_Report.docx first. UAT_Task_Template.json contains eight unexecuted participant tasks with blank observation and reviewer fields. The native recommendation path passed the recorded checks with rules and the native scripted controller. Final system acceptance remains pending. The Excel Review sheet separates observed technical results from human review and outstanding gates. Yellow cells are editable team inputs. The Native Cases sheet contains seven independent full-data scenarios. Retrieval Cases records the eight original retrieval tests and their expected and observed outcomes. Evidence lists precise scopes and previous path retests; E12 contains the retrieval follow up. Different test profiles overlap; do not add their counts.

The earlier native/scripted and eight-test offline profiles recorded no chat model calls. The new live retrieval profile used a real local embedding model, real Chroma and actual BM25/RRF. Its 40 repository evaluation questions achieved 100% fused section Recall@5 and 18 integration checks passed. These results do not establish chat answer quality or performance capacity.

DeepSeek V4.1 Flash now works through ClinePass with the same supplied credential. The subscription slug is cline-pass/deepseek-v4.1-flash, as documented at https://docs.cline.bot/getting-started/clinepass . The earlier 402 concerned the separate usage-billing slug; it did not establish exhaustion of the subscription quota. That historical receipt is preserved.

With the QA provider transport and explicit nonthinking configuration, the original intent test passed 42/42 with every LLM and vector channel successful. The original knowledge answer test passed 21/22 and remains FAIL. The full live model workflow passed seven operations, owner isolation and overflow rejection. The native controller executed four tools with four real model calls against 21,431 canonical rental rows. Reply continuity passed both Node tests, including the real model subtest. DEF04 remains open because a refund-guarantee challenge produced a safe but generic abstention rather than the explicit cited refusal required by the original assertion. R01 is FAIL, R02 is PASS and final acceptance remains PENDING. Participant UAT, capacity, Windows execution and human signoff remain open. No external message or booking was made.

REPRODUCTION PROFILE
Use an exact checkout of the tested commit and dedicated databases. The QA project was g42-qa-8913189 with fresh Docker volumes. PostgreSQL 16.15 used the cached pgvector/pgvector:pg16 image; Neo4j was the unmodified official 5.26.32 image. The override file records reduced Neo4j memory settings. Configure .env locally with LLM_MODE=rules, RECOMMENDATION_MODE=native, RECOMMENDATION_CONTROLLER=scripted, RECOMMENDATION_DATA_MODE=database, EXTERNAL_ACTION_MODE=simulation, DATA_MODE=full and DATASET_VERSION=2026-10-09. Use a generated local recommendation service token and a dedicated native SQLite state path. Provider keys are unnecessary for this profile. Never commit .env or runtime session tokens.

Prepare the snapshot using data/knowledge_graph.py prepare-postgres and import, project the committed official location catalogs using scripts/project-locations.ts, then run data/knowledge_graph.py verify --api-url http://127.0.0.1:8089. Run full validators sequentially on a small Docker allocation. Preserve the verified report as DATA_BUNDLE_MANIFEST_PATH. Start the data API, native recommendation service, graph service and public FastAPI entrypoint using the repository entrypoints. See observed-app-config.json for the actual modes; this file contains no keys.

SCOPED COMMANDS FROM THE CHECKOUT
node node_modules/typescript/bin/tsc --noEmit
node node_modules/typescript/bin/tsc --noEmit -p tsconfig.recommendation.json
node node_modules/typescript/bin/tsc
node --import tsx --test tests/*.test.ts
python -m pytest data/tests recommendation/tests tests/test_api.py tests/test_webhook_gateway.py tests/test_native_transport.py -q

The offline commands were executed before the runtime .env and QA harness were created. PostgreSQL tests additionally set PROPERTYGURU_TEST_DATABASE_URL and TEST_DATABASE_URL to dedicated test databases. Follow-up component tests use DATASET_VERSION=fixture-design-v1 and BUSINESS_LIVE=1; they require the runtime event/task/domain schemas. This fixture identity must not change the running full-data application's profile. Do not enable every BUSINESS_LIVE test against native full data: several repository tests deliberately target the older sample/baseline profile.

Run tools/native_sql_acceptance.py --repo /absolute/checkout --out /absolute/new-evidence-folder. It checks the scripted controller before sending a native request and always calculates all seven scenarios afresh. It needs the repository Python dependencies plus httpx and python-dotenv.

Copy tools/qa-native-scripted.test.ts into the checkout tests folder, then run QA_NATIVE_SCRIPTED=1 node --env-file=.env --import tsx --test tests/qa-native-scripted.test.ts. Keep the application in rules/native/scripted/simulation modes. This is a separately labelled adaptation of the original live-model test. It preserves the SQL, score, feedback, replay, hidden-commit, explanation, draft, summary and media assertions. Executed copies are retained under evidence/executed_harnesses. The reusable copies additionally accept path arguments or check safe mode configuration; they are not represented as separately rerun product tests.

Run NATIVE_GEO_LIVE=1 node --env-file=.env --import tsx --test tests/native-geography-live.test.ts for the real graph oracle. Run python scripts/test_native_recommendation_ui.py after the scripted integration test has created its ignored browser session. The canonical presentation test used SAMPLE_PROPERTYGURU_DATABASE_URL pointing explicitly to the full propertyguru database for its independent SQL oracle. Run tests/listing-presentation-live.test.ts before tests/reply-continuity-live.test.ts; the latter needs its NUS conversation fixture. MODEL_LIVE remained unset in that earlier profile. The subsequent real model reply retest is recorded below.

The evidence archive includes passing logs, JUnit records, exact counts, SQL/graph/HTTP verification, browser screenshots and the initial resource/precondition incidents. It excludes .env, owner tokens, databases, model weights and Docker images. Manifest SHA256 hashes cover all delivered files except the manifest itself.

RETRIEVAL FOLLOW UP REPRODUCTION
The eight original tests in tests/test_retrieval.py ran unchanged against commit 89131897f56bbc176c30246a451f118f7de0209f. A new isolated Python 3.12 environment contained chromadb 0.5.23, numpy 1.26.4, rank-bm25 0.2.2, jieba 0.42.1 and fastembed 0.7.4. All installed versions are recorded in evidence/retrieval-requirements-frozen.txt; pip check reported no broken requirements. Dependency installation occurred before the guarded execution and downloaded packages, not model weights. This is the recorded macOS environment, not a portability acceptance result.

With those dependencies installed, execute the following from this pack using the isolated environment's Python:
python tools/run_retrieval_offline.py --repo /absolute/runtime-checkout --source /absolute/pinned-source-checkout --out /absolute/new-retrieval-evidence

Both checkouts must contain the tested commit. The helper compares every retrieval Python source, all eight corpus documents and the original test file against the independent source checkout before running. It supplies only a temporary corpus-derived manifest to retrieval.hybrid.MANIFEST; it does not call index_knowledge or publish a production index. Network connections and DNS, embedding construction and calls, ONNX sessions and real Chroma clients are blocked during imports and test execution. Any guarded attempt makes the overall result fail even if a broad production exception handler catches the blocked operation. The corpus fixture, pytest log, JUnit file, exact original test file and executed helper are retained as evidence. Model cache directories remained absent.

RT01 to RT08 cover chunk boundaries and preservation, real corpus metadata and expiry, rejected source forms, RRF ranks and duplicates, lexical synonyms, embedding model mismatch, an injected vector query failure and an injected connection failure. The last two tests use their original vector mocks and the actual BM25 implementation; each returned five chunks with vector_unavailable. They do not establish successful vector retrieval, embedding quality or current legal/policy accuracy. At completion of that offline profile R02 was NOT_RUN. The later live retrieval profile now passes R02; the later chat answer suite is recorded separately as 21/22 FAIL in R01 and final acceptance remains pending. Earlier test profiles were not rerun or added into a combined pass rate.

REAL RETRIEVAL FOLLOW UP
This separate runtime copies the pinned source unchanged. Chroma 0.5.23 ran natively on macOS at loopback port 18002. The server used a dependency overlay containing FastAPI 0.115.9 and Starlette 0.45.3 after the initial current FastAPI 0.156 combination rejected collection creation. The client remains in the separately recorded retrieval environment. All model files are identified by SHA256 in live-retrieval-acceptance.json. The model is sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 using FastEmbed 0.7.4 and CPUExecutionProvider. Its initial weight download was interrupted and the built-in downloader resumed successfully. Model files and the persisted test index remain local and are excluded from this archive.

The original commands ran with CHROMA_HOST=127.0.0.1, CHROMA_PORT=18002, ANONYMIZED_TELEMETRY=False and TOKENIZERS_PARALLELISM=false:
python -m retrieval.index
node --import tsx scripts/export-intent-templates.ts
python -m retrieval.app
PYTHONPATH=. python scripts/evaluate_retrieval.py
python -m uvicorn retrieval.app:app --host 127.0.0.1 --port 18091

The original 40 query evaluator uses the original question only, with no chat rewrite or rerank. Section Recall@5 was 95% vector, 95% BM25 and 100% fused. Document Recall@5 was 95%, 97.5% and 100% respectively. MRR was 0.793333, 0.884167 and 0.883333. Fusion improved recall on this evaluation set; it did not improve every metric. This is the repository evaluation set rather than an independent holdout. Three exact indexed-template intent queries checked HTTP plumbing only. The additional integration receipt contains vector readback, six real HTTP searches, health, invalid inputs, template version rejection and source identity checks. No question was added to the knowledge index.

CLINEPASS LIVE MODEL PROFILE
The base URL is https://api.cline.bot/api/v1. The successful response model was deepseek/deepseek-v4.1-flash. A dated 1017 backend build is not exposed by this subscription response and is not claimed. Use tools/cline-profile.example as a template and keep credentials in a private env file. The supplied key is absent from every delivered file.

The ClinePass nonstreaming response used a success/data envelope. tools/cline-pass-transport.mjs unwraps that envelope for the repository's LangChain client and records optional audits without headers or credentials. G42_CLINE_NONTHINKING=1 adds thinking disabled and reasoning disabled at the provider boundary. It preserves model choice, messages, token limits, temperatures, business logic, corpus and test assertions. The adapter supports nonstreaming only. Carry equivalent handling into production integration before relying on this profile. The first default-reasoning intent run failed its model-success assertion at 40/42, although all final routes were correct through fallback; both first-run and configured-retest results are retained.

For the standalone reusable access helper, run:
python tools/cline_model_smoke.py --env /absolute/private-env --out /absolute/new-cline-access.json
The helper accepts CLINE_API_KEY or the project's OPENAI_API_KEY from that private file. It is updated for the subscription route; the exact executed probe is retained under evidence/executed_harnesses. No additional request was made solely to retest the reusable wrapper.

From the pinned checkout, make the transport available through an absolute file URI in NODE_OPTIONS before starting the graph service and the Python native service. The native controller launches Node model-bridge subprocesses that must inherit the option. For example, set NODE_OPTIONS to --import=file:///ABSOLUTE/PATH/TO/tools/cline-pass-transport.mjs . Set G42_CLINE_NONTHINKING=1. Use the private provider env file and the real cached retrieval services. Do not place any credential in a shell command argument.

INTENT_LIVE=1 node --env-file=/absolute/private-env --import tsx --test tests/orchestrator-intent-live.test.ts
RAG_LIVE=1 node --env-file=/absolute/private-env --import tsx --test tests/knowledge-live.test.ts
ORCHESTRATOR_LIVE=1 node --env-file=/absolute/private-env --import tsx --test tests/orchestrator-rag-live.test.ts
BUSINESS_LIVE=1 MODEL_LIVE=1 node --env-file=/absolute/private-env --import tsx --test tests/reply-continuity-live.test.ts

The original tests also read the checkout .env file. Point it at the same private configuration so its provider overrides agree with the process profile. These runs used a separate clean workflow database in the retained QA PostgreSQL instance, existing immutable property data, a new native SQLite state, and loopback services. The reply-continuity fixture points to the successful current NUS workflow session; this adaptation is recorded in reply-fixture-provenance.json. The original reply assertions and source were unchanged. Browser tests from the earlier scripted profile were not rerun with the model profile and are not claimed as live-model browser acceptance.

USAGE AND OPEN WORK
cline-request-accounting.json records 200 external API attempts across all phases, including the earlier metered 402 and first intent run. There were 196 HTTP 200 model responses, three HTTP 500 responses and one HTTP 402 response. An API response is not a passed business case. Reported usage totals 191,109 tokens. The provider reference cost totals USD 0.027280158; this is not a subscription invoice or a verified extra charge. No usage or spend is inferred for four responses without usage. Model and local services were stopped after evidence collection; the indexes and QA databases were retained.

Resolve DEF04 with the knowledge owner and QA reviewer. Improve the grounded refusal or formally agree an amended expectation, retain the original failing evidence and rerun the affected evaluation. Then complete participant UAT, declared performance testing, target Windows execution and human signoff. All reviewer and participant fields remain blank. No test was weakened and no production source was changed to force a pass.
