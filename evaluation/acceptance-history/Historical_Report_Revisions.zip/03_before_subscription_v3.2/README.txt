GROUP 42 LATEST ACCEPTANCE PACK
Version 3.2 with real retrieval and blocked Cline model access

Tested commit 89131897f56bbc176c30246a451f118f7de0209f
Execution date 21 October 2026, Asia/Shanghai

Read 01_Latest_Testing_and_Acceptance_Report.docx first. UAT_Task_Template.json contains eight unexecuted participant tasks with blank observation and reviewer fields. The native recommendation path passed the recorded checks with rules and the native scripted controller. Final system acceptance remains pending. The Excel Review sheet separates observed technical results from human review and outstanding gates. Yellow cells are editable team inputs. The Native Cases sheet contains seven independent full-data scenarios. Retrieval Cases records the eight original retrieval tests and their expected and observed outcomes. Evidence lists precise scopes and previous path retests; E12 contains the retrieval follow up. Different test profiles overlap; do not add their counts.

The earlier native/scripted and eight-test offline profiles recorded no chat model calls. The new live retrieval profile used a real local embedding model, real Chroma and actual BM25/RRF. Its 40 repository evaluation questions achieved 100% fused section Recall@5 and 18 integration checks passed. These results do not establish chat answer quality or performance capacity.

The user authorized DeepSeek V4.1 Flash through Cline for this follow up. One request for deepseek/deepseek-v4.1-flash-1017 was rejected with HTTP 402 insufficient_credits. No model completion or token usage was returned. The model SDK check, 22 question RAG answers, live LLM intent classification and model enabled business workflow are not run. R01 is BLOCKED, R02 is PASS and final system acceptance remains PENDING. No external message or booking was made. Participant UAT, Windows execution, capacity and team signoff remain open.

REPRODUCTION PROFILE
Use an exact checkout of the tested commit and dedicated databases. The QA project was g42-qa-8913189 with fresh Docker volumes. PostgreSQL 16.15 used the cached pgvector/pgvector:pg16 image; Neo4j was the unmodified official 5.26.32 image. The override file records reduced Neo4j memory settings. Configure .env locally with LLM_MODE=rules, RECOMMENDATION_MODE=native, RECOMMENDATION_CONTROLLER=scripted, RECOMMENDATION_DATA_MODE=database, EXTERNAL_ACTION_MODE=simulation, DATA_MODE=full and DATASET_VERSION=2026-10-09. Use a generated local recommendation service token and a dedicated native SQLite state path. Provider keys are unnecessary for this profile. Never commit .env or runtime session tokens.

Prepare the snapshot using data/knowledge_graph.py prepare-postgres and import, project the committed official location catalogs using scripts/project-locations.ts, then run data/knowledge_graph.py verify --api-url http://127.0.0.1:8089. Run full validators sequentially on a small Docker allocation. Preserve the verified report as DATA_BUNDLE_MANIFEST_PATH. Start the data API, native recommendation service, graph service and public FastAPI entrypoint using the repository entrypoints. See observed-app-config.json for the actual modes; this file contains no keys.

SCOPED COMMANDS FROM THE CHECKOUT
node node_modules/typescript/bin/tsc --noEmit
node node_modules/typescript/bin/tsc --noEmit -p tsconfig.recommendation.json
node node_modules/typescript/bin/tsc
node --import tsx --test tests/*.test.ts
python -m pytest data/tests recommendation/tests tests/test_api.py tests/test_webhook_gateway.py tests/test_native_transport.py -q

The offline commands were executed before the runtime .env and QA harness were created. PostgreSQL tests additionally set PROPERTYGURU_TEST_DATABASE_URL and TEST_DATABASE_URL to dedicated test databases. Follow-up component tests use DATASET_VERSION=fixture-design-v1 and BUSINESS_LIVE=1; they require the runtime event/task/domain schemas. This fixture identity must not change the running full-data application's profile. Do not enable every BUSINESS_LIVE test against native full data: several repository tests deliberately target the older sample/baseline profile.

Run tools/native_sql_acceptance.py --repo /absolute/checkout --out /absolute/new-evidence-folder. It checks the scripted controller before sending a native request and always calculates all seven scenarios afresh. It needs the repository Python dependencies plus httpx and python-dotenv.

Copy tools/qa-native-scripted.test.ts into the checkout tests folder, then run QA_NATIVE_SCRIPTED=1 node --env-file=.env --import tsx --test tests/qa-native-scripted.test.ts. Keep the application in rules/native/scripted/simulation modes. This is a separately labelled adaptation of the original live-model test. It preserves the SQL, score, feedback, replay, hidden-commit, explanation, draft, summary and media assertions. Executed copies are retained under evidence/executed_harnesses. The reusable copies additionally accept path arguments or check safe mode configuration; they are not represented as separately rerun product tests.

Run NATIVE_GEO_LIVE=1 node --env-file=.env --import tsx --test tests/native-geography-live.test.ts for the real graph oracle. Run python scripts/test_native_recommendation_ui.py after the scripted integration test has created its ignored browser session. The canonical presentation test used SAMPLE_PROPERTYGURU_DATABASE_URL pointing explicitly to the full propertyguru database for its independent SQL oracle. Run tests/listing-presentation-live.test.ts before tests/reply-continuity-live.test.ts; the latter needs its NUS conversation fixture. MODEL_LIVE remained unset.

The evidence archive includes passing logs, JUnit records, exact counts, SQL/graph/HTTP verification, browser screenshots and the initial resource/precondition incidents. It excludes .env, owner tokens, databases, model weights and Docker images. Manifest SHA256 hashes cover all delivered files except the manifest itself.

RETRIEVAL FOLLOW UP REPRODUCTION
The eight original tests in tests/test_retrieval.py ran unchanged against commit 89131897f56bbc176c30246a451f118f7de0209f. A new isolated Python 3.12 environment contained chromadb 0.5.23, numpy 1.26.4, rank-bm25 0.2.2, jieba 0.42.1 and fastembed 0.7.4. All installed versions are recorded in evidence/retrieval-requirements-frozen.txt; pip check reported no broken requirements. Dependency installation occurred before the guarded execution and downloaded packages, not model weights. This is the recorded macOS environment, not a portability acceptance result.

With those dependencies installed, execute the following from this pack using the isolated environment's Python:
python tools/run_retrieval_offline.py --repo /absolute/runtime-checkout --source /absolute/pinned-source-checkout --out /absolute/new-retrieval-evidence

Both checkouts must contain the tested commit. The helper compares every retrieval Python source, all eight corpus documents and the original test file against the independent source checkout before running. It supplies only a temporary corpus-derived manifest to retrieval.hybrid.MANIFEST; it does not call index_knowledge or publish a production index. Network connections and DNS, embedding construction and calls, ONNX sessions and real Chroma clients are blocked during imports and test execution. Any guarded attempt makes the overall result fail even if a broad production exception handler catches the blocked operation. The corpus fixture, pytest log, JUnit file, exact original test file and executed helper are retained as evidence. Model cache directories remained absent.

RT01 to RT08 cover chunk boundaries and preservation, real corpus metadata and expiry, rejected source forms, RRF ranks and duplicates, lexical synonyms, embedding model mismatch, an injected vector query failure and an injected connection failure. The last two tests use their original vector mocks and the actual BM25 implementation; each returned five chunks with vector_unavailable. They do not establish successful vector retrieval, embedding quality or current legal/policy accuracy. At completion of that offline profile R02 was NOT_RUN. The later live retrieval profile now passes R02; Cline chat model acceptance remains blocked in R01 and final acceptance remains pending. Earlier test profiles were not rerun or added into a combined pass rate.

REAL RETRIEVAL FOLLOW UP
This separate runtime copies the pinned source unchanged. Chroma 0.5.23 ran natively on macOS at loopback port 18002. The server used a dependency overlay containing FastAPI 0.115.9 and Starlette 0.45.3 after the initial current FastAPI 0.156 combination rejected collection creation. The client remains in the separately recorded retrieval environment. All model files are identified by SHA256 in live-retrieval-acceptance.json. The model is sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 using FastEmbed 0.7.4 and CPUExecutionProvider. Its initial weight download was interrupted and the built-in downloader resumed successfully. Model files and the persisted test index remain local and are excluded from this archive.

The original commands ran with CHROMA_HOST=127.0.0.1, CHROMA_PORT=18002, ANONYMIZED_TELEMETRY=False and TOKENIZERS_PARALLELISM=false:
python -m retrieval.index
node --import tsx scripts/export-intent-templates.ts
python -m retrieval.app
PYTHONPATH=. python scripts/evaluate_retrieval.py
python -m uvicorn retrieval.app:app --host 127.0.0.1 --port 18091

The original 40 query evaluator uses the original question only, with no chat rewrite or rerank. Section Recall@5 was 95% vector, 95% BM25 and 100% fused. Document Recall@5 was 95%, 97.5% and 100% respectively. MRR was 0.793333, 0.884167 and 0.883333. Fusion improved recall on this evaluation set; it did not improve every metric. This is the repository evaluation set rather than an independent holdout. Three exact indexed-template intent queries checked HTTP plumbing only. The additional integration receipt contains vector readback, six real HTTP searches, health, invalid inputs, template version rejection and source identity checks. No question was added to the knowledge index.

CLINE ACCESS AND RESUMPTION
The verified Cline base URL is https://api.cline.bot/api/v1. The public model catalog listed deepseek/deepseek-v4.1-flash-1017. Cline documentation: https://docs.cline.bot/api/overview and https://docs.cline.bot/api/errors . The user supplied the key solely for this authorized model test. The credential is not present in any delivered file. No alternative model was used after the credit rejection.

After usable Cline Credits are available, the reusable helper accepts CLINE_API_KEY through the process environment or a private local env file. Run python tools/cline_model_smoke.py --env /absolute/private-env --out /absolute/new-cline-smoke.json . The helper makes one bounded request to the fixed Cline host and selected model, with no automatic retry. It writes no credential and prints only status and the output path. The exact initially executed helper is retained separately in evidence/executed_harnesses. The reusable helper and prepared cline-profile.example are not represented as successfully executed model integration tests.

Once the smoke succeeds, use the prepared provider configuration to run the repository model SDK check, tests/knowledge-live.test.ts, tests/orchestrator-intent-live.test.ts and the model enabled workflow in sequence. Preserve their actual responses, citations, parameters, latencies and provider-reported usage. Keep external delivery in simulation. Existing offline passes must not be counted as live model passes.
