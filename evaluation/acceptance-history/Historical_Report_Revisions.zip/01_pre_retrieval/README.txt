GROUP 42 LATEST ACCEPTANCE PACK

Tested commit 89131897f56bbc176c30246a451f118f7de0209f
Execution date 21 October 2026, Asia/Shanghai

Read 01_Latest_Testing_and_Acceptance_Report.docx first. UAT_Task_Template.json contains eight unexecuted participant tasks with blank observation and reviewer fields. The native recommendation path passed the recorded checks with rules and the native scripted controller. Final system acceptance remains pending. The Excel Review sheet separates observed technical results from human review and outstanding gates. Yellow cells are editable team inputs. The Native Cases sheet contains seven independent full-data scenarios. Evidence lists precise scopes and previous path retests. Different test profiles overlap; do not add their counts.

No real model call, external message or booking was made. The browser is automated evidence, not participant UAT. Hybrid retrieval and eight retrieval Python tests were not run; no Chroma service or embedding index was provisioned. Windows launcher execution, capacity and final team review remain open. Keep these boundaries when presenting the results.

REPRODUCTION PROFILE
Use an exact checkout of the tested commit and dedicated databases. The QA project was g42-qa-8913189 with fresh Docker volumes. PostgreSQL 16.15 used the cached pgvector/pgvector:pg16 image; Neo4j was the unmodified official 5.26.32 image. The override file records reduced Neo4j memory settings. Configure .env locally with LLM_MODE=rules, RECOMMENDATION_MODE=native, RECOMMENDATION_CONTROLLER=scripted, RECOMMENDATION_DATA_MODE=database, EXTERNAL_ACTION_MODE=simulation, DATA_MODE=full and DATASET_VERSION=2026-10-09. Use a generated local recommendation service token and a dedicated native SQLite state path. Provider keys are unnecessary for this profile. Never commit .env or runtime session tokens.

Prepare the snapshot using data/knowledge_graph.py prepare-postgres and import, project the committed official location catalogs using scripts/project-locations.ts, then run data/knowledge_graph.py verify --api-url http://127.0.0.1:8089. Run full validators sequentially on a small Docker allocation. Preserve the verified report as DATA_BUNDLE_MANIFEST_PATH. Start the data API, native recommendation service, graph service and public FastAPI entrypoint using the repository entrypoints. See observed-app-config.json for the actual modes; this file contains no keys.

SCOPED COMMANDS FROM THE CHECKOUT
node node_modules/typescript/bin/tsc --noEmit
node node_modules/typescript/bin/tsc --noEmit -p tsconfig.recommendation.json
node node_modules/typescript/bin/tsc
node --import tsx --test tests/*.test.ts
python -m pytest data/tests recommendation/tests tests/test_api.py tests/test_webhook_gateway.py tests/test_native_transport.py -q

The offline commands were executed before the runtime .env and QA harness were created. PostgreSQL tests additionally set PROPERTYGURU_TEST_DATABASE_URL and TEST_DATABASE_URL to dedicated test databases. Follow-up component tests use DATASET_VERSION=fixture-design-v1 and BUSINESS_LIVE=1; they require the runtime event/task/domain schemas. This fixture identity must not change the running full-data application's profile. Do not enable every BUSINESS_LIVE test against native full data: several repository tests deliberately target the older sample/baseline profile.

Run tools/native_sql_acceptance.py --repo /absolute/checkout --out /absolute/new-evidence-folder. It checks the scripted controller before sending a native request and always calculates all seven scenarios afresh. It needs the repository Python dependencies plus httpx and python-dotenv.

Copy tools/qa-native-scripted.test.ts into the checkout tests folder, then run QA_NATIVE_SCRIPTED=1 node --env-file=.env --import tsx --test tests/qa-native-scripted.test.ts. Keep the application in rules/native/scripted/simulation modes. This is a separately labelled adaptation of the original live-model test. It preserves the SQL, score, feedback, replay, hidden-commit, explanation, draft, summary and media assertions. Executed copies are retained under evidence/executed_harnesses. The reusable copies additionally accept path arguments or check safe mode configuration; they are not represented as separately rerun product tests.

Run NATIVE_GEO_LIVE=1 node --env-file=.env --import tsx --test tests/native-geography-live.test.ts for the real graph oracle. Run python scripts/test_native_recommendation_ui.py after the scripted integration test has created its ignored browser session. The canonical presentation test used SAMPLE_PROPERTYGURU_DATABASE_URL pointing explicitly to the full propertyguru database for its independent SQL oracle. Run tests/listing-presentation-live.test.ts before tests/reply-continuity-live.test.ts; the latter needs its NUS conversation fixture. MODEL_LIVE remained unset.

The evidence archive includes passing logs, JUnit records, exact counts, SQL/graph/HTTP verification, browser screenshots and the initial resource/precondition incidents. It excludes .env, owner tokens, databases, model weights and Docker images. Manifest SHA256 hashes cover all delivered files except the manifest itself.
