EXTENDED TEST REPRODUCTION — ENGLISH GUIDE
Pinned application commit: 89131897f56bbc176c30246a451f118f7de0209f.

These are copies of the executed external QA harnesses, with environment-specific sibling paths preserved. Their exact executed versions are also under evidence/extended/executed_harnesses. They do not include the application, databases, dependencies or credentials. Follow the main README for the full 21,431-row snapshot import and real Chroma/MiniLM setup. Use isolated QA databases and keep EXTERNAL_ACTION_MODE=simulation.

To reuse the same relative layout under a chosen working directory:
1. Place an exact application checkout in .build/qa_live_cline_8913189/runtime; install its Node and Python dependencies. Keep all original test assertions unchanged.
2. Place the provider transport from tools/cline-pass-transport.mjs at .build/qa_live_cline_8913189/cline-pass-transport.mjs. Use tools/cline-profile.example with the authorized key in a private env file. Point runtime/.env to that file. Use a new workflow database/native state, real data service, and the retained real knowledge/intent indexes.
3. Copy this folder's contents to .build/qa_extended_8913189. For TSX to resolve the project's model libraries, provide a node_modules symlink there to the runtime checkout's node_modules. package.json sets type=module. The frozen catalogue and hash must match; do not regenerate expectations after seeing results.
4. services.py records owned process groups and uses the observed sibling Python environments (.build/qa_repo_v2/python and .build/qa_retrieval_8913189/python), a Chroma server dependency overlay, and loopback ports 8010/8089/8092/18002/18091. Recreate those environments/paths or adapt only the launcher paths to the same dependency versions and modes. The graph service uses its configured loopback port. Do not point fault harnesses at shared services.
5. Run the repository's standard TypeScript build before browser acceptance. Start healthy QA services and verify the full snapshot and persisted indexes. Supply the private provider profile to every model process, including the native controller's Node subprocess. Do not store any secret in command arguments or the archive.

From the runtime checkout, with G42_CLINE_NONTHINKING=1 and G42_CLINE_AUDIT set to a private absolute receipt file:
node --env-file=.env --import ../cline-pass-transport.mjs --import tsx ../../qa_extended_8913189/run_model_cases.ts intent
Repeat the same command with knowledge and reply. def04 repeats the unchanged historical refund challenge three times. Suite FAIL is expected on the pinned baseline where the retained defect reproduces; do not edit expectations to suppress it.

Original full recommendation test:
NATIVE_LIVE=1 node --env-file=.env --import tsx --test tests/native-recommendation-live.test.ts
The native and graph processes must already inherit the provider transport and nonthinking settings. Then run python scripts/test_native_recommendation_ui.py using the same ignored session fixture produced by that original test. It exercises real browser actions and manual SAMPLE feedback; it does not send external messages.

With all healthy services, run api_boundaries.py using a Python environment with httpx and python-dotenv. It observes real HTTP responses; invalid requests are expected to be rejected before chat calls. fault_recovery.py deliberately stops/restarts only processes registered by services.py and depends on app_client.py and fault_probe.ts. Run it serially. app_client.py waits for terminal PostgreSQL domain operation status because an SSE acknowledgement does not establish completion.

performance.py runs 10 retrieval requests each at concurrency 1/3/5 and 3 completed model workflows each at concurrency 1/3, restarting the graph between application batches to clear answer cache. It measures response contracts and timings, not an approved SLA or sustained-load capacity. Do not rerun fault or performance harnesses against a shared or production environment.

Every rerun should use a new receipt directory, a new audit file, declared model/profile and a pinned source. Preserve earlier failures. Human UAT and reviewer signatures remain separate work.
