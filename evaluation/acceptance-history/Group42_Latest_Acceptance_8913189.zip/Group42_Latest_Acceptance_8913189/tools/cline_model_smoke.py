"""Verify DeepSeek V4.1 Flash through the authorized ClinePass subscription."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import time
import requests
from dotenv import dotenv_values

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--env',type=Path,help='Optional private local env file containing CLINE_API_KEY')
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
settings=dotenv_values(args.env) if args.env else {}
key=settings.get('CLINE_API_KEY') or settings.get('OPENAI_API_KEY') or os.getenv('CLINE_API_KEY')
if not key:raise SystemExit('Set CLINE_API_KEY in a private local env file or the process environment. Do not place it in a command argument.')
model='cline-pass/deepseek-v4.1-flash'
payload={'model':model,'messages':[{'role':'user','content':'Reply with exactly G42_MODEL_OK and nothing else.'}],
         'temperature':0,'max_tokens':128,'stream':False,'reasoning':{'enabled':False},'thinking':{'type':'disabled'}}
start=time.monotonic()
report={'started_at':datetime.now().astimezone().isoformat(),'endpoint':'https://api.cline.bot/api/v1/chat/completions',
        'requested_model':model,'request_attempts':1}
try:
    response=requests.post(report['endpoint'],headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},
                           json=payload,timeout=60,allow_redirects=False)
    report['http_status']=response.status_code
    try:data=response.json()
    except ValueError:data={}
    if data.get('success') is True and isinstance(data.get('data'),dict):
        report['response_envelope']='success/data'
        data=data['data']
    report['returned_model']=data.get('model')
    report['token_usage']=data.get('usage')
    error=data.get('error')
    report['error_code']=error.get('code') if isinstance(error,dict) else error
    content=((data.get('choices') or [{}])[0].get('message') or {}).get('content','')
    report['successful_model_responses']=int(response.status_code==200 and bool(content))
    report['status']='PASS' if response.status_code==200 and content.strip()=='G42_MODEL_OK' and data.get('model')=='deepseek/deepseek-v4.1-flash' else 'BLOCKED' if response.status_code in [401,402,403] else 'FAIL'
except requests.RequestException as e:
    report.update(status='FAIL',error_type=type(e).__name__)
report['latency_ms']=round((time.monotonic()-start)*1000)
args.out.parent.mkdir(parents=True,exist_ok=True)
args.out.write_text(json.dumps(report,indent=2).replace(key,'[REDACTED]'))
print(json.dumps({'status':report['status'],'http_status':report.get('http_status'),'output':str(args.out)}))
raise SystemExit(0 if report['status']=='PASS' else 1)
