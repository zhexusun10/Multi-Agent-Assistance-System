EXTENDED EXECUTION RECEIPTS — VERSION 3.4
Source: 89131897f56bbc176c30246a451f118f7de0209f. Execution: 21 October 2026.

Start with acceptance-summary.json and open-issues.json. The 140 new functional checks are 60 intent, 24 knowledge, 18 reply, 32 HTTP boundary and 6 actual outage/recovery checks. There are 135 individual passes and 5 individual failures. Intent meets its frozen >=95% suite threshold at 59/60; XI20 is still an individual failure. Keep suite decisions separate from case counts.

native-full-model-result.json has 8 recorded checks from the unchanged original integration test. native-browser-result.json records 5 original workflow groups with the real model; knowledge-browser-result.json adds 4 automated browser checks. These are separate from the 140 and do not represent participant UAT. The three DEF04 repeats and 36 timing samples are also excluded from that functional count. Timings have no agreed SLA. All six application timing workflows produced grounded answers; one reranker timed out and caused the strict no-degradation contract to fail at 5/6.

frozen-cases.json was frozen before model execution; its SHA256 is in every model case receipt. The 60 exact intent texts were checked against the original 42-case corpus and 42 templates. These are authored, corpus-derived regressions, not an independently human-labelled holdout. Full raw inputs and answers may retain their original Chinese language; the formal report and tracking labels are English.

request-accounting.json reconciles all 277 additional API attempts, including setup/fault reruns: 276 HTTP 200 model responses and one 10-second transport timeout. An API success is not a case pass. Audit files omit credentials and headers; original content/tool responses, usage and message hashes are retained. No token usage or cost is inferred for missing usage. Reference cost is not a subscription invoice or verified extra charge.

setup-incidents retains a browser attempt before the standard TypeScript build and an early fault harness that read state immediately after an SSE acknowledgement. The final harness waits for terminal operation completion. Both corrected runs retained the business expectations. Those setup observations are not product defects. Earlier evidence elsewhere in the archive is unchanged.

executed_harnesses contains exact test sources. No product source or original assertion was edited. Services used a separate QA workflow database and native state; outbox count was zero. Local services were stopped. Credentials, owner tokens, database files, weights and large native pools are excluded. Reproduction requires environment preparation described in tools/extended/README.txt; this is not a self-contained deployment bundle.
