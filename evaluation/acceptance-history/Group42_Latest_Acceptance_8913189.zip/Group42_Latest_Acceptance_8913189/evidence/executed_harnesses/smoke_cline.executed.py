"""One authorized, bounded real-model connectivity request through Cline."""
from datetime import datetime
import json
from pathlib import Path
import time
import requests

BASE=Path(__file__).resolve().parent
key=json.loads(Path((BASE/'private_credential_path.txt').read_text()).read_text())['CLINE_API_KEY']
model='deepseek/deepseek-v4.1-flash-1017'
payload={'model':model,'messages':[{'role':'user','content':'Reply with exactly G42_MODEL_OK and nothing else.'}],
         'temperature':0,'max_tokens':128,'stream':False,
         'reasoning':{'enabled':False},'thinking':{'type':'disabled'}}
started=time.monotonic()
report={'started_at':datetime.now().astimezone().isoformat(),
        'provider':'Cline API','endpoint':'https://api.cline.bot/api/v1/chat/completions',
        'requested_model':model,'request':payload,'attempts':1}
try:
    response=requests.post(report['endpoint'],headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},
                           json=payload,timeout=60,allow_redirects=False)
    report['http_status']=response.status_code
    try:data=response.json()
    except ValueError:data={'error':'Non-JSON provider response'}
    safe=json.loads(json.dumps(data).replace(key,'[REDACTED]'))
    report['response']=safe
    content=((safe.get('choices') or [{}])[0].get('message') or {}).get('content','')
    report['status']='PASS' if response.status_code==200 and content.strip()=='G42_MODEL_OK' and safe.get('model')==model else 'FAIL'
except requests.RequestException as e:
    report.update(status='FAIL',error_type=type(e).__name__,error='Cline request did not complete')
report['latency_ms']=round((time.monotonic()-started)*1000)
(BASE/'cline-model-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:report.get(k) for k in ['status','http_status','requested_model','latency_ms','error_type']},indent=2))
if report.get('response'):
    print(json.dumps({'returned_model':report['response'].get('model'),'usage':report['response'].get('usage'),
                      'error':report['response'].get('error')},ensure_ascii=False,indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
