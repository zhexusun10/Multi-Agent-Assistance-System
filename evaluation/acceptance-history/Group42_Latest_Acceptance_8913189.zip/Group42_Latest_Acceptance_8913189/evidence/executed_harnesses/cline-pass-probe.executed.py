"""Bounded subscription-route probe; secrets are loaded only in memory."""
from datetime import datetime
import json
from pathlib import Path
import time
import requests

BASE = Path(__file__).resolve().parent
key = json.loads(Path((BASE / 'private_credential_path.txt').read_text()).read_text())['CLINE_API_KEY']
model = 'cline-pass/deepseek-v4.1-flash'
payload = {
    'model': model,
    'messages': [{'role': 'user', 'content': 'Reply with exactly G42_MODEL_OK and nothing else.'}],
    'temperature': 0, 'max_tokens': 128, 'stream': False,
    'reasoning': {'enabled': False}, 'thinking': {'type': 'disabled'},
}
report = {
    'started_at': datetime.now().astimezone().isoformat(),
    'provider': 'ClinePass',
    'endpoint': 'https://api.cline.bot/api/v1/chat/completions',
    'requested_model': model, 'request': payload, 'attempts': 1,
    'routing_source': 'https://docs.cline.bot/getting-started/clinepass',
    'historical_metered_attempt': 'cline-model-smoke.json',
}
started = time.monotonic()
try:
    response = requests.post(
        report['endpoint'], headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'},
        json=payload, timeout=60, allow_redirects=False,
    )
    report['http_status'] = response.status_code
    try:
        data = response.json()
    except ValueError:
        data = {'error': 'Non-JSON provider response'}
    report['response'] = json.loads(json.dumps(data).replace(key, '[REDACTED]'))
    content = ((report['response'].get('choices') or [{}])[0].get('message') or {}).get('content', '')
    report['answer_matches'] = content.strip() == 'G42_MODEL_OK'
    report['status'] = 'PASS' if response.status_code == 200 and report['answer_matches'] else 'FAIL'
except requests.RequestException as exc:
    report.update(status='FAIL', error_type=type(exc).__name__, error='ClinePass probe did not complete')
report['latency_ms'] = round((time.monotonic() - started) * 1000)
(BASE / 'cline-pass-model-smoke.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps({k: report.get(k) for k in ['status', 'http_status', 'requested_model', 'latency_ms', 'answer_matches', 'error_type']}, indent=2))
print(json.dumps({k: report.get('response', {}).get(k) for k in ['model', 'usage', 'error']}, ensure_ascii=False, indent=2))
raise SystemExit(0 if report['status'] == 'PASS' else 1)
