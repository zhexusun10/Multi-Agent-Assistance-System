"""Fresh native HTTP acceptance with real PostgreSQL and independent scalar oracles.

No production module is patched. Scripted controller is asserted; zero model calls.
"""
import datetime, json, math, time, uuid
from pathlib import Path
import httpx, psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import dotenv_values

BASE=Path(__file__).resolve().parent
CONFIG=dotenv_values(BASE/'run/.env')
headers={'x-recommendation-token':CONFIG['RECOMMENDATION_SERVICE_TOKEN']}
client=httpx.Client(base_url='http://127.0.0.1:8092',headers=headers,timeout=180)
conn=psycopg2.connect(CONFIG['PROPERTYGURU_DATABASE_URL'].replace('postgresql+psycopg2:','postgresql:'))
conn.set_session(readonly=True)
with conn.cursor(cursor_factory=RealDictCursor) as c:
    c.execute("SELECT listing_id,price,bedrooms,floor_area_sqft,district_code,property_type FROM properties WHERE listing_type='RENT'")
    rows=[dict(p) for p in c.fetchall()]
conn.close()
assert len(rows)==21431
for p in rows:
    p['listing_id']=str(p['listing_id'])
    for key in ('price','bedrooms','floor_area_sqft'):
        p[key]=float(p[key]) if p[key] is not None and math.isfinite(float(p[key])) and float(p[key])>=0 else None
rows.sort(key=lambda p:p['listing_id'])

def criterion(field,value,op='lte',strength='hard',**kw):
    return dict(criterion_id=field,field=field,value=value,operator=op,strength=strength,**kw)

def outcome(p,c):
    v=p.get(c['field']);w=c['value']
    if v is None:return 'unknown'
    return 'pass' if {'lte':lambda:v<=w,'gte':lambda:v>=w,'eq':lambda:v==w}[c['operator']]() else 'fail'

def oracle(criteria):
    groups={'eligible':[],'unverified':[],'excluded':[]}
    soft=[c for c in criteria if c['strength']=='soft']
    for p in rows:
        results=[outcome(p,c) for c in criteria if c['strength']=='hard']
        group='excluded' if 'fail' in results else 'unverified' if 'unknown' in results else 'eligible'
        score=sum(c.get('weight',1)*(outcome(p,c)=='pass') for c in soft)/sum(c.get('weight',1) for c in soft) if soft else 0
        groups[group].append((p['listing_id'],score))
    groups['eligible'].sort(key=lambda p:(-p[1],p[0]))
    return groups

budget=criterion('price',5000,unit='SGD/month')
beds=criterion('bedrooms',2,'gte')
district=criterion('district_code','D05','eq')
cases=[
 ('N01',[budget,beds,district],4),
 ('N02',[dict(budget,value=4500),beds,district],4),
 ('N03',[dict(budget,value=1)],4),
 ('N04',[dict(budget,value=3000),dict(district,strength='soft',weight=1)],4),
 ('N05',[beds,criterion('floor_area_sqft',800,'gte',unit='sqft')],4),
 ('N06',[criterion('furnishing','fully_furnished','eq')],4),
 ('N07',[budget,beds,district],1),
]
report={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':'89131897f56bbc176c30246a451f118f7de0209f','controller':'scripted','real_model_calls':0,'database':'real PostgreSQL 16','assessed_per_case':21431,'cases':[],'checks':[]}
previous=json.loads((BASE/'native-sql-acceptance.json').read_text()) if (BASE/'native-sql-acceptance.json').exists() else {}
report['cases']=previous.get('cases',[])
try:
    for name,criteria,limit in cases:
        if name in [c['id'] for c in report['cases'] if c['status']=='passed']:continue
        request={'request_id':str(uuid.uuid4()),'conversation_id':'qa-sql-'+str(uuid.uuid4()),'requirements_version':1,'result_limit':limit,'requirements':{'listing_type':'RENT','criteria':criteria}}
        expected=oracle(criteria);start=time.monotonic()
        http=client.post('/app/recommend',json=request);assert http.status_code==200,http.text[:300]
        env=http.json();rec=env['response'];assert rec['status']==('success' if expected['eligible'] else 'needs_clarification' if expected['unverified'] else 'no_match'),rec.get('error')
        assert rec['execution']['controller_mode']=='scripted' and rec['execution']['model_calls']==0
        assert rec['state']['source_count']==21431
        counts={'assessed':21431,**{g:len(v) for g,v in expected.items()}}
        assert env['presentation']['counts']==counts,(name,env['presentation']['counts'],counts)
        actual_ids=[c['listing']['listing_id'] for c in rec['recommendations']]
        assert actual_ids==[p[0] for p in expected['eligible'][:limit]],(name,actual_ids,expected['eligible'][:limit])
        assert [c['listing_id'] for c in rec['unverified_candidates']]==[p[0] for p in expected['unverified'][:4]]
        for c in rec['recommendations']:
            score=dict(expected['eligible'])[c['listing']['listing_id']]
            assert abs(c['scores']['combined_score']-score)<1e-9
        replay=client.post('/app/recommend',json=request);assert replay.json()['response']==rec
        changed=client.post('/app/recommend',json={**request,'result_limit':2 if limit!=2 else 3});assert changed.status_code==409
        report['cases'].append({'id':name,'status':'passed','counts':counts,'verified_ids':actual_ids,'unverified_ids':[c['listing_id'] for c in rec['unverified_candidates']],'elapsed_seconds':round(time.monotonic()-start,3),'immutable_replay':True,'body_conflict':409})
        print(name,'passed',counts,flush=True)
    assert client.post('/recommend',json=request,headers={'x-recommendation-token':'wrong-token'}).status_code==401
    assert client.post('/recommend',json={**request,'request_id':str(uuid.uuid4()),'result_limit':5}).status_code==422
    stale=client.post('/recommend',json={**request,'request_id':str(uuid.uuid4()),'previous_state_id':'nonexistent'}).json()
    assert stale['error']['code']=='STALE_REFERENCE'
    report['checks']=['Full canonical scan per case','Independent eligibility and unknown/excluded groups','Lexicographic stable tie order','Soft threshold exact scores','Unverified candidates preserve source order without score','Limit enforcement','Immutable replay','Changed-body conflict','Authentication rejection','Stale reference rejection','Controller scripted and model calls zero']
    report['status']='passed'
except Exception as e:
    report['status']='failed';report['error']=str(e);raise
finally:
    (BASE/'native-sql-acceptance.json').write_text(json.dumps(report,indent=2))
    client.close()
