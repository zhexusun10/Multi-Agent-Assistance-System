"""Execute the repository's eight retrieval tests without network or inference.

The production corpus and algorithms are used unchanged. Only the missing index
manifest is supplied as a temporary, corpus-derived fixture. The original two
outage tests supply their own vector mocks. No production index is published.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from datetime import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import socket
import sys
import tempfile
import time
from unittest.mock import patch


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(path: Path) -> dict:
    return {
        "exists": path.exists(),
        "files": {str(p.relative_to(path)): sha(p) for p in sorted(path.rglob("*")) if p.is_file()},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    repo, source, out = (p.resolve() for p in (args.repo, args.source, args.out))
    out.mkdir(parents=True, exist_ok=True)
    cache = out / "isolated-cache"
    cache.mkdir(exist_ok=True)
    os.environ.update({
        "TZ": "Asia/Shanghai", "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
        "HF_HOME": str(cache / "huggingface"),
        "HF_HUB_CACHE": str(cache / "huggingface" / "hub"),
        "FASTEMBED_CACHE_PATH": str(cache / "fastembed"),
        "ANONYMIZED_TELEMETRY": "False", "OTEL_SDK_DISABLED": "true",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTHONDONTWRITEBYTECODE": "1",
    })
    if hasattr(time, "tzset"):
        time.tzset()
    os.chdir(repo)
    sys.path.insert(0, str(repo))
    paths = sorted({
        *repo.joinpath("retrieval").glob("*.py"),
        *repo.joinpath("knowledge/rental").glob("*.md"),
        repo / "tests/test_retrieval.py",
    })
    before = {str(p.relative_to(repo)): sha(p) for p in paths}
    exact_source = all((source / name).is_file() and sha(source / name) == digest
                       for name, digest in before.items())
    if not exact_source:
        raise RuntimeError("Tested source differs from the immutable source snapshot")
    production_manifest = repo / "data/.runtime/knowledge-index.json"
    manifest_before = inventory(production_manifest) if production_manifest.is_dir() else {
        "exists": production_manifest.exists(),
        "sha256": sha(production_manifest) if production_manifest.exists() else None,
    }
    model_cache = repo / "data/.runtime/models"
    model_before = inventory(model_cache)
    calls = {"network": [], "embedding": [], "chroma_client": [], "onnx_session": []}
    results, stages, observations = [], [], []
    started = datetime.now().astimezone().isoformat()

    def blocked_network(*_args, **_kwargs):
        calls["network"].append({"event": "outbound connection or DNS attempted"})
        raise RuntimeError("OFFLINE_ACCEPTANCE_NETWORK_BLOCKED")

    def block(kind, label):
        def denied(*_args, **_kwargs):
            calls[kind].append({"event": label})
            raise RuntimeError("OFFLINE_ACCEPTANCE_INFERENCE_OR_SERVICE_BLOCKED: " + label)
        return denied

    active_test = {"id": None}

    class Recorder:
        def pytest_runtest_setup(self, item):
            active_test["id"] = item.nodeid

        def pytest_runtest_logreport(self, report):
            row = {"test_id": report.nodeid, "phase": report.when,
                   "outcome": report.outcome, "duration_seconds": report.duration}
            if report.failed:
                row["failure"] = str(report.longrepr)
            stages.append(row)
            if report.when == "call":
                results.append(row)

    with ExitStack() as stack:
        for obj, attr in [(socket.socket, "connect"), (socket.socket, "connect_ex"),
                          (socket, "create_connection"), (socket, "getaddrinfo")]:
            stack.enter_context(patch.object(obj, attr, blocked_network))
        import fastembed
        import onnxruntime
        import chromadb
        stack.enter_context(patch.object(fastembed.TextEmbedding, "__init__", block("embedding", "TextEmbedding.__init__")))
        stack.enter_context(patch.object(onnxruntime.InferenceSession, "__init__", block("onnx_session", "InferenceSession.__init__")))
        for attr in ["HttpClient", "Client", "PersistentClient", "EphemeralClient"]:
            if hasattr(chromadb, attr):
                stack.enter_context(patch.object(chromadb, attr, block("chroma_client", attr)))
        import retrieval.embeddings as embeddings
        stack.enter_context(patch.object(embeddings.Embeddings, "__call__", block("embedding", "EMBED.__call__")))
        import jieba
        # Jieba's local dictionary cache is lexical data, not model weights.
        jieba.dt.tmp_dir = str(cache)
        import pytest
        import retrieval.index as index
        import retrieval.hybrid as hybrid
        corpus = index.load_corpus()
        corpus_text = json.dumps(corpus, ensure_ascii=False, sort_keys=True, indent=2)
        (out / "retrieval-corpus-fixture.json").write_text(corpus_text, encoding="utf-8")
        with tempfile.TemporaryDirectory(prefix="group42-retrieval-") as tmp:
            fixture = Path(tmp) / "knowledge-index.json"
            fixture.write_text(corpus_text, encoding="utf-8")
            stack.enter_context(patch.object(hybrid, "MANIFEST", fixture))
            real_search = hybrid.search

            def observed_search(*args_, **kwargs_):
                response = real_search(*args_, **kwargs_)
                observations.append({
                    "test_id": active_test["id"], "queries": args_[0] if args_ else kwargs_.get("queries"),
                    "status": response.get("status"), "vector_enabled": response.get("vector_enabled"),
                    "bm25_enabled": response.get("bm25_enabled"), "degraded": response.get("degraded"),
                    "chunk_count": len(response.get("chunks", [])),
                    "document_ids": [c["document_id"] for c in response.get("chunks", [])],
                    "generation": response.get("generation"),
                })
                return response

            stack.enter_context(patch.object(hybrid, "search", observed_search))
            exit_code = pytest.main([
                "tests/test_retrieval.py", "-vv", "-p", "no:cacheprovider", "-o", "addopts=",
                "--junitxml=" + str(out / "retrieval-junit.xml"),
                "--basetemp=" + str(out / "pytest-tmp"),
            ], plugins=[Recorder()])
        fixture_removed = not fixture.exists()
    after = {str(p.relative_to(repo)): sha(p) for p in paths}
    manifest_after = {
        "exists": production_manifest.exists(),
        "sha256": sha(production_manifest) if production_manifest.is_file() else None,
    }
    model_after = inventory(model_cache)
    guards_clear = all(not values for values in calls.values())
    passed = sum(r["outcome"] == "passed" for r in results)
    all_passed = (exit_code == 0 and len(results) == 8 and passed == 8
                  and not any(r["outcome"] != "passed" for r in stages)
                  and guards_clear and before == after and model_before == model_after
                  and manifest_before == manifest_after and fixture_removed)
    report = {
        "status": "PASS" if all_passed else "FAIL",
        "profile": "original-retrieval-tests/offline-corpus-fixture-v1",
        "commit": "89131897f56bbc176c30246a451f118f7de0209f",
        "started_at": started, "finished_at": datetime.now().astimezone().isoformat(),
        "python": platform.python_version(), "platform": platform.platform(),
        "dependencies": {name: importlib.metadata.version(name) for name in
                         ["pytest", "chromadb", "numpy", "rank-bm25", "jieba", "fastembed", "onnxruntime", "posthog"]},
        "pytest_exit_code": int(exit_code), "passed": passed,
        "failed": sum(r["outcome"] == "failed" for r in stages),
        "skipped": sum(r["outcome"] == "skipped" for r in stages),
        "test_file": "tests/test_retrieval.py", "tests": results,
        "corpus": {"documents": len(corpus["documents"]), "chunks": len(corpus["chunks"]),
                   "generation": corpus["generation"], "fixture_sha256": sha(out / "retrieval-corpus-fixture.json"),
                   "review_dates": sorted({(d["checked_at"], d["review_after"]) for d in corpus["documents"]})},
        "fixture": {"derived_by": "unmodified retrieval.index.load_corpus()",
                    "override": "retrieval.hybrid.MANIFEST only, during execution",
                    "temporary_fixture_removed": fixture_removed,
                    "production_manifest_before": manifest_before, "production_manifest_after": manifest_after},
        "guards": {"network_blocked": True, "embedding_initialization_and_calls_blocked": True,
                   "chroma_clients_blocked": True, "onnx_sessions_blocked": True,
                   "attempts": calls, "all_attempt_counts_zero": guards_clear},
        "source": {"matches_immutable_snapshot": exact_source, "unchanged": before == after,
                   "files_sha256_before": before, "files_sha256_after": after},
        "production_model_cache": {"before": model_before, "after": model_after,
                                   "unchanged": model_before == model_after},
        "isolated_model_caches": {"huggingface": inventory(cache / "huggingface"),
                                  "fastembed": inventory(cache / "fastembed")},
        "degradation_observations": observations,
        "limitations": ["Vector outages are injected by the two original repository tests.",
                        "No live Chroma service, successful vector search, model download or inference.",
                        "Corpus metadata and algorithms were checked; policy content was not externally revalidated.",
                        "This result does not close live hybrid retrieval integration or final system acceptance."],
    }
    (out / "retrieval-acceptance.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "requirements-frozen.txt").write_text("\n".join(sorted(
        f"{d.metadata['Name']}=={d.version}" for d in importlib.metadata.distributions())) + "\n", encoding="utf-8")
    print("\nOFFLINE_GUARDED_RESULT=" + json.dumps({
        "status": report["status"], "passed": passed, "guards_clear": guards_clear,
        "documents": len(corpus["documents"]), "chunks": len(corpus["chunks"]),
        "source_unchanged": before == after, "production_manifest_unchanged": manifest_before == manifest_after,
    }))
    return 0 if all_passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
