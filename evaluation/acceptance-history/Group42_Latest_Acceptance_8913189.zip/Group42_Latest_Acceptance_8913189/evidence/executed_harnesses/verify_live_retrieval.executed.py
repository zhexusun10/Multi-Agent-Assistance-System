"""Read back real vectors and exercise the unmodified HTTP retrieval service."""
from datetime import datetime
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
import requests

BASE=Path(__file__).resolve().parent
ROOT=BASE/'runtime'
sys.path.insert(0,str(ROOT))
from retrieval.chroma_store import client
from retrieval.embeddings import EMBED, MODEL
from retrieval.index import MANIFEST

report={'started_at':datetime.now().astimezone().isoformat(),
        'commit':'89131897f56bbc176c30246a451f118f7de0209f',
        'profile':'real-local-chroma-0.5.23-and-fastembed-0.7.4',
        'mocked_retrieval':False,'chat_model_used':False,'checks':[]}

def check(name,condition,observed):
    report['checks'].append({'check':name,'status':'PASS' if condition else 'FAIL','observed':observed})

corpus=json.loads(MANIFEST.read_text())
collection=client().get_collection(corpus['collection'],embedding_function=EMBED)
stored=collection.get(include=['embeddings'])
vectors=np.asarray(stored['embeddings'],dtype=np.float64)
norms=np.linalg.norm(vectors,axis=1)
check('Complete published generation and exact IDs',
      set(stored['ids'])=={r['id'] for r in corpus['chunks']} and collection.metadata.get('generation')==corpus['generation'],
      {'expected':len(corpus['chunks']),'stored':len(stored['ids']),'generation':corpus['generation']})
check('Real finite normalized embeddings',vectors.shape==(40,384) and bool(np.isfinite(vectors).all()) and bool(np.allclose(norms,1,atol=1e-4)),
      {'shape':list(vectors.shape),'min_norm':float(norms.min()),'max_norm':float(norms.max())})
origin='http://127.0.0.1:18091'
health=requests.get(origin+'/health',timeout=15)
h=health.json()
check('HTTP health and both indexed corpora',health.status_code==200 and h.get('knowledge_documents')==8 and h.get('knowledge_chunks')==40 and h.get('intent_templates')==42,h)

queries=[('印花税税率','stamp-duty'),('押金退还条件','tenancy-terms'),
         ('HDB房间最短租期','hdb-rental'),('普通私人住宅最短租期','private-rental'),
         ('复制草稿是不是已经发出去了','system-followup'),
         ('What should I clarify about the security deposit refund?','tenancy-terms')]
searches=[]
for query,expected in queries:
    started=time.perf_counter()
    response=requests.post(origin+'/search',json={'queries':[query],'top_k':5},timeout=30)
    data=response.json()
    documents=[c.get('document_id') for c in data.get('chunks',[])]
    valid=(response.status_code==200 and data.get('vector_enabled') is True and data.get('bm25_enabled') is True
           and data.get('degraded')==[] and expected in documents
           and bool(data.get('channel_rankings',{}).get('vector')) and bool(data.get('channel_rankings',{}).get('bm25')))
    check('HTTP search: '+query,valid,{'http_status':response.status_code,'expected_document':expected,
          'document_ids':documents,'vector_enabled':data.get('vector_enabled'),'bm25_enabled':data.get('bm25_enabled'),
          'degraded':data.get('degraded'),'latency_ms':round((time.perf_counter()-started)*1000)})
    searches.append({'query':query,'expected_document':expected,'response':data})

templates=json.loads((ROOT/'data/.runtime/intent-templates.json').read_text())
intents=[('我想看第一套，帮我约明天下午看房','arrange_viewing'),
         ('公寓租约的印花税怎么算，押金一般怎么约定','rental_knowledge'),
         ('Has my message to the salesperson been sent?','followup_status')]
intent_results=[]
for query,expected in intents:
    response=requests.post(origin+'/intent-match',json={'query':query,'template_version':templates['version']},timeout=30)
    data=response.json()
    check('HTTP intent template smoke: '+expected,response.status_code==200 and data.get('intent')==expected and data.get('confidence',0)>.99,data)
    intent_results.append({'query':query,'expected_intent':expected,'response':data})
for path,payload,expected in [
    ('/search',{'queries':['   ']},422),('/search',{'queries':['x'*8001]},422),
    ('/search',{'queries':['押金'],'top_k':21},422),
    ('/intent-match',{'query':'看房','template_version':'wrong-version'},409),
]:
    response=requests.post(origin+path,json=payload,timeout=15)
    check('HTTP input/version rejection: '+path+' '+str(expected),response.status_code==expected,{'http_status':response.status_code,'expected':expected})

ablation=json.loads((ROOT/'evaluation/reports/rag-retrieval.json').read_text())
check('Original 40-query retrieval evaluation',ablation['cases']==40 and ablation['metrics']['fused']['section_recall_at_5']>=.90
      and all(not row['degraded'] for row in ablation['rows']),{'cases':ablation['cases'],'metrics':ablation['metrics']})
source=json.loads((BASE/'live-source-provenance.json').read_text())
unchanged=all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==value for name,value in source['files_sha256'].items())
check('Pinned retrieval source unchanged',unchanged,{'files_checked':len(source['files_sha256'])})

weights=[]
for p in sorted((ROOT/'data/.runtime/models').rglob('*')):
    if p.is_file() and not p.name.endswith('.lock') and '.cache' not in p.parts and '.locks' not in p.parts:
        weights.append({'path':str(p.relative_to(ROOT/'data/.runtime/models')),'bytes':p.stat().st_size,
                        'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report.update({'status':'PASS' if all(c['status']=='PASS' for c in report['checks']) else 'FAIL',
    'passed':sum(c['status']=='PASS' for c in report['checks']),'failed':sum(c['status']=='FAIL' for c in report['checks']),
    'embedding_model':MODEL,'generation':corpus['generation'],'documents':8,'chunks':40,'intent_templates':42,
    'retrieval_metrics':ablation['metrics'],'http_searches':searches,'http_intent_smokes':intent_results,
    'model_files':weights,'client_dependencies':{name:importlib.metadata.version(name) for name in ['chromadb','fastembed','numpy','rank-bm25','jieba','onnxruntime']},
    'server_dependencies':{'chromadb':'0.5.23','fastapi':'0.115.9','starlette':'0.45.3','hosting':'native macOS loopback process'},
    'finished_at':datetime.now().astimezone().isoformat(),
    'limitations':['The 40 labelled retrieval questions are the repository evaluation set, not an independent holdout.',
                   'The three intent queries match indexed templates and prove plumbing only, not intent classification accuracy.',
                   'Latency observations are not a capacity or concurrency benchmark.',
                   'No chat model answer was assessed; Cline model access was blocked by insufficient credits.']})
(BASE/'live-retrieval-acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'status':report['status'],'passed':report['passed'],'failed':report['failed'],
                  'retrieval_metrics':ablation['metrics']},indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
