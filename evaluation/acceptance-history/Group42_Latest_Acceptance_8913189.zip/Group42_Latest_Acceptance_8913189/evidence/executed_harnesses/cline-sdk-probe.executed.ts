import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {createModel} from './src/model.js';

const started = performance.now();
let result: Record<string, unknown>;
try {
  const model = await createModel(undefined, {maxTokens: 128, temperature: 0});
  const answer = await model.invoke('Reply with exactly G42_MODEL_OK and nothing else.', {signal: AbortSignal.timeout(45000)});
  result = {status: answer.text.trim() === 'G42_MODEL_OK' ? 'PASS' : 'FAIL',
    profile: process.env.G42_CLINE_NONTHINKING === '1' ? 'explicit_nonthinking' : 'repository_default',
    text: answer.text, usage: answer.usage_metadata, response_metadata: answer.response_metadata,
    latency_ms: Math.round(performance.now() - started)};
} catch (error) {
  result = {status: 'FAIL', profile: process.env.G42_CLINE_NONTHINKING === '1' ? 'explicit_nonthinking' : 'repository_default',
    error_type: error instanceof Error ? error.name : 'unknown', latency_ms: Math.round(performance.now() - started)};
}
await writeFile(process.env.G42_SDK_RESULT || '../cline-sdk-smoke.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
assert.equal(result.status, 'PASS');
