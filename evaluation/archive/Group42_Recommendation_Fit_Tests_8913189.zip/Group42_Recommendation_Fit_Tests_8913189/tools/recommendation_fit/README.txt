REPRODUCING RECOMMENDATION FIT TESTS
Use pinned source 89131897f56bbc176c30246a451f118f7de0209f and the verified full historical snapshot. Keep a dedicated QA workflow PostgreSQL database, separate native state and EXTERNAL_ACTION_MODE=simulation. Follow the main README and tools/extended/README.txt for dependencies, data import, provider adapter, private credentials and retained Chroma/MiniLM setup.

These exact executed external harnesses preserve sibling paths. Place the application checkout at .build/qa_live_cline_8913189/runtime, the provider adapter at .build/qa_live_cline_8913189/cline-pass-transport.mjs, and this folder's contents at .build/qa_recommendation_fit_8913189. Provide node_modules there pointing to the checkout's Node dependencies. Keep the frozen catalogue/hash unchanged.

The Python QA environment needs the project's requirements plus psycopg2, neo4j, httpx, python-dotenv and SQLAlchemy. From the project workspace root:
python .build/qa_recommendation_fit_8913189/run_structured.py
This invokes the original recommendation.app.execute function with a scripted controller and isolated in-memory state, reads the real data sources and records all 24 cases. It sets the mode only in that test process. It also produces projection-native-fixture.json, consumed by the next harness.

From the runtime checkout:
node --env-file=.env --import tsx ../../qa_recommendation_fit_8913189/run_projection.ts
No model call is needed for these eight projection cases.

For the 12 deployed persona turns, first start healthy QA services with the real ClinePass profile and verified data. Start Chroma and wait for heartbeat before retrieval. Use the supplied private env file and the nonthinking provider transport for graph/native processes. services.py preserves the observed Python environment paths and ports; adapt launcher paths only if recreating the same profile on another machine. Then run:
python .build/qa_recommendation_fit_8913189/run_natural.py
from the workspace root. It creates fresh owned sessions and waits for PostgreSQL domain-operation completion; an SSE acknowledgement does not count as completion. It retains every failed case and does not alter expectations or retry solely to seek a pass.

diagnose_intake.ts runs four read-only parser probes and makes no model calls. User_Relevance_Review_Template.json is a separate NOT_RUN human form; do not populate it with model-generated participant ratings.

Every rerun should have a new receipt location and audit file, declared model/configuration and immutable baseline. These harnesses are environment snapshots rather than a self-contained application deployment package. No production source fix is included.
