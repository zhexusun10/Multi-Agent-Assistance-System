RECOMMENDATION FIT EXECUTION RECEIPTS
Version 3.5. Pinned source 89131897f56bbc176c30246a451f118f7de0209f.

The 44 frozen cases comprise 24 structured matching scenarios (24 PASS), eight projection checks (eight PASS) and 12 deployed persona turns (four PASS, eight FAIL). Six cross-case relations and four read-only parser probes support triage and are not added to the case count. The primary acceptance decision remains PENDING.

Structured tests execute the unchanged production Python service in process, with real read-only PostgreSQL and Neo4j sources, a scripted controller and in-memory QA state. The independent oracle imports no production validation/ranking module and calculates full groups, exact IDs, scores and evidence coverage. Sixty-four verified recommendation occurrences satisfy structured hard criteria. These tests isolate the algorithm from natural-language interpretation; they make zero chat calls.

Projection tests reuse the RF01 actual native database response and execute the production TypeScript adapter. Seven hard unsupported criteria yield pending candidates; the soft unsupported criterion stays visible without excluding hard matches. They are eight adapter scenarios rather than eight independent searches.

Natural cases execute the public loopback API with real ClinePass model calls, a live native controller, retrieval and full data. Four authored personas have three sequential turns each. Eight failures are grouped as DEF09 to DEF12; later turns may inherit earlier errors. Two completed family turns display six verified recommendation occurrences with one or two bedrooms despite the user's at-least-three-bedroom requirement. RN06 keeps the wrong operator although its prefix happens to meet the minimum. Failed turns may retain an older UI recommendation; such stale observations are excluded from the 20-occurrence denominator.

RN07/RN08 retain distance words inside NUS destination names and leave unresolved location questions. RN10 stores a soft district as hard and also produces a native LOOP_EXHAUSTED error after eight model turns. The exact error response is retained separately; the loop failure is not assumed to have only one cause. RN12 has two correctly evidenced model removal proposals that the code rejects. Original failing receipts and unchanged assertions are preserved.

The request audit reconciles 72 actual API attempts and 72 HTTP 200 model responses. Business failures remain failures. Reported usage is 192,852 tokens; reference cost USD 0.015158118 is not a subscription invoice or verified extra charge. No provider key or header is exported.

The initial retrieval process started before Chroma was ready and exited; it was restarted after Chroma readiness before any case ran. This setup ordering incident is not a case failure. All six owned services and the QA database containers were stopped after execution. Large SQLite trace pools, credentials and dependency/model files are excluded. Reproduction prerequisites and commands are in tools/recommendation_fit/README.txt.
