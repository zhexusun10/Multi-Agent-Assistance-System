"""Actual deployed model workflow, frozen persona turns, independent expectation oracle."""
from datetime import datetime
import hashlib,json,time,uuid
from pathlib import Path
import httpx,psycopg2
from dotenv import dotenv_values
from oracle import Oracle
B=Path(__file__).resolve().parent;R=B.parent/'qa_live_cline_8913189/runtime'
settings=dotenv_values(R/'.env');catalog_bytes=(B/'frozen-fit-cases.json').read_bytes()
fingerprint=hashlib.sha256(catalog_bytes).hexdigest();assert fingerprint==(B/'frozen-fit-cases.sha256').read_text().strip()
catalog=json.loads(catalog_bytes);oracle=Oracle();client=httpx.Client(timeout=180,trust_env=False)
sessions={};rows=[]
def criterion_matches(actual,expected):
 return all(actual.get(k)==expected.get(k) for k in ['field','operator','value','strength']) and (not expected.get('target_id') or actual.get('target',{}).get('place_id')==expected['target_id']) and (expected['field']!='place_proximity' or actual.get('distance_type')=='straight_line')
def oracle_criterion(c):
 d={**c,'field':{'district':'district_code','place_proximity':'distance','current_availability':'availability'}.get(c['field'],c['field'])}
 if c.get('target_id'):d.update(destination_id=c['target_id'],distance_type='straight_line')
 return d
try:
 for case in catalog['natural']:
  start=time.monotonic();profile=case['profile'];error=None;checks={};state={};op=None;exchange=None
  try:
   if profile not in sessions:
    owner=uuid.uuid4().hex+uuid.uuid4().hex;headers={'authorization':'Bearer '+owner,'content-type':'application/json'}
    created=client.post('http://127.0.0.1:8010/api/sessions',headers=headers,json={});created.raise_for_status()
    sessions[profile]={'id':created.json()['session_id'],'headers':headers}
   session=sessions[profile];headers=session['headers'];sid=session['id']
   previous=client.get('http://127.0.0.1:8010/api/state',headers=headers,params={'session_id':sid});previous.raise_for_status();previous=previous.json()
   rid=str(uuid.uuid4());body={'session_id':sid,'request_id':rid,'query':case['query']}
   if previous.get('latest_request_id'):body['source_request_id']=previous['latest_request_id']
   answer=client.post('http://127.0.0.1:8010/api/query',headers=headers,json=body);answer.raise_for_status()
   conn=psycopg2.connect(settings['DATABASE_URL']);conn.autocommit=True
   try:
    deadline=time.monotonic()+180
    while time.monotonic()<deadline:
     with conn.cursor() as cur:
      cur.execute('SELECT status,kind FROM domain_operations WHERE session_id=%s AND request_id=%s',(sid,rid));op=cur.fetchone()
     if op and op[0] in ['completed','failed','superseded']:break
     time.sleep(.2)
    else:raise TimeoutError('Operation not terminal')
   finally:conn.close()
   state=client.get('http://127.0.0.1:8010/api/state',headers=headers,params={'session_id':sid}).json()
   actual_criteria=state['requirements']['criteria'];rec=state.get('recommendation');pending=state.get('pending')
   checks['operation_completed']=op[0]=='completed';checks['search_route']=op[1]=='search'
   checks['no_unexpected_clarification']=not pending
   checks['expected_criteria_retained']=all(any(criterion_matches(a,e) for a in actual_criteria) for e in case['expected_criteria'])
   checks['cancelled_fields_removed']=all(not any(a['field']==f for a in actual_criteria) for f in case['absent_fields'])
   expected_hard=[e for e in case['expected_criteria'] if e['strength']=='hard']
   checks['no_unauthorized_hard_constraints']=all(any(criterion_matches(a,e) for e in expected_hard) for a in actual_criteria if a['strength']=='hard')
   checks['recommendation_present']=rec is not None
   expected_native=[oracle_criterion(c) for c in case['expected_criteria']]
   independent=oracle.assess(expected_native)
   verified=rec.get('recommendations',[]) if rec else []
   checks['user_hard_constraints_satisfied']=all(all(oracle.outcome(oracle.by_id[item['listing']['listing_id']],c)=='pass' for c in expected_native if c['strength']=='hard') for item in verified)
   unknown_hard=any(c['field'] not in ['price','bedrooms','floor_area_sqft','district_code','property_type','distance'] for c in expected_native if c['strength']=='hard')
   checks['unknown_hard_not_verified']=not verified if unknown_hard else True
   checks['known_satisfying_results_returned']=bool(verified) if independent['groups']['eligible'] else not verified
   checks['source_fields_match_sql']=all(all(item['listing'].get(f)==oracle.by_id[item['listing']['listing_id']].get({'district':'district_code'}.get(f,f)) for f in ['price','bedrooms','district','floor_area_sqft','property_type']) for item in verified)
   if rec and rec.get('native'):
    ref=rec['native']['exchange_ref'];receipt=client.get('http://127.0.0.1:8010/api/evidence',headers=headers,params={'session_id':sid,'ref':ref});receipt.raise_for_status();exchange=receipt.json()['data']
    actual_native=exchange['request']['requirements']['criteria'];expected_actual=oracle.assess(actual_native)
    checks['native_top_k_matches_independent_oracle']=[i['listing']['listing_id'] for i in exchange['response']['recommendations']]==expected_actual['groups']['eligible'][:4]
    checks['live_native_controller']=exchange['response']['execution']['controller_mode']=='live' and exchange['response']['execution']['model_calls']>0
   else:checks['live_native_controller']=False;checks['native_top_k_matches_independent_oracle']=False
  except Exception as exc:error=type(exc).__name__;checks['execution']=False
  clean_state={k:state.get(k) for k in ['requirements','requirements_version','pending','recommendation','latest_request_id']}
  if state.get('messages'):clean_state['last_message']=state['messages'][-1]
  row={'id':case['id'],'persona':case['persona'],'profile':case['profile'],'turn':case['turn'],'query':case['query'],
   'expected_criteria':case['expected_criteria'],'absent_fields':case['absent_fields'],'status':'PASS' if checks and all(checks.values()) else 'FAIL',
   'checks':checks,'operation':{'status':op[0],'kind':op[1]} if op else None,
   'state':clean_state,'native_exchange':exchange,'error_type':error,'latency_ms':round((time.monotonic()-start)*1000)}
  rows.append(row);(B/'natural-result.partial.json').write_text(json.dumps({'catalog_sha256':fingerprint,'rows':rows},indent=2,ensure_ascii=False))
  print(case['id'],row['status'],row['latency_ms'],'ms',[k for k,v in checks.items() if not v],flush=True)
finally:client.close()
report={'status':'PASS' if len(rows)==12 and all(r['status']=='PASS' for r in rows) else 'FAIL','catalog_sha256':fingerprint,
 'profile':'Actual deployed API; real ClinePass DeepSeek model, live native controller, full data and real retrieval',
 'cases':len(rows),'passed':sum(r['status']=='PASS' for r in rows),'failed':sum(r['status']=='FAIL' for r in rows),
 'participant_uat':False,'rows':rows,'completed_at':datetime.now().astimezone().isoformat()}
(B/'natural-result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
