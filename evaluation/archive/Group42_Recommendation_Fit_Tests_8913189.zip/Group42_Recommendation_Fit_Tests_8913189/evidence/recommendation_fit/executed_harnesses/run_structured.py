"""Run unchanged production recommendation service, real databases, scripted tools."""
import gc,hashlib,json,os,sys,time,uuid
from datetime import datetime
from pathlib import Path
from dotenv import dotenv_values
from oracle import Oracle
B=Path(__file__).resolve().parent;R=B.parent/'qa_live_cline_8913189/runtime'
sys.path.insert(0,str(R));os.environ.update({k:v for k,v in dotenv_values(R/'.env').items() if v is not None})
from recommendation.app import execute
from recommendation.contracts.request import RecommendationRequest
os.environ['RECOMMENDATION_CONTROLLER']='scripted';os.environ['RECOMMENDATION_STATE_PATH']=':memory:'
frozen=(B/'frozen-fit-cases.json').read_bytes();fingerprint=hashlib.sha256(frozen).hexdigest()
assert fingerprint==(B/'frozen-fit-cases.sha256').read_text().strip()
catalog=json.loads(frozen);oracle=Oracle();rows=[];expected_all={}
for case in catalog['structured']:
 start=time.monotonic();request={'contract_version':'1.0','request_id':str(uuid.uuid4()),'conversation_id':str(uuid.uuid4()),'requirements_version':1,'requirements':{'listing_type':'RENT','criteria':case['criteria']},'result_limit':case['limit']}
 expected=oracle.assess(case['criteria']);expected_all[case['id']]=expected
 checks={};env=None;error=None
 try:
  env=execute(RecommendationRequest.model_validate(request),True);actual=env['response'];items=actual['recommendations']
  checks={'status':actual['status']==('success' if expected['groups']['eligible'] else 'needs_clarification' if expected['groups']['unverified'] else 'no_match'),
   'full_count':actual['state']['source_count']==21431,'counts':env['presentation']['counts']==expected['counts'],
   'exact_top_k':[x['listing']['listing_id'] for x in items]==expected['groups']['eligible'][:case['limit']],
   'unverified_ids':[x['listing_id'] for x in actual['unverified_candidates']]==expected['groups']['unverified'][:4],
   'all_hard_constraints':all(oracle.outcome(oracle.by_id[x['listing']['listing_id']],c)=='pass' for x in items for c in case['criteria'] if c['strength']=='hard'),
   'scores':all(abs(x['scores']['combined_score']-expected['scores'][x['listing']['listing_id']])<1e-9 for x in items),
   'evidence_coverage':all(abs(x['scores']['evidence_coverage']-expected['coverage'][x['listing']['listing_id']])<1e-9 for x in items),
   'zero_model_calls':actual['execution']['model_calls']==0 and actual['execution']['controller_mode']=='scripted',
   'canonical_listing_values':all(all(x['listing'][f]==oracle.by_id[x['listing']['listing_id']][f] for f in ['price','bedrooms','floor_area_sqft','district_code','property_type']) for x in items)}
  if case['id']=='RF01':(B/'projection-native-fixture.json').write_text(json.dumps(env,indent=2))
 except Exception as exc:error=type(exc).__name__;checks['execution']=False
 row={'id':case['id'],'name':case['name'],'status':'PASS' if all(checks.values()) and checks else 'FAIL','checks':checks,
  'expected_counts':expected['counts'],'expected_verified_ids':expected['groups']['eligible'][:case['limit']],
  'request':request,'envelope':env,'error_type':error,'latency_ms':round((time.monotonic()-start)*1000)}
 rows.append(row);(B/'structured-result.partial.json').write_text(json.dumps({'rows':rows},indent=2))
 print(case['id'],row['status'],row['latency_ms'],'ms', [k for k,v in checks.items() if not v],flush=True);gc.collect()
comparisons={
 'exact_rent_is_subset_of_budget':set(expected_all['RF02']['groups']['eligible'])<=set(expected_all['RF01']['groups']['eligible']),
 'smaller_radius_is_subset':set(expected_all['RF14']['groups']['eligible'])<=set(expected_all['RF15']['groups']['eligible']),
 'impossible_budget_no_verified':next(x for x in rows if x['id']=='RF17')['envelope']['response']['recommendations']==[],
 'district_priority_reversal_changes_recommendations':next(x for x in rows if x['id']=='RF20')['envelope']['response']['recommendations'][0]['listing']['district_code']=='D05' and next(x for x in rows if x['id']=='RF21')['envelope']['response']['recommendations'][0]['listing']['district_code']=='D10',
 'negative_bedrooms_not_verified':all(x['listing']['bedrooms'] is not None and x['listing']['bedrooms']>=0 for x in next(x for x in rows if x['id']=='RF19')['envelope']['response']['recommendations']),
 'unknown_soft_preference_not_perfect_fit':all(x['scores']['evidence_coverage']<1 and x['scores']['combined_score']<1 for x in next(x for x in rows if x['id']=='RF24')['envelope']['response']['recommendations']),
}
(B/'oracle-case-results.json').write_text(json.dumps(expected_all,indent=2))
report={'status':'PASS' if all(r['status']=='PASS' for r in rows) and all(comparisons.values()) else 'FAIL','catalog_sha256':fingerprint,
 'profile':'Unchanged production service in process; real PostgreSQL/Neo4j; scripted controller; in-memory QA state',
 'cases':len(rows),'passed':sum(r['status']=='PASS' for r in rows),'failed':sum(r['status']=='FAIL' for r in rows),'real_model_calls':0,
 'cross_case_checks':comparisons,'rows':rows,'completed_at':datetime.now().astimezone().isoformat()}
(B/'structured-result.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
