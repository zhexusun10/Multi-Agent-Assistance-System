from pathlib import Path
from datetime import datetime
import hashlib,json
B=Path(__file__).resolve().parent
def c(id,field,value,operator='lte',strength='hard',**kw):
 d={'criterion_id':id,'field':field,'operator':operator,'value':value,'strength':strength,**kw}
 if field in {'price':'SGD/month','floor_area_sqft':'sqft','distance':'m','commute':'minutes','lease_months':'months'}:d['unit']={'price':'SGD/month','floor_area_sqft':'sqft','distance':'m','commute':'minutes','lease_months':'months'}[field]
 return d
def budget(n):return c('budget','price',n)
def bed(n):return c('beds','bedrooms',n,'gte')
def geo(n,**kw):return c('radius','distance',n,destination_id='OSM:way:54519165',distance_type='straight_line',**kw)
raw=[
 ('Budget cap for a cost-sensitive renter',[budget(1800)]),
 ('Exact SGD 1800 rent boundary',[c('exact-rent','price',1800,'eq')]),
 ('Rent within inclusive SGD 1500 to 2000',[c('rent-range','price',[1500,2000],'between')]),
 ('Exactly one bedroom within SGD 2200',[budget(2200),c('beds','bedrooms',1,'eq')]),
 ('Family needs at least three bedrooms within SGD 6000',[budget(6000),bed(3)]),
 ('Space requirement at least 1000 sqft within SGD 6000',[budget(6000),c('area','floor_area_sqft',1000,'gte')]),
 ('Accept D05 or D10 within SGD 4500',[budget(4500),c('district','district_code',['D05','D10'],'in')]),
 ('Accept condominium or apartment within SGD 4000',[budget(4000),c('type','property_type',['condominium','apartment'],'in')]),
 ('Required furnishing must remain unverified',[budget(2000),c('furnished','furnishing','fully_furnished','eq')]),
 ('Required six-month lease must remain unverified',[budget(2000),c('lease','lease_months',6,'eq')]),
 ('Current vacancy must remain unverified',[budget(2000),c('availability','availability','available','eq')]),
 ('Thirty-minute transit commute cannot use straight-line evidence',[budget(3000),c('commute','commute',30,destination_id='OSM:way:54519165',distance_type='transit',transport_mode='transit')]),
 ('One-kilometre walking limit cannot use straight-line evidence',[budget(3000),c('walking','distance',1000,destination_id='OSM:way:54519165',distance_type='walking')]),
 ('NUS two-kilometre hard radius and nearer-first preference',[budget(3000),geo(2000),c('near','distance',1000,strength='soft',weight=1,utility='proximity',destination_id='OSM:way:54519165',distance_type='straight_line')]),
 ('NUS three-kilometre hard radius and nearer-first preference',[budget(3000),geo(3000),c('near','distance',1000,strength='soft',weight=1,utility='proximity',destination_id='OSM:way:54519165',distance_type='straight_line')]),
 ('Unresolvable destination must not be guessed',[budget(2000),c('missing-place','distance',1000,destination_id='QA:NONEXISTENT:FIT',distance_type='straight_line')]),
 ('Impossible SGD 1 budget must not be silently relaxed',[budget(1)]),
 ('Impossible twenty-bedroom low-budget request',[budget(2000),bed(20)]),
 ('Negative bedroom sentinels remain unknown',[budget(2000),bed(0)]),
 ('Prefer D05 three times as much as D10',[budget(2500),c('district-allowed','district_code',['D05','D10'],'in'),c('prefer-d05','district_code','D05','eq','soft',weight=3),c('prefer-d10','district_code','D10','eq','soft',weight=1)]),
 ('Reverse relative district priorities',[budget(2500),c('district-allowed','district_code',['D05','D10'],'in'),c('prefer-d05','district_code','D05','eq','soft',weight=1),c('prefer-d10','district_code','D10','eq','soft',weight=3)]),
 ('Cheaper-first numeric utility under a hard budget',[budget(3500),c('cheaper','price',3500,strength='soft',weight=1,utility='minimize')]),
 ('Larger-first numeric utility with family constraints',[budget(4000),bed(2),c('larger','floor_area_sqft',0,'gte','soft',weight=1,utility='maximize')]),
 ('Unknown furnishing preference has partial evidence coverage',[budget(2000),c('cheap-preference','price',1500,strength='soft',weight=1),c('furnished-preference','furnishing','fully_furnished','eq','soft',weight=1)]),
]
structured=[{'id':f'RF{i:02}','name':name,'criteria':criteria,'limit':4} for i,(name,criteria) in enumerate(raw,1)]
projection=[
 ('Private bathroom is an unsupported hard requirement',{'field':'amenities','operator':'eq','value':'private_bathroom','strength':'hard'}),
 ('Bathroom count is not silently proved',{'field':'bathrooms','operator':'gte','value':1,'unit':'count','strength':'hard'}),
 ('Whole-unit rental scope is not inferred',{'field':'rental_scope','operator':'eq','value':'whole_unit','strength':'hard'}),
 ('Move-in date is not inferred from historical listing',{'field':'move_in_date','operator':'lte','value':'2026-12-01','strength':'hard'}),
 ('MRT walking minutes are not inferred from coordinates',{'field':'mrt_walking_mins','operator':'lte','value':10,'unit':'min','distance_type':'platform_reported','strength':'hard'}),
 ('Pet permission is not invented',{'field':'amenities','operator':'eq','value':'pets_allowed','strength':'hard'}),
 ('Unsupported native postal criterion stays unverified',{'field':'postal_code','operator':'eq','value':'119077','strength':'hard'}),
 ('Unknown soft private-bathroom preference does not exclude hard matches',{'field':'amenities','operator':'eq','value':'private_bathroom','strength':'soft','weight':1}),
]
projection=[{'id':f'RP{i:02}','name':name,'extra_criterion':{'criterion_id':'extra-fit',**criterion},'native_fixture':'RF01'} for i,(name,criterion) in enumerate(projection,1)]
def e(field,value,operator='lte',strength='hard',**extra):return {'field':field,'value':value,'operator':operator,'strength':strength,**extra}
profiles=[
 ('Student budget and evidence limits',[
  ('帮我找租房，月租不超过2000新币，D05，至少1个卧室。',[e('price',2000),e('district','D05','eq'),e('bedrooms',1,'gte')],[]),
  ('预算降低到1800新币，其余条件保持不变。',[e('price',1800),e('district','D05','eq'),e('bedrooms',1,'gte')],[]),
  ('独立卫浴必须有，其他条件不变。',[e('price',1800),e('district','D05','eq'),e('bedrooms',1,'gte'),e('amenities','private_bathroom','eq')],[])]),
 ('Family English refinement and space',[
  ('Find rental properties in D10 with at least 3 bedrooms and monthly rent no more than SGD 6500.',[e('price',6500),e('district','D10','eq'),e('bedrooms',3,'gte')],[]),
  ('Change the district to D15 and keep the budget and bedroom requirement.',[e('price',6500),e('district','D15','eq'),e('bedrooms',3,'gte')],[]),
  ('Also require at least 1200 sqft of floor area.',[e('price',6500),e('district','D15','eq'),e('bedrooms',3,'gte'),e('floor_area_sqft',1200,'gte')],[])]),
 ('NUS radius and unsupported furnishing/lease',[
  ('找NUS国立大学直线距离3公里内的出租房，月租不超过3000新币。',[e('price',3000),e('place_proximity',3000,target_id='OSM:way:54519165')],[]),
  ('到NUS国立大学的直线距离改为2公里，预算不变。',[e('price',3000),e('place_proximity',2000,target_id='OSM:way:54519165')],[]),
  ('还必须带齐家具，租期为6个月。',[e('price',3000),e('place_proximity',2000,target_id='OSM:way:54519165'),e('furnishing','fully_furnished','eq'),e('lease_months',6,'eq')],[])]),
 ('Soft-to-hard district and explicit cancellation',[
  ('请找月租不超过2500新币，至少2房，优先D05，但其他邮区也可以。',[e('price',2500),e('bedrooms',2,'gte'),e('district','D05','eq','soft')],[]),
  ('现在D05必须满足，预算和卧室数量不变。',[e('price',2500),e('bedrooms',2,'gte'),e('district','D05','eq')],[]),
  ('取消邮区限制，其他条件不变。',[e('price',2500),e('bedrooms',2,'gte')],['district'])]),
]
natural=[]
for pi,(persona,turns) in enumerate(profiles,1):
 for ti,(query,expected,absent) in enumerate(turns,1):natural.append({'id':f'RN{len(natural)+1:02}','persona':persona,'profile':pi,'turn':ti,'query':query,'expected_criteria':expected,'absent_fields':absent})
catalog={'frozen_at':datetime.now().astimezone().isoformat(),'baseline_commit':'89131897f56bbc176c30246a451f118f7de0209f',
 'scope':'Recommendation alignment to explicit requirements, preference weights, unknown evidence and refinements. Human satisfaction is not inferred.',
 'structured':structured,'projection':projection,'natural':natural,
 'criteria_rules':'Freeze before execution. Compare full eligible/unknown/excluded counts and exact top four IDs with independent full SQL/Neo4j oracle. All verified hard constraints must pass; unsupported hard requirements cannot be presented as verified.',
 'natural_rules':'Each deployed turn must complete, retain every expected criterion with value/operator/strength, remove cancelled fields, and recommend only independently hard-satisfying listings. Unknown hard criteria require zero verified recommendations. Added hard constraints not authorized by the case also fail.',
 'limitations':'Authored project-contract tests, not participant relevance labels. Source snapshot does not prove present vacancy, viewing approval or subjective satisfaction.'}
p=B/'frozen-fit-cases.json';p.write_text(json.dumps(catalog,indent=2,ensure_ascii=False));(B/'frozen-fit-cases.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'\n')
print('Frozen 24 structured cases, 8 evidence-projection cases and 12 deployed natural-language turns before execution.')
