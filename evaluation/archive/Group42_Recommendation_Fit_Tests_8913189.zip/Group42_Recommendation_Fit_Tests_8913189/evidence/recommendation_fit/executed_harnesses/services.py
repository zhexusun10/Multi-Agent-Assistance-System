"""Start and stop only the processes owned by this extended QA run."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from dotenv import dotenv_values

B=Path(__file__).resolve().parent
L=B.parent/'qa_live_cline_8913189'
R=L/'runtime'
registry=B/'service-pids.json'
records=json.loads(registry.read_text()) if registry.exists() else {}
action,name=sys.argv[1:3]
if action=='stop':
    pid=records.get(name,{}).get('pid')
    if pid:
        try:os.killpg(pid,signal.SIGTERM)
        except ProcessLookupError:pass
    records.pop(name,None);registry.write_text(json.dumps(records,indent=2))
    print('Stopped owned service '+name);raise SystemExit()
env=dict(os.environ);env.update({k:v for k,v in dotenv_values(R/'.env').items() if v is not None})
env.update(ANONYMIZED_TELEMETRY='False',OTEL_SDK_DISABLED='true',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',CHROMA_HOST='127.0.0.1',CHROMA_PORT='18002')
python=B.parent/'qa_repo_v2/python/bin/python'
retrieval_python=B.parent/'qa_retrieval_8913189/python/bin/python'
if name=='chroma':
    env['PYTHONPATH']=str(L/'chroma-server-deps')
    command=[str(retrieval_python.parent/'chroma'),'run','--host','127.0.0.1','--port','18002','--path',str(L/'chroma-data')]
elif name=='retrieval':command=[str(retrieval_python),'-m','uvicorn','retrieval.app:app','--host','127.0.0.1','--port','18091']
elif name=='graph':
    env.update(G42_CLINE_NONTHINKING='1',G42_CLINE_AUDIT=str(B/'app-model-audit.jsonl'))
    command=['node','--env-file=.env','--import',str(L/'cline-pass-transport.mjs'),'--import','tsx','src/server.ts']
else:
    module,port={'data':('data.service.app:create_app','8089'),'native':('recommendation.app:app','8092'),'public':('api.main:app','8010')}[name]
    command=[str(python),'-m','uvicorn',module,'--host','127.0.0.1','--port',port]+(['--factory'] if name=='data' else [])
    if name=='native':env.update(NODE_OPTIONS='--import='+(L/'cline-pass-transport.mjs').as_uri(),G42_CLINE_NONTHINKING='1',G42_CLINE_AUDIT=str(B/'native-model-audit.jsonl'))
if name in records:
    try:os.kill(records[name]['pid'],0);print('Owned service already running: '+name);raise SystemExit()
    except ProcessLookupError:pass
with (B/(name+'-service.log')).open('a') as log:
    process=subprocess.Popen(command,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
records[name]={'pid':process.pid};registry.write_text(json.dumps(records,indent=2))
print('Started owned service '+name)
