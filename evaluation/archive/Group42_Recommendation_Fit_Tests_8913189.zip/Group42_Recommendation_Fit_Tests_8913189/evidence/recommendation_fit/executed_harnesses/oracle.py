"""Independent expectation calculations. Does not import production validation/ranking."""
import hashlib,json,math
from pathlib import Path
from dotenv import dotenv_values
import psycopg2
from psycopg2.extras import RealDictCursor
from neo4j import GraphDatabase
B=Path(__file__).resolve().parent;R=B.parent/'qa_live_cline_8913189/runtime'

class Oracle:
 def __init__(self):
  s=dotenv_values(R/'.env');self.rows=[];self.distances={};self.place=None
  conn=psycopg2.connect(s['PROPERTYGURU_DATABASE_URL'].replace('postgresql+psycopg2:','postgresql:'));conn.set_session(readonly=True,isolation_level='REPEATABLE READ')
  with conn.cursor(cursor_factory=RealDictCursor) as cur:
   cur.execute("SELECT listing_id,price,bedrooms,floor_area_sqft,property_type,district_code,latitude,longitude,currency FROM properties WHERE listing_type='RENT' ORDER BY listing_id::text")
   raw=[dict(r) for r in cur.fetchall()]
  conn.close();assert len(raw)==21431
  self.source_negative_bedrooms=sum(r['bedrooms'] is not None and r['bedrooms']<0 for r in raw)
  for p in raw:
   p['listing_id']=str(p['listing_id'])
   for f in ['price','bedrooms','floor_area_sqft','latitude','longitude']:
    v=float(p[f]) if p[f] is not None else None
    p[f]=v if v is not None and math.isfinite(v) and (abs(v)<=({'latitude':90,'longitude':180}[f]) if f in ['latitude','longitude'] else v>=0) else None
   if p['currency'] not in [None,'','SGD']:p['price']=None
   p['property_type']=p['property_type'].strip().casefold() if p['property_type'] else None
   self.rows.append(p)
  self.by_id={p['listing_id']:p for p in self.rows}
  driver=GraphDatabase.driver(s['NEO4J_URI'],auth=None if s.get('NEO4J_AUTH')=='none' else(s.get('NEO4J_USER','neo4j'),s.get('NEO4J_PASSWORD','')))
  with driver.session(database=s.get('NEO4J_DATABASE','neo4j'),default_access_mode='READ') as session:
   places=session.run("MATCH(p:Place {place_id:$id}) WHERE p.active=true RETURN p.place_id AS place_id,p.latitude AS latitude,p.longitude AS longitude,p.name AS name",id='OSM:way:54519165').data()
   assert len(places)==1;self.place=places[0]
   relations=session.run("MATCH(l:Listing)-[r:NEAR_PLACE]->(p:Place {place_id:$id}) RETURN l.listing_id AS listing_id,l.latitude AS latitude,l.longitude AS longitude,r.distance_m AS distance_m,r.distance_type AS distance_type",id=self.place['place_id']).data()
  driver.close();self.relations={str(x['listing_id']):x for x in relations}
  for p in self.rows:
   distance=self.coordinate_distance(p,self.place);edge=self.relations.get(p['listing_id'])
   if edge and distance is not None and edge['latitude']==p['latitude'] and edge['longitude']==p['longitude'] and edge['distance_type']=='geodesic' and edge['distance_m'] is not None and abs(edge['distance_m']-distance)<=1:distance=edge['distance_m']
   self.distances[p['listing_id']]=distance
  self.summary={'source':'Read-only PostgreSQL properties and independent Neo4j place/edge reads','rows':len(self.rows),
   'normalized_source_sha256':hashlib.sha256(json.dumps(self.rows,sort_keys=True,default=str).encode()).hexdigest(),
   'negative_bedroom_sentinels':self.source_negative_bedrooms,'missing_coordinates':sum(self.distances[p['listing_id']] is None for p in self.rows),
   'place':self.place,'graph_edges_to_place':len(relations),'production_ranking_or_validation_imported':False}
  (B/'oracle-source-summary.json').write_text(json.dumps(self.summary,indent=2))
 @staticmethod
 def coordinate_distance(p,d):
  if p['latitude'] is None or p['longitude'] is None or d['latitude'] is None or d['longitude'] is None:return None
  a,b,c,e=map(math.radians,[p['latitude'],p['longitude'],d['latitude'],d['longitude']]);h=math.sin((c-a)/2)**2+math.cos(a)*math.cos(c)*math.sin((e-b)/2)**2
  return 6371008.8*2*math.asin(math.sqrt(min(1,max(0,h))))
 def value(self,p,c):
  f=c['field']
  if f in ['furnishing','lease_months','availability','commute']:return None
  if f=='distance':
   if c.get('distance_type')!='straight_line' or c.get('destination_id')!=self.place['place_id']:return None
   return self.distances[p['listing_id']]
  return p.get(f)
 def outcome(self,p,c):
  value=self.value(p,c)
  if value is None:return 'unknown'
  target=c['value'];op=c['operator']
  yes={'eq':lambda:value==target,'in':lambda:value in target,'lte':lambda:value<=target,'gte':lambda:value>=target,'between':lambda:target[0]<=value<=target[1]}[op]()
  return 'pass' if yes else 'fail'
 def score(self,p,criteria):
  soft=[c for c in criteria if c['strength']=='soft']
  if not soft:return 0.,0.
  total=sum(c.get('weight',1) for c in soft);score=coverage=0
  for c in soft:
   value=self.value(p,c);weight=c.get('weight',1)/total
   if value is None:continue
   coverage+=weight;u=c.get('utility','threshold')
   if u=='proximity':utility=1/(1+value/c['value'])
   elif u in ['minimize','maximize']:
    upper={'price':20000,'bedrooms':10,'floor_area_sqft':10000}[c['field']];utility=min(1,max(0,value/upper))
    if u=='minimize':utility=1-utility
   else:utility=float(self.outcome(p,c)=='pass')
   score+=weight*utility
  return score,coverage
 def assess(self,criteria):
  groups={'eligible':[],'unverified':[],'excluded':[]};scores={};coverage={}
  for p in self.rows:
   checks=[self.outcome(p,c) for c in criteria if c['strength']=='hard']
   group='excluded' if 'fail' in checks else 'unverified' if 'unknown' in checks else 'eligible'
   groups[group].append(p['listing_id'])
   if group=='eligible':scores[p['listing_id']],coverage[p['listing_id']]=self.score(p,criteria)
  groups['eligible'].sort(key=lambda id:(-scores[id],id))
  return {'counts':{'assessed':len(self.rows),**{k:len(v) for k,v in groups.items()}},'groups':groups,'scores':scores,'coverage':coverage}
