import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {extractRules} from '../qa_live_cline_8913189/runtime/src/domain/requirements.js';
import {parseLocationIntents} from '../qa_live_cline_8913189/runtime/src/domain/geo-intake.js';
const b=path.dirname(fileURLToPath(import.meta.url));
const c=JSON.parse(await readFile(path.join(b,'frozen-fit-cases.json'),'utf8'));
const result=JSON.parse(await readFile(path.join(b,'natural-result.json'),'utf8'));
const rows=[];
for(const id of ['RN04','RN07','RN10','RN12']){
 const item=c.natural.find(x=>x.id===id),base=id==='RN12'?result.rows.find(x=>x.id==='RN11').state.requirements:{listing_type:'RENT',criteria:[]};
 rows.push({id,input:item.query,rule_draft:extractRules(item.query,base),location_intents:parseLocationIntents(item.query)});
}
await writeFile(path.join(b,'intake-diagnostics.json'),JSON.stringify({purpose:'Read-only product parser probes for issue triage; not additional cases or fixes',real_model_calls:0,rows},null,2));
console.log('Four read-only intake diagnostics recorded; no model calls.');
