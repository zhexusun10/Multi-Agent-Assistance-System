from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from uuid import uuid4
import httpx
from dotenv import dotenv_values
from app_client import run_question

B=Path(__file__).resolve().parent;L=B.parent/'qa_live_cline_8913189';R=L/'runtime'
client=httpx.Client(timeout=120,trust_env=False)
rows=[];baseline=None
def service(action,name):
    r=subprocess.run([sys.executable,str(B/'services.py'),action,name],capture_output=True,text=True)
    if r.returncode:raise RuntimeError('Service control failed')
def wait_ready(url,expected=200,seconds=25):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        try:
            r=client.get(url,timeout=2)
            if r.status_code==expected:return r.json()
        except httpx.HTTPError:pass
        time.sleep(.3)
    raise TimeoutError('Service did not reach expected readiness')
def record(name,passed,observed):
    rows.append({'id':f'XF{len(rows)+1:02}','name':name,'status':'PASS' if passed else 'FAIL','observed':observed})
    print(name,rows[-1]['status'],flush=True)
def app_question(query):
    owner=uuid4().hex+uuid4().hex;headers={'authorization':'Bearer '+owner,'content-type':'application/json'}
    sid=client.post('http://127.0.0.1:8010/api/sessions',headers=headers,json={}).json()['session_id']
    started=time.monotonic()
    response=client.post('http://127.0.0.1:8010/api/query',headers=headers,json={'session_id':sid,'request_id':str(uuid4()),'query':query})
    response.raise_for_status()
    state=client.get('http://127.0.0.1:8010/api/state',headers=headers,params={'session_id':sid}).json()
    return {'latency_ms':round((time.monotonic()-started)*1000),'http_status':response.status_code,
        'last_message':state['messages'][-1],'recommendation_created':state['recommendation'] is not None}
try:
    baseline=wait_ready('http://127.0.0.1:18091/health')
    before=client.post('http://127.0.0.1:18091/search',json={'queries':['普通公寓最短租期'],'top_k':5}).json()
    record('Healthy real hybrid search',before['vector_enabled'] and before['bm25_enabled'] and not before['degraded'],{'generation':before['generation'],'chunks':len(before['chunks'])})
    service('stop','chroma');time.sleep(.5)
    response=client.post('http://127.0.0.1:18091/search',json={'queries':['普通公寓最短租期'],'top_k':5})
    data=response.json()
    record('Real Chroma outage retains BM25 HTTP search',response.status_code==200 and data['vector_enabled'] is False and data['bm25_enabled'] is True and 'vector_unavailable' in data['degraded'] and bool(data['chunks']),data)
    env=dict(os.environ);env.update({k:v for k,v in dotenv_values(R/'.env').items() if v is not None})
    env.update(G42_CLINE_NONTHINKING='1',G42_CLINE_AUDIT=str(B/'fault-model-audit.jsonl'))
    result=subprocess.run(['node','--env-file=.env','--import',str(L/'cline-pass-transport.mjs'),'--import','tsx',str(B/'fault_probe.ts'),str(B/'fault-bm25-model-result.json')],cwd=R,env=env,capture_output=True,text=True,timeout=90)
    probe=json.loads((B/'fault-bm25-model-result.json').read_text())
    record('Grounded real-model answer survives actual vector outage',result.returncode==0 and probe['status']=='PASS',probe)
    service('start','chroma');wait_ready('http://127.0.0.1:18002/api/v1/heartbeat')
    service('stop','retrieval');time.sleep(.5)
    failed=run_question('请解释普通公寓最短可以租多久。')
    knowledge=failed['last_message'].get('knowledge',{})
    record('Application reports retrieval outage without invented answer',knowledge.get('status')=='unavailable' and not knowledge.get('citations') and not failed['recommendation_created'],failed)
    service('start','retrieval');after=wait_ready('http://127.0.0.1:18091/health')
    record('Restart preserves both existing indexes',all(after[k]==baseline[k] for k in ['knowledge_generation','knowledge_documents','knowledge_chunks','intent_templates']),after)
    recovered=run_question('请解释HDB卧室最低出租期限。')
    knowledge=recovered['last_message'].get('knowledge',{})
    record('Recovered application returns a grounded model answer',knowledge.get('status')=='ok' and knowledge.get('method')=='llm_grounded_verified' and bool(knowledge.get('citations')) and not recovered['recommendation_created'],recovered)
except Exception as exc:
    rows.append({'id':'HARNESS_ERROR','status':'FAIL','error_type':type(exc).__name__})
finally:
    service('start','chroma');service('start','retrieval')
    result={'status':'PASS' if len(rows)==6 and all(x['status']=='PASS' for x in rows) else 'FAIL',
       'cases':len(rows),'passed':sum(x['status']=='PASS' for x in rows),'failed':sum(x['status']!='PASS' for x in rows),
       'actual_process_outages':True,'source_changed':False,'rows':rows,'finished_at':datetime.now().astimezone().isoformat()}
    (B/'fault-recovery-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));client.close()
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
