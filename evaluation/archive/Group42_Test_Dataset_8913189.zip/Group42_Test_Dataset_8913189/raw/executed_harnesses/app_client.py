"""Observe completed operations, since SSE acknowledgement precedes completion."""
from pathlib import Path
import time
from uuid import uuid4
import httpx
import psycopg2
from dotenv import dotenv_values

B=Path(__file__).resolve().parent
def run_question(query):
    settings=dotenv_values(B.parent/'qa_live_cline_8913189/runtime/.env')
    owner=uuid4().hex+uuid4().hex;headers={'authorization':'Bearer '+owner,'content-type':'application/json'}
    with httpx.Client(timeout=120,trust_env=False) as client:
        created=client.post('http://127.0.0.1:8010/api/sessions',headers=headers,json={});created.raise_for_status()
        sid=created.json()['session_id'];rid=str(uuid4());started=time.monotonic()
        response=client.post('http://127.0.0.1:8010/api/query',headers=headers,json={'session_id':sid,'request_id':rid,'query':query})
        response.raise_for_status()
        conn=psycopg2.connect(settings['DATABASE_URL']);conn.autocommit=True
        try:
            deadline=time.monotonic()+90
            while True:
                with conn.cursor() as cur:
                    cur.execute('SELECT status,kind,intent_plan FROM domain_operations WHERE session_id=%s AND request_id=%s',(sid,rid));row=cur.fetchone()
                if row and row[0] in ['completed','failed','superseded']:break
                if time.monotonic()>deadline:raise TimeoutError('Operation did not reach terminal state')
                time.sleep(.15)
        finally:conn.close()
        state=client.get('http://127.0.0.1:8010/api/state',headers=headers,params={'session_id':sid}).json()
        return {'latency_ms':round((time.monotonic()-started)*1000),'http_status':response.status_code,
          'operation_status':row[0],'operation_kind':row[1],'intent':row[2],
          'last_message':state['messages'][-1],'recommendation_created':state['recommendation'] is not None}
