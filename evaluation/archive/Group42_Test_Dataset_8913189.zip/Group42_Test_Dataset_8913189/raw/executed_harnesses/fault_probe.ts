import {writeFile} from 'node:fs/promises';
import {createModel} from '../qa_live_cline_8913189/runtime/src/model.js';
import {KnowledgeService} from '../qa_live_cline_8913189/runtime/src/domain/knowledge.js';
const started=performance.now();
const service=new KnowledgeService('hybrid_rrf',await createModel(undefined,{maxTokens:2600,temperature:.1}),{
 rewriteModel:await createModel(undefined,{maxTokens:512,temperature:.3}),rerankModel:await createModel(undefined,{maxTokens:768,temperature:.1})});
const result=await service.query('普通私人住宅至少要租几个月？');
const passed=result.status==='ok'&&result.method==='llm_grounded_verified'&&result.vector_enabled===false&&result.bm25_enabled===true&&result.degraded?.includes('vector_unavailable')&&result.citations.some(c=>c.document_id==='private-rental');
await writeFile(process.argv[2],JSON.stringify({status:passed?'PASS':'FAIL',expected_fault:'Real Chroma process stopped; real BM25 and chat model retained',latency_ms:Math.round(performance.now()-started),result},null,2));
console.log(JSON.stringify({status:passed?'PASS':'FAIL',method:result.method,vector:result.vector_enabled,bm25:result.bm25_enabled}));
process.exitCode=passed?0:1;
