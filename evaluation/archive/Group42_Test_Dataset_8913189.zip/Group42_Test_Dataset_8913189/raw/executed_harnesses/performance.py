from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time
import httpx
from app_client import run_question

B=Path(__file__).resolve().parent
def stats(rows):
    values=sorted(r['latency_ms'] for r in rows)
    return {'n':len(values),'mean_ms':round(statistics.mean(values)),'median_ms':values[(len(values)-1)//2],
        'p95_ms':values[max(0,__import__('math').ceil(.95*len(values))-1)],'maximum_ms':values[-1]}
def search(index):
    query=['普通公寓最短租期','独立卫浴待核实','复制草稿是否发送','押金扣款证据','组屋卧室批准'][index%5]
    start=time.monotonic()
    try:
        with httpx.Client(timeout=30,trust_env=False) as c:r=c.post('http://127.0.0.1:18091/search',json={'queries':[query],'top_k':5})
        d=r.json();ok=r.status_code==200 and d['status']=='ok' and d['vector_enabled'] and d['bm25_enabled'] and not d['degraded']
        return {'query':query,'latency_ms':round((time.monotonic()-start)*1000),'http_status':r.status_code,'contract_pass':ok,'generation':d.get('generation')}
    except Exception as exc:return {'query':query,'latency_ms':round((time.monotonic()-start)*1000),'contract_pass':False,'error_type':type(exc).__name__}
retrieval=[]
for concurrency in [1,3,5]:
    start=time.monotonic()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:rows=list(pool.map(search,range(10)))
    retrieval.append({'concurrency':concurrency,'wall_ms':round((time.monotonic()-start)*1000),'statistics':stats(rows),'passed':sum(x['contract_pass'] for x in rows),'rows':rows})
    print('Retrieval concurrency',concurrency,'completed',flush=True)

questions=['请解释本系统为什么不能把一个卫生间等同于独立卫浴。',
 '请解释复制联系草稿和取得平台送达回执的区别。',
 '请解释区域距离为零为什么不等于距离车站零米。']
def question(query):
    start=time.monotonic()
    try:
        r=run_question(query);k=r['last_message'].get('knowledge',{})
        r['query']=query;r['contract_pass']=r['operation_status']=='completed' and r['operation_kind']=='knowledge' and k.get('status')=='ok' and k.get('method')=='llm_grounded_verified' and bool(k.get('citations')) and not k.get('degraded')
        return r
    except Exception as exc:return {'query':query,'latency_ms':round((time.monotonic()-start)*1000),'contract_pass':False,'error_type':type(exc).__name__}
application=[]
for concurrency in [1,3]:
    # Reset the application's in-memory answer cache between batches.
    for action in ['stop','start']:
        subprocess.run([sys.executable,str(B/'services.py'),action,'graph'],check=True,capture_output=True)
    deadline=time.monotonic()+25
    while True:
        try:
            with httpx.Client(timeout=2,trust_env=False) as c:
                ready=c.get('http://127.0.0.1:3001/health').status_code==200
            if ready:break
        except httpx.HTTPError:pass
        if time.monotonic()>deadline:raise TimeoutError('Graph did not restart for cache isolation')
        time.sleep(.2)
    start=time.monotonic()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:rows=list(pool.map(question,questions))
    application.append({'concurrency':concurrency,'wall_ms':round((time.monotonic()-start)*1000),'statistics':stats(rows),'passed':sum(x['contract_pass'] for x in rows),'rows':rows})
    print('Application concurrency',concurrency,'completed',flush=True)
report={'status':'PASS' if all(x['passed']==10 for x in retrieval) and all(x['passed']==3 for x in application) else 'FAIL',
    'finished_at':datetime.now().astimezone().isoformat(),'retrieval_requests':30,'application_workflows':6,
    'acceptance_scope':'HTTP and grounded-answer response contracts only. Timing is observational; no agreed latency SLA or capacity threshold exists.',
    'limitations':['Warm local indexes and the same small corpus','10 retrieval samples per concurrency level and 3 application workflows per level',
       'Application process restarted between batches to clear its answer cache',
       'Application measurement includes completed operation polling, not browser paint time','No production capacity claim or human acceptance'],
    'retrieval':retrieval,'application':application}
(B/'performance-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['retrieval','application']}),flush=True)
