from datetime import datetime
import hashlib
import json
from pathlib import Path
from uuid import uuid4
import httpx
from dotenv import dotenv_values

B=Path(__file__).resolve().parent
R=B.parent/'qa_live_cline_8913189/runtime'
fixture=json.loads((R/'data/.runtime/native-browser-session.json').read_text())
settings=dotenv_values(R/'.env')
owner=fixture['owner'];sid=fixture['session_id'];stranger=uuid4().hex+uuid4().hex
origin='http://127.0.0.1:8010'
client=httpx.Client(timeout=20,trust_env=False)
state=client.get(origin+'/api/state',params={'session_id':sid},headers={'authorization':'Bearer '+owner}).json()
ref=str(uuid4());aid=str(uuid4());listing=state['recommendation']['recommendations'][0]['listing']['listing_id']
cases=[]
def case(name,method,path,expected,auth='owner',body=None,content=None):
    cases.append({'id':f'XA{len(cases)+1:02}','name':name,'method':method,'path':path,'expected_status':expected,
                  'auth':auth,'body':body,'raw_content':content})
case('State requires authorization','GET',f'/api/state?session_id={sid}',401,'none')
case('Short malformed owner token rejected','GET',f'/api/state?session_id={sid}',401,'invalid')
case('Different owner cannot read a session','GET',f'/api/state?session_id={sid}',403,'stranger')
case('Different owner cannot read evidence','GET',f'/api/evidence?session_id={sid}&ref={ref}',403,'stranger')
case('Different owner cannot download an artifact','GET',f'/api/artifacts/{ref}?session_id={sid}',403,'stranger')
case('Different owner cannot read listing presentation','GET',f'/api/listings/{listing}/presentation?session_id={sid}&source_request_id={state["latest_request_id"]}',403,'stranger')
case('Different owner cannot prepare a manual action','POST',f'/api/actions/{aid}/manual-prepare',403,'stranger',{'session_id':sid,'revision':1})
case('Public query preserves missing-auth 401 status','POST','/api/query',401,'none',{'session_id':sid,'query':'Explain the current first recommendation.'})
case('Public query preserves wrong-owner 403 status','POST','/api/query',403,'stranger',{'session_id':sid,'query':'Explain the current first recommendation.'})
case('Empty query rejected','POST','/api/query',422,body={'query':''})
case('Whitespace query rejected','POST','/api/query',422,body={'query':'   '})
case('Missing query rejected','POST','/api/query',422,body={})
case('Oversized query rejected','POST','/api/query',422,body={'query':'x'*8001})
case('Empty session identifier rejected','POST','/api/query',422,body={'query':'hello','session_id':''})
case('Long session identifier rejected','POST','/api/query',422,body={'query':'hello','session_id':'s'*129})
case('Long request identifier rejected','POST','/api/query',422,body={'query':'hello','request_id':'r'*101})
case('Malformed query JSON rejected','POST','/api/query',422,content='{"query":')
case('Body exceeding 64 KiB rejected','POST','/api/sessions',413,content='x'*65537)
case('Negative SSE cursor rejected','GET',f'/api/events?session_id={sid}&after=-1',422)
case('Fractional SSE cursor rejected','GET',f'/api/events?session_id={sid}&after=1.5',422)
case('Unknown public route rejected','GET','/api/not-a-project-route',404)
case('Invalid evidence reference rejected','GET',f'/api/evidence?session_id={sid}&ref=not-a-uuid',422)
case('Missing artifact returns 404','GET',f'/api/artifacts/{ref}?session_id={sid}',404)
case('Stale listing source reference rejected','GET',f'/api/listings/{listing}/presentation?session_id={sid}&source_request_id={ref}',409)
case('Native service rejects missing internal token','POST','http://127.0.0.1:8092/recommend',401,'none',{})
case('Retrieval rejects no queries','POST','http://127.0.0.1:18091/search',422,'none',{'queries':[]})
case('Retrieval rejects blank query','POST','http://127.0.0.1:18091/search',422,'none',{'queries':[' ']})
case('Retrieval rejects oversized query','POST','http://127.0.0.1:18091/search',422,'none',{'queries':['x'*8001]})
case('Retrieval rejects zero top k','POST','http://127.0.0.1:18091/search',422,'none',{'queries':['rent'],'top_k':0})
case('Retrieval rejects excessive top k','POST','http://127.0.0.1:18091/search',422,'none',{'queries':['rent'],'top_k':21})
case('Intent service rejects old template generation','POST','http://127.0.0.1:18091/intent-match',409,'none',{'query':'找房','template_version':'not-the-published-version'})
case('Intent service requires template generation','POST','http://127.0.0.1:18091/intent-match',422,'none',{'query':'找房'})
catalog={'frozen_at':datetime.now().astimezone().isoformat(),'cases':cases,
         'scope':'Actual loopback HTTP boundary checks. Error status propagation is a proposed QA contract. No authenticated request is allowed to trigger an external send.'}
p=B/'api-boundary-cases.json';p.write_text(json.dumps(catalog,ensure_ascii=False,indent=2));digest=hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for c in cases:
    url=c['path'] if c['path'].startswith('http') else origin+c['path']
    token={'owner':owner,'stranger':stranger,'invalid':'bad','none':None}[c['auth']]
    headers={'content-type':'application/json'}
    if token:headers['authorization']='Bearer '+token
    start=datetime.now()
    try:
        kwargs={'headers':headers}
        if c['raw_content'] is not None:kwargs['content']=c['raw_content']
        elif c['body'] is not None:kwargs['json']=c['body']
        response=client.request(c['method'],url,**kwargs)
        rows.append({'id':c['id'],'name':c['name'],'expected_status':c['expected_status'],'actual_status':response.status_code,
            'correct':response.status_code==c['expected_status'],'response_excerpt':response.text[:500],
            'latency_ms':round((datetime.now()-start).total_seconds()*1000)})
    except Exception as e:rows.append({'id':c['id'],'name':c['name'],'correct':False,'error_type':type(e).__name__})
result={'cases':len(rows),'passed':sum(x['correct'] for x in rows),'failed':sum(not x['correct'] for x in rows),
    'case_catalog_sha256':digest,'rows':rows,'actual_http':True,'real_chat_calls_expected':0,
    'status':'PASS' if all(x['correct'] for x in rows) else 'FAIL'}
(B/'api-boundary-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='rows'}));print(json.dumps([r for r in rows if not r['correct']],ensure_ascii=False))
client.close()
