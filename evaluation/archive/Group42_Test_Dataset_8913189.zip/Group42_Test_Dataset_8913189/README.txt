GROUP 42 TEST DATASET REVIEW
Open 01_Test_Case_Catalogue.txt for an ordered, readable view of all 140 added functional/fault cases. Open 02_Test_Case_Catalogue.json for machine-readable inputs, expectations, shared fixtures and result references. Input languages are preserved exactly; explanatory labels are English.

The five individually failing cases are XI20, XK23, XR05, XA08 and XA09. Intent still meets its predeclared >=95% suite threshold; the other failed suite decisions remain failed. The existing DEF04 refund challenge and its repeats are documented in the main acceptance pack and are not new cases in this 140-case catalogue.

raw contains unmodified original frozen catalogues, execution results, open issues and exact executed harnesses. JSON #CaseID references identify a record in its rows array; they are record locators rather than browser anchors. Full provider request audits and browser screenshots remain in the main acceptance evidence archive. No model, browser or product test was rerun to create this export.

The main pack contains additional historical repository tests and original native integration/browser reruns. This focused dataset does not repeat those tests or the 36 timing samples. Final acceptance remains pending.
