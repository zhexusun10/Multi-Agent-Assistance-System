#!/usr/bin/env python3
"""Offline QA checks. Standard library only. No model calls or external actions."""
import argparse
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]

def reject_nonfinite(value):
    raise ValueError(f"Non-finite JSON number is not allowed: {value}")

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_constant=reject_nonfinite)

def read_jsonl(path):
    rows = []
    for n, line in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        if line.strip():
            try:
                rows.append(json.loads(line, parse_constant=reject_nonfinite))
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}: line {n}: {e}") from e
    return rows

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def ensure_fresh_output(path):
    path = Path(path)
    if path.exists() and (not path.is_dir() or any(path.iterdir())):
        raise ValueError(f"Output already exists: {path}. Choose a new run or review path to preserve existing evidence.")

def read_reviews(path):
    payload = read_json(path)
    if not isinstance(payload, dict) or not isinstance(payload.get("reviews"), list):
        raise ValueError("Human review file must be an object containing a reviews array.")
    return payload["reviews"]

def validate_review_shape(reviews):
    if not isinstance(reviews, list):
        raise ValueError("Human reviews must be a list.")
    for review in reviews:
        if not isinstance(review, dict):
            raise ValueError("Each human review must be an object.")
        for key in ["case_id", "run_id", "result_sha256", "status", "reviewer", "evidence", "factuality", "task_behavior", "notes"]:
            if key in review and not isinstance(review[key], str):
                raise ValueError(f"Human review {key} must be a string.")
        score = review.get("clarity_score")
        if score not in (None, "") and (type(score) is not int or not 1 <= score <= 5):
            raise ValueError("Human review clarity_score must be an integer from 1 to 5, or blank while pending.")

def load(root=ROOT):
    root = Path(root)
    cases = read_jsonl(root / "data/cases.jsonl")
    fixture = read_json(root / "data/fixtures.json")
    manifest = read_json(root / "data/dataset_manifest.json")
    return cases, fixture, manifest

def unique_index(rows, key, label):
    result = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError(f"{label}: each record must be an object")
        value = row.get(key)
        if not isinstance(value, str) or not value:
            raise ValueError(f"{label}: missing {key}")
        if value in result:
            raise ValueError(f"{label}: duplicate {key}: {value}")
        result[value] = row
    return result

def equal(a, b):
    # Python otherwise treats True as equal to 1. That is unsafe for structured fields.
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    if isinstance(a, (float, int)) and isinstance(b, (float, int)):
        return math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, abs_tol=1e-9)
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b

def eligible(listing, constraints):
    if listing.get("transaction_type") != "rent" or listing.get("residential") is not True:
        return False
    if listing.get("availability") != "active_verified":
        return False
    rent = listing.get("monthly_rent_sgd")
    if rent is not None and (not isinstance(rent, (int, float)) or isinstance(rent, bool) or not math.isfinite(rent) or rent <= 0):
        return False
    fields = {
        "budget_max_sgd": ("monthly_rent_sgd", "max"),
        "bedrooms_min": ("bedrooms", "min"),
        "mrt_walk_max_min": ("mrt_walk_minutes", "max"),
        "commute_max_min": ("commute_minutes", "max"),
        "lease_months": ("min_lease_months", "max"),
        "lease_mode": ("lease_mode", "eq"),
        "property_type": ("property_type", "eq"),
        "location": ("location", "eq"),
        "furnishing": ("furnishing", "eq"),
        "pets_required": ("pets_allowed", "eq"),
    }
    for key, wanted in constraints.items():
        if key not in fields:
            continue
        field, kind = fields[key]
        value = listing.get(field)
        if value is None:
            return False
        if kind == "eq":
            if not equal(value, wanted): return False
        else:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value): return False
            if kind == "max" and value > wanted: return False
            if kind == "min" and value < wanted: return False
    return True

def validate_dataset(cases, fixture, manifest, root=ROOT):
    cidx = unique_index(cases, "case_id", "cases")
    listings = unique_index(fixture["listings"], "listing_id", "fixtures")
    edges = unique_index(fixture["graph_edges"], "edge_id", "graph")
    if fixture.get("synthetic") is not True or manifest.get("synthetic") is not True:
        raise ValueError("Fixture and manifest must explicitly identify synthetic data.")
    if manifest["dataset_id"] != fixture["dataset_id"]:
        raise ValueError("Dataset ID mismatch.")
    if len(cases) != manifest["case_count"]:
        raise ValueError("Case count mismatch.")
    for split in ["development", "holdout"]:
        if sum(c["split"] == split for c in cases) != manifest[f"{split}_count"]:
            raise ValueError(f"{split} count mismatch.")
    for name, key in [("cases.jsonl","case_sha256"),("fixtures.json","fixture_sha256")]:
        if hashlib.sha256((Path(root)/"data"/name).read_bytes()).hexdigest() != manifest[key]:
            raise ValueError(f"{name} differs from the frozen manifest. Review and version it.")
    coverage = set()
    for c in cases:
        coverage.update(c["requirement_ids"])
        if not c["steps"] or not c["manual_checks"] or c["initial_status"] != "NOT_RUN":
            raise ValueError(f"{c['case_id']}: missing steps/review, or prefilled result.")
        for s in c["steps"]:
            if not set(s.get("fixture_pool", [])) <= listings.keys():
                raise ValueError(f"{c['case_id']}: unknown fixture ID.")
            expected = s["expected"]
            for id_ in expected.get("graph_edge_ids", []):
                if id_ not in edges: raise ValueError(f"{c['case_id']}: unknown graph edge.")
            if "hard_constraints" in s:
                independent = {id_ for id_ in s["fixture_pool"] if eligible(listings[id_], s["hard_constraints"])}
                if independent != set(expected["eligible_ids"]):
                    raise ValueError(f"{c['case_id']}: inconsistent eligibility gold.")
            for claim in expected.get("claims", []):
                x = listings[claim["listing_id"]]
                if not equal(x[claim["field"]],claim["value"]) or x["source_id"] != claim["source_id"]:
                    raise ValueError(f"{c['case_id']}: unsupported gold claim.")
    if coverage != {f"R{i:02}" for i in range(1,15)}:
        raise ValueError("Requirement coverage is incomplete.")
    return dict(dataset_id=manifest["dataset_id"],cases=len(cidx),
                development=manifest["development_count"],holdout=manifest["holdout_count"],
                listings=len(listings),graph_edges=len(edges),requirements=len(coverage),
                validation="PASS",system_testing="NOT_RUN")

def ndcg(ids, labels, k=5):
    if len(ids) != len(set(ids)):
        return None
    # Empty or zero-gain truth is not a meaningful ranking sample.
    ideal = sorted(labels.values(), reverse=True)[:k]
    idcg = sum((2**v-1)/math.log2(i+2) for i,v in enumerate(ideal))
    if idcg == 0: return None
    gain = sum((2**labels.get(id_,0)-1)/math.log2(i+2) for i,id_ in enumerate(ids[:k]))
    return gain/idcg

def percentile(values, q):
    if not values: return None
    values = sorted(values)
    pos = (len(values)-1)*q
    low, high = math.floor(pos), math.ceil(pos)
    return values[low] + (values[high]-values[low])*(pos-low)

def check_turn(case, index, observed, fixture):
    spec = case["steps"][index]
    expected = spec["expected"]
    listings = {x["listing_id"]:x for x in fixture["listings"]}
    edges = {x["edge_id"]:x for x in fixture["graph_edges"]}
    failures, missing = [], []
    fields_correct = fields_total = 0
    hard_violations = hard_assessed = 0
    ranking_metric = recall_metric = None
    field_breakdown={}
    if not isinstance(observed,dict):
        return dict(failures=[],missing=["turn output"],field_correct=0,field_total=0,
                    hard_violations=0,hard_assessed=0,ndcg=None,recall=None)
    for key, wanted in expected.items():
        if key == "state":
            state = observed.get("state")
            if not isinstance(state,dict):
                missing.append("state")
                fields_total += len(wanted)
                for field in wanted:field_breakdown[field]=[0,1]
                continue
            for field, value in wanted.items():
                fields_total += 1
                field_breakdown[field]=[0,1]
                if field not in state:
                    missing.append(f"state.{field}")
                elif equal(state[field],value):
                    fields_correct += 1
                    field_breakdown[field][0]=1
                else:
                    failures.append(f"state.{field}: expected {value!r}, observed {state[field]!r}")
        elif key == "actions":
            actions = observed.get("actions")
            if not isinstance(actions,list):
                missing.append("actions")
                continue
            if len(actions) != len(wanted):
                failures.append("actions: unexpected number of action records")
            by_id = {a.get("action_id"):a for a in actions if isinstance(a,dict)}
            for action in wanted:
                got = by_id.get(action["action_id"])
                if got is None:
                    failures.append(f"missing action {action['action_id']}")
                    continue
                # Hash values are generated by the real adapter. Compare the semantic fixture
                # identity here, and validate exact approval binding independently below.
                for field in ["approval_state","executed","execution_count","execution_mode","recipient"]:
                    if field not in got: missing.append(f"action.{field}")
                    elif not equal(got[field],action[field]): failures.append(f"action {action['action_id']}: {field}")
                if got.get("action_type","message_send")!=action.get("action_type","message_send"):
                    failures.append(f"action {action['action_id']}: action type")
        elif key == "claims":
            claims = observed.get("claims")
            if not isinstance(claims,list):
                missing.append("claims")
                continue
            for claim in wanted:
                if not any(all(equal(c.get(k),v) for k,v in claim.items())
                           for c in claims if isinstance(c,dict)):
                    failures.append(f"missing expected claim {claim['listing_id']}.{claim['field']}")
        elif key == "relevance":
            continue
        else:
            if key not in observed:
                missing.append(key)
                continue
            got = observed[key]
            if key in {"eligible_ids","shortlist_ids","clarification_fields","graph_edge_ids",
                       "unknown_fields","conflicting_slot_ids","invalid_listing_ids","raw_record_ids"}:
                if not isinstance(got,list):
                    failures.append(f"{key}: expected a list")
                elif len(set(got)) != len(got):
                    failures.append(f"{key}: duplicate entries")
                elif set(got) != set(wanted):
                    failures.append(f"{key}: expected {wanted}, observed {got}")
            elif not equal(got,wanted):
                failures.append(f"{key}: expected {wanted!r}, observed {got!r}")
    for id_ in observed.get("shortlist_ids",[]):
        if id_ not in spec.get("fixture_pool",[]):
            failures.append(f"shortlist contains a listing outside the declared pool: {id_}")
        if "hard_constraints" in spec:
            hard_assessed += 1
            if id_ not in listings or not eligible(listings[id_],spec["hard_constraints"]):
                hard_violations += 1
                failures.append(f"hard constraint violation: {id_}")
    for claim in observed.get("claims",[]):
        if not isinstance(claim,dict):
            failures.append("malformed claim")
            continue
        x = listings.get(claim.get("listing_id"))
        if (x is None or claim.get("field") not in x or
            not equal(x.get(claim.get("field")),claim.get("value")) or
            claim.get("source_id") != x.get("source_id")):
            failures.append("unsupported structured claim")
    for id_ in observed.get("graph_edge_ids",[]):
        if id_ not in edges or edges[id_]["subject"] not in spec.get("fixture_pool",[]):
            failures.append(f"unsupported graph edge: {id_}")
    if "eligible_ids" in expected:
        relevant = set(expected["eligible_ids"])
        returned = observed.get("eligible_ids")
        if relevant and isinstance(returned,list):
            recall_metric = len(relevant & set(returned))/len(relevant)
    if "relevance" in expected and isinstance(observed.get("ranking_ids"),list):
        if len(observed["ranking_ids"]) != len(set(observed["ranking_ids"])):
            failures.append("ranking_ids: duplicate entries")
        ranking_metric = ndcg(observed["ranking_ids"],expected["relevance"])
    if not isinstance(observed.get("response_text"),str) or not observed["response_text"].strip():
        missing.append("response_text")
    trace = observed.get("trace")
    if not isinstance(trace,dict):
        missing.append("trace")
    else:
        if trace.get("session_id") != spec["session_id"]:
            failures.append("trace session_id mismatch")
        for key in ["request_id","evidence_path","evidence_sha256"]:
            if not trace.get(key, "").strip(): missing.append(f"trace.{key}")
        agents=trace.get("agents")
        if not isinstance(agents,list) or not agents:
            missing.append("trace.agents")
        else:
            for a in agents:
                if not isinstance(a,dict) or not a.get("name"):
                    missing.append("agent.name")
                    continue
                for key in ["start_ms","end_ms"]:
                    if isinstance(a.get(key),bool) or not isinstance(a.get(key),(int,float)):
                        missing.append(f"agent.{key}")
                if isinstance(a.get("start_ms"),(int,float)) and isinstance(a.get("end_ms"),(int,float)):
                    if (not math.isfinite(a["start_ms"]) or not math.isfinite(a["end_ms"]) or
                        a["start_ms"]<0 or a["end_ms"]<a["start_ms"]):
                        failures.append("invalid agent timing")
        if not isinstance(trace.get("tool_calls"),list):
            missing.append("trace.tool_calls")
        else:
            calls=trace["tool_calls"]
            call_ids=[]
            sources=set()
            known_sources={x["source_id"] for x in fixture["listings"]+fixture["graph_edges"]}
            for call in calls:
                if not isinstance(call,dict):
                    failures.append("malformed tool call");continue
                if not call.get("call_id") or not call.get("name"):
                    missing.append("tool call identity")
                else:call_ids.append(call["call_id"])
                if not isinstance(call.get("arguments"),dict):missing.append("tool arguments")
                if type(call.get("success")) is not bool:missing.append("tool success")
                if type(call.get("side_effect")) is not bool:missing.append("tool side_effect")
                if not isinstance(call.get("result_source_ids"),list):missing.append("tool result_source_ids")
                else:
                    if call.get("success") is True and call.get("name") in {"listing_search", "listing_lookup", "graph_query"}:
                        sources.update(call["result_source_ids"])
                    if not set(call["result_source_ids"])<=known_sources:
                        failures.append("tool result contains unknown source IDs")
                if call.get("success") is False and not call.get("error_code"):
                    missing.append("failed tool error_code")
            if len(call_ids)!=len(set(call_ids)):failures.append("duplicate tool call ID within a turn")
            required=[]
            if "hard_constraints" in spec:
                required.append(("listing_search",True))
            if expected.get("error_code"):
                required.append(("listing_search",False))
            if "graph_edge_ids" in expected:
                required.append(("graph_query",case.get("fault_injection",{}).get("graph")!="timeout"))
            if expected.get("claims") and "hard_constraints" not in spec:
                required.append(("listing_lookup",True))
            for name,success in required:
                if not any(call.get("name")==name and call.get("success") is success for call in calls):
                    missing.append(f"trace tool {name} success={success}")
            for claim in observed.get("claims",[]):
                if isinstance(claim,dict) and claim.get("source_id") not in sources:
                    failures.append("structured claim has no source in tool results")
            for id_ in observed.get("graph_edge_ids",[]):
                if "fixture:graph:"+id_ not in sources:
                    failures.append("graph edge has no source in tool results")
    return dict(failures=failures,missing=missing,field_correct=fields_correct,
                field_total=fields_total,hard_violations=hard_violations,
                hard_assessed=hard_assessed,ndcg=ranking_metric,recall=recall_metric,
                field_breakdown=field_breakdown)

def action_failures(turns):
    failures=[]
    previous={}
    side_effect_counts={}
    for turn in turns:
        action_ids = [a.get("action_id") for a in turn.get("actions", [])]
        if len(action_ids) != len(set(action_ids)):
            failures.append("duplicate action ID within a turn")
        current={a.get("action_id"):a for a in turn.get("actions",[]) if isinstance(a,dict)}
        for call in turn.get("trace",{}).get("tool_calls",[]):
            if not isinstance(call,dict) or call.get("side_effect") is not True:continue
            arg=call.get("arguments",{})
            action_id=arg.get("action_id")
            a=current.get(action_id)
            if (call.get("name") not in {"message_send","calendar_book"} or
                call.get("success") is not True or a is None or
                call.get("name")!=a.get("action_type","message_send") or
                a.get("approval_state")!="approved" or a.get("executed") is not True or
                arg.get("content_hash")!=a.get("content_hash") or
                arg.get("recipient")!=a.get("recipient")):
                failures.append("tool side effect lacks a matching approved action record")
            side_effect_counts[action_id]=side_effect_counts.get(action_id,0)+1
        for a in turn.get("actions",[]):
            if not isinstance(a,dict):
                failures.append("malformed action")
                continue
            required=["action_id","approval_state","executed","execution_count",
                      "content_hash","approved_content_hash","recipient","approved_recipient","execution_mode"]
            if any(k not in a for k in required):
                failures.append("incomplete action audit record")
                continue
            count=a["execution_count"]
            if type(count) is not int or count<0 or count>1:
                failures.append("invalid or duplicate action execution count")
            if type(a["executed"]) is not bool or a["executed"] != (count>0):
                failures.append("action executed flag and count disagree")
            if a["executed"]:
                if (a["approval_state"]!="approved" or not a["content_hash"] or
                    a["content_hash"]!=a["approved_content_hash"] or
                    not a["recipient"] or a["recipient"]!=a["approved_recipient"]):
                    failures.append("unapproved action or approval not bound to exact content and recipient")
                if a["execution_mode"]!="simulated":
                    failures.append("unexpected live execution in a simulation-only test")
            last=previous.get(a["action_id"])
            if last:
                if count<last["execution_count"]:
                    failures.append("cumulative action execution count went backwards")
                if last["execution_count"]>0 and a["content_hash"]!=last["content_hash"]:
                    failures.append("an executed action ID was reused for different content")
            previous[a["action_id"]]=a
    for id_,action in previous.items():
        if side_effect_counts.get(id_,0)!=action["execution_count"]:
            failures.append("action audit count does not match tool side-effect events")
    return failures

def result_sha256(result):
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

def manual_status(review, root, result):
    if not review or review.get("status")=="PENDING":
        return "PENDING"
    if (review.get("run_id") != result.get("metadata", {}).get("run_id") or
        review.get("result_sha256") != result_sha256(result)):
        return "STALE"
    if review.get("status")=="FAIL" or review.get("factuality")=="FAIL" or review.get("task_behavior")=="FAIL":
        return "FAIL"
    if (review.get("status")!="PASS" or review.get("factuality")!="PASS" or
        review.get("task_behavior")!="PASS" or not str(review.get("reviewer","")).strip()):
        return "PENDING"
    score=review.get("clarity_score")
    if type(score) is not int or not 1<=score<=5:
        return "PENDING"
    if score<4: return "FAIL"
    evidence=review.get("evidence","")
    if not evidence: return "PENDING"
    p=Path(evidence)
    if not p.is_absolute(): p=Path(root)/p
    if not p.is_file() or not p.stat().st_size: return "PENDING"
    return "PASS"

def validate_result_shape(results):
    """Reject malformed exports before checks. Missing fields remain incomplete."""
    for row in results:
        if not isinstance(row, dict):
            raise ValueError("results: each record must be an object")
        case_id = row.get("case_id", "unknown case")
        def require(value, typ, name):
            if not isinstance(value, typ):
                raise ValueError(f"{case_id}: {name} must be {typ.__name__}")
        for key in ["metadata", "runtime"]:
            if key in row: require(row[key], dict, key)
        for key, value in row.get("metadata", {}).items():
            if not isinstance(value, str):
                raise ValueError(f"{case_id}: metadata.{key} must be str")
        if "turns" in row: require(row["turns"], list, "turns")
        for i, turn in enumerate(row.get("turns", []), 1):
            prefix = f"turn {i}"
            require(turn, dict, prefix)
            for key in ["state", "trace"]:
                if key in turn: require(turn[key], dict, f"{prefix}.{key}")
            for key in ["eligible_ids", "shortlist_ids", "ranking_ids", "graph_edge_ids", "clarification_fields", "unknown_fields", "conflicting_slot_ids", "invalid_listing_ids", "raw_record_ids"]:
                if key in turn:
                    require(turn[key], list, f"{prefix}.{key}")
                    if any(not isinstance(v, str) or not v for v in turn[key]):
                        raise ValueError(f"{case_id}: {prefix}.{key} requires nonempty string entries")
            for key in ["actions", "claims"]:
                if key in turn:
                    require(turn[key], list, f"{prefix}.{key}")
                    for item in turn[key]: require(item, dict, f"{prefix}.{key} item")
            for action in turn.get("actions", []):
                if "action_id" in action and (not isinstance(action["action_id"], str) or not action["action_id"]):
                    raise ValueError(f"{case_id}: action_id must be a nonempty string")
            trace = turn.get("trace", {})
            for key in ["session_id", "request_id", "evidence_path", "evidence_sha256"]:
                if key in trace: require(trace[key], str, f"{prefix}.trace.{key}")
            for key in ["agents", "tool_calls"]:
                if key in trace:
                    require(trace[key], list, f"{prefix}.trace.{key}")
                    for item in trace[key]: require(item, dict, f"{prefix}.trace.{key} item")
            for call in trace.get("tool_calls", []):
                for key in ["call_id", "name"]:
                    if key in call: require(call[key], str, f"tool {key}")
                if "arguments" in call: require(call["arguments"], dict, "tool arguments")
                if "result_source_ids" in call:
                    require(call["result_source_ids"], list, "tool result_source_ids")
                    if any(not isinstance(v, str) for v in call["result_source_ids"]):
                        raise ValueError(f"{case_id}: tool sources require string IDs")

def empty_envelope(result):
    if result.get("metadata", {}).get("run_id"):
        return False
    if any(v is not None for v in result.get("runtime", {}).values()):
        return False
    return all(not t.get("response_text") and not any(k not in {"response_text", "trace"} for k in t) and
               not any(t.get("trace", {}).get(k) for k in ["request_id", "evidence_path", "evidence_sha256", "agents", "tool_calls"])
               for t in result.get("turns", []))

def evaluate(cases,fixture,manifest,results,reviews=None,split="holdout",root=ROOT):
    validate_result_shape(results)
    validate_review_shape(reviews if reviews is not None else [])
    index=unique_index(results,"case_id","results")
    all_ids={c["case_id"] for c in cases}
    unknown=set(index)-all_ids
    if unknown: raise ValueError(f"Unknown case IDs in results: {sorted(unknown)}")
    rev=unique_index(reviews or [],"case_id","manual reviews")
    if set(rev)-all_ids: raise ValueError("Unknown case ID in manual review.")
    selected=[c for c in cases if split=="all" or c["split"]==split]
    executed = [index[c["case_id"]] for c in selected if c["case_id"] in index and not empty_envelope(index[c["case_id"]])]
    for key in ["result_kind", "run_id", "code_version", "model_version", "prompt_version", "data_version"]:
        values = {r.get("metadata", {}).get(key) for r in executed if r.get("metadata", {}).get(key)}
        if len(values) > 1:
            raise ValueError(f"Mixed {key} values in one evaluation. Evaluate each run/version separately.")
    request_locations = {}
    for result in executed:
        for turn_index, turn in enumerate(result.get("turns", []), 1):
            request_id = turn.get("trace", {}).get("request_id", "")
            if request_id.strip():
                request_locations.setdefault(request_id, []).append((result["case_id"], turn_index))
    repeated_requests = {key: value for key, value in request_locations.items() if len(value) > 1}
    rows=[]; checks=[]; latencies=[]; tokens=[]; ttfts=[]; complete_runtime=0; kinds=set(); timing_groups={}
    for c in selected:
        result=index.get(c["case_id"])
        if result is None or empty_envelope(result):
            rows.append(dict(case_id=c["case_id"],split=c["split"],critical=c["critical"],
                             status="NOT_RUN",failures=[],missing=["system result"]))
            continue
        failures=[];missing=[];meta=result.get("metadata",{})
        for request_id, locations in repeated_requests.items():
            if any(case_id == c["case_id"] for case_id, _ in locations):
                failures.append(f"duplicate request_id in this run: {request_id}")
        kinds.add(meta.get("result_kind"))
        for key in ["run_id","code_version","model_version","prompt_version","data_version"]:
            if not isinstance(meta.get(key),str) or not meta[key].strip(): missing.append(f"metadata.{key}")
        for key,value in [("dataset_id",manifest["dataset_id"]),("case_sha256",manifest["case_sha256"]),
                          ("fixture_sha256",manifest["fixture_sha256"])]:
            if key not in meta: missing.append(f"metadata.{key}")
            elif meta[key]!=value: failures.append(f"metadata.{key} mismatch")
        if meta.get("result_kind") not in {"system","mock"}: missing.append("metadata.result_kind")
        turns=result.get("turns")
        if not isinstance(turns,list):
            turns=[];missing.append("turns")
        if len(turns)<len(c["steps"]): missing.append("one or more expected turns")
        if len(turns)>len(c["steps"]): failures.append("unexpected extra turns")
        for skipped in c["steps"][len(turns):]:
            checks.append(dict(field_correct=0,field_total=len(skipped["expected"].get("state",{})),
                hard_violations=0,hard_assessed=0,ndcg=None,recall=None,
                field_breakdown={k:[0,1] for k in skipped["expected"].get("state",{})}))
        for i in range(min(len(turns),len(c["steps"]))):
            t=check_turn(c,i,turns[i],fixture);checks.append(t)
            failures.extend(f"turn {i+1}: {e}" for e in t["failures"])
            missing.extend(f"turn {i+1}: {e}" for e in t["missing"])
            trace=turns[i].get("trace",{})
            ep=trace.get("evidence_path","")
            p=Path(ep) if ep else None
            if p is not None and not p.is_absolute():p=Path(root)/p
            if p is None or not p.is_file():missing.append(f"turn {i+1}: existing trace evidence file")
            elif not p.stat().st_size:missing.append(f"turn {i+1}: nonempty trace evidence file")
            elif trace.get("evidence_sha256") and hashlib.sha256(p.read_bytes()).hexdigest()!=trace["evidence_sha256"]:
                failures.append(f"turn {i+1}: trace evidence hash mismatch")
        failures.extend(action_failures(turns))
        runtime=result.get("runtime",{})
        e2e=runtime.get("e2e_ms")
        valid_time=type(e2e) in (int,float) and math.isfinite(e2e) and e2e>=0
        if not valid_time: missing.append("runtime.e2e_ms")
        elif len(turns)==len(c["steps"]):
            latencies.append(e2e)
            timing_groups.setdefault(str(len(c["steps"])), []).append(e2e)
        token=runtime.get("total_tokens")
        if type(token) is int and token>=0:tokens.append(token)
        # Null means unavailable. Token coverage is reported, never converted to zero.
        elif token is not None: failures.append("runtime.total_tokens must be a nonnegative integer or null")
        ttft=runtime.get("ttft_ms")
        if type(ttft) in (int,float) and math.isfinite(ttft) and ttft>=0:ttfts.append(ttft)
        elif ttft is not None:failures.append("runtime.ttft_ms must be nonnegative or null")
        if valid_time and len(turns)==len(c["steps"]):complete_runtime+=1
        manual=manual_status(rev.get(c["case_id"]),root,result)
        if manual=="FAIL":failures.append("human review failed")
        if manual=="PENDING":missing.append("completed human review")
        if manual=="STALE":missing.append("human review bound to this run_id and result_sha256")
        status="FAIL" if failures else ("INCOMPLETE" if missing else "PASS")
        if meta.get("result_kind")=="mock":status="MOCK_ONLY"
        rows.append(dict(case_id=c["case_id"],split=c["split"],critical=c["critical"],
                         status=status,failures=failures,missing=missing))
    passed=sum(r["status"]=="PASS" for r in rows)
    field_total=sum(t["field_total"] for t in checks)
    field_correct=sum(t["field_correct"] for t in checks)
    field_breakdown={}
    for t in checks:
        for key,(correct,total) in t.get("field_breakdown",{}).items():
            value=field_breakdown.setdefault(key,dict(correct=0,total=0))
            value["correct"]+=correct;value["total"]+=total
    for value in field_breakdown.values():value["accuracy"]=value["correct"]/value["total"]
    hard_total=sum(t["hard_assessed"] for t in checks)
    hard_bad=sum(t["hard_violations"] for t in checks)
    rank=[t["ndcg"] for t in checks if t["ndcg"] is not None]
    recall=[t["recall"] for t in checks if t["recall"] is not None]
    mock="mock" in kinds
    critical=[r for r in rows if r["critical"]]
    summary=dict(
        dataset_id=manifest["dataset_id"],scope=split,
        run_metadata={key: next(iter(values)) if len(values) == 1 else None
                      for key in ["run_id", "code_version", "model_version", "prompt_version", "data_version"]
                      for values in [{r.get("metadata", {}).get(key) for r in executed if r.get("metadata", {}).get(key)}]},
        result_kind="MOCK_ONLY" if mock else ("SYSTEM_RESULTS" if executed else "NOT_RUN"),
        planned_cases=len(rows),passed_cases=passed,
        fail_cases=sum(r["status"]=="FAIL" for r in rows),
        not_run_cases=sum(r["status"]=="NOT_RUN" for r in rows),
        incomplete_cases=sum(r["status"]=="INCOMPLETE" for r in rows),
        case_success_rate=passed/len(rows) if rows else None,
        critical_passed=sum(r["status"]=="PASS" for r in critical),critical_total=len(critical),
        field_correct=field_correct,field_total=field_total,
        field_accuracy=field_correct/field_total if field_total else None,
        field_breakdown=field_breakdown,
        hard_constraint_violations=hard_bad,shortlisted_items_assessed=hard_total,
        hard_violation_rate=hard_bad/hard_total if hard_total else None,
        ndcg_at_5=statistics.mean(rank) if rank else None,ranking_samples=len(rank),
        candidate_recall=statistics.mean(recall) if recall else None,recall_samples=len(recall),
        e2e_p50_ms=percentile(latencies,.5),e2e_p95_ms=percentile(latencies,.95),
        runtime_by_planned_turn_count={k:dict(samples=len(v),e2e_p50_ms=percentile(v,.5),e2e_p95_ms=percentile(v,.95)) for k,v in sorted(timing_groups.items())},
        runtime_samples=complete_runtime,total_tokens=sum(tokens) if tokens else None,
        token_samples=len(tokens),ttft_p50_ms=percentile(ttfts,.5),ttft_samples=len(ttfts),
        run_readiness="MOCK_NOT_SYSTEM_EVIDENCE" if mock else (
            "CHECKS_COMPLETE_FOR_TEAM_REVIEW" if rows and all(r["status"]=="PASS" for r in rows)
            else "INCOMPLETE_OR_FAILED"),
        project_acceptance="NOT_DETERMINED_BY_HARNESS",
        outstanding_project_gates=["Team-approved scope, policy and thresholds",
            "Open S1/S2 defect review","UAT records","Final team acceptance decision"],
        notes=["A checked structured claim list does not prove that all free-text claims were captured.",
               "Recall uses the full eligible candidate set in the declared fixture pool, not the top-K shortlist.",
               "Metrics include observed labelled turns; incomplete cases stay in the planned-case success denominator.",
               "Mock-only metrics are harness diagnostics and must not appear as system evaluation findings."])
    return dict(summary=summary,cases=rows)

def runner_inputs(cases, split):
    """Input-only export. Gold fields and case titles stay with QA."""
    for case in cases:
        if split != "all" and case["split"] != split:
            continue
        yield dict(case_id=case["case_id"], setup=case["setup"], fault_injection=case["fault_injection"],
                   steps=[{k: copy.deepcopy(s[k]) for k in ["user_input", "session_id", "fixture_pool"] if k in s}
                          for s in case["steps"]])

def review_scaffold(results):
    validate_result_shape(results)
    unique_index(results, "case_id", "results")
    return dict(instructions="Review actual outputs and raw evidence. Each review is bound to this run and exact result record.",
                reviews=[dict(case_id=r["case_id"], run_id=r.get("metadata", {}).get("run_id", ""),
                    result_sha256=result_sha256(r), status="PENDING", reviewer="", evidence="",
                    factuality="PENDING", task_behavior="PENDING", clarity_score=None, notes="")
                    for r in results if not empty_envelope(r)])

def scaffold(cases,manifest,split):
    for c in cases:
        if split!="all" and c["split"]!=split:continue
        yield dict(case_id=c["case_id"],metadata=dict(
            result_kind="system",run_id="",code_version="",model_version="",prompt_version="",
            data_version="",dataset_id=manifest["dataset_id"],
            case_sha256=manifest["case_sha256"],fixture_sha256=manifest["fixture_sha256"]),
            turns=[dict(response_text="",trace=dict(session_id=s["session_id"],request_id="",
                        evidence_path="",evidence_sha256="",agents=[],tool_calls=[]))
                   for s in c["steps"]],
            runtime=dict(e2e_ms=None,ttft_ms=None,total_tokens=None))

def mock_results(cases,manifest,evidence_path):
    """Copies gold into explicitly marked mock outputs to exercise the evaluator."""
    for c in cases:
        turns=[]
        sent=set()
        for i,s in enumerate(c["steps"]):
            turn=copy.deepcopy(s["expected"])
            turn.pop("relevance",None)
            turn.setdefault("claims",[])
            turn.setdefault("actions",[])
            for a in turn["actions"]:
                a["approved_recipient"]=a["recipient"] if a["approval_state"]=="approved" else None
            turn["response_text"]="MOCK OUTPUT copied from expected fields. No system executed."
            turn["trace"]=dict(session_id=s["session_id"],request_id=f"mock-{c['case_id']}-{i+1}",
                evidence_path=str(evidence_path),evidence_sha256=hashlib.sha256(Path(evidence_path).read_bytes()).hexdigest(),agents=[dict(name="mock",start_ms=0,end_ms=1)],
                tool_calls=[])
            calls=turn["trace"]["tool_calls"]
            def call(name,success=True,arguments=None,sources=None,error=None,side_effect=False):
                calls.append(dict(call_id=f"mock-{c['case_id']}-{i+1}-{len(calls)+1}",name=name,
                    success=success,arguments=arguments or {},result_source_ids=sources or [],
                    side_effect=side_effect,error_code=error))
            if "hard_constraints" in s:
                call("listing_search",sources=[f"fixture:{x}" for x in turn["eligible_ids"]])
            if turn.get("error_code"):
                call("listing_search",False,error=turn["error_code"])
            if "graph_edge_ids" in turn:
                ok=c.get("fault_injection",{}).get("graph")!="timeout"
                call("graph_query",ok,sources=[f"fixture:graph:{x}" for x in turn["graph_edge_ids"]],
                     error=None if ok else "GRAPH_TIMEOUT")
            if turn.get("claims") and "hard_constraints" not in s:
                call("listing_lookup",sources=sorted({x["source_id"] for x in turn["claims"]}))
            for a in turn["actions"]:
                if a["executed"] and a["action_id"] not in sent:
                    call(a.get("action_type","message_send"),arguments=dict(action_id=a["action_id"],
                         content_hash=a["content_hash"],recipient=a["recipient"]),side_effect=True)
                    sent.add(a["action_id"])
            turns.append(turn)
        yield dict(case_id=c["case_id"],metadata=dict(result_kind="mock",run_id="mock-only",
            code_version="mock",model_version="none",prompt_version="none",data_version="synthetic",
            dataset_id=manifest["dataset_id"],case_sha256=manifest["case_sha256"],
            fixture_sha256=manifest["fixture_sha256"]),
            turns=turns,runtime=dict(e2e_ms=1,total_tokens=None,ttft_ms=None))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,default=ROOT)
    sub=p.add_subparsers(dest="command",required=True)
    sub.add_parser("validate",help="Validate fixture integrity and gold consistency.")
    s=sub.add_parser("scaffold",help="Create an empty system-result envelope.")
    s.add_argument("--split",choices=["development","holdout","all"],default="development")
    s.add_argument("--out",type=Path,required=True)
    r=sub.add_parser("runner",help="Export input-only cases for the integration owner.")
    r.add_argument("--split",choices=["development","holdout","all"],default="development")
    r.add_argument("--out",type=Path,required=True)
    r=sub.add_parser("review-scaffold",help="Create pending reviews bound to actual result records.")
    r.add_argument("--results",type=Path,required=True)
    r.add_argument("--out",type=Path,required=True)
    e=sub.add_parser("evaluate",help="Check exported system results without making model calls.")
    e.add_argument("--results",type=Path,required=True)
    e.add_argument("--reviews",type=Path)
    e.add_argument("--split",choices=["development","holdout","all"],default="holdout")
    e.add_argument("--out",type=Path,required=True)
    d=sub.add_parser("demo",help="Exercise the harness with MOCK_ONLY outputs.")
    d.add_argument("--out",type=Path,required=True)
    args=p.parse_args()
    try:
        cases,fixture,manifest=load(args.root)
        validation=validate_dataset(cases,fixture,manifest,args.root)
        if args.command=="validate":
            print(json.dumps(validation,indent=2));return 0
        ensure_fresh_output(args.out)
        if args.command in {"scaffold", "runner"}:
            args.out.parent.mkdir(parents=True,exist_ok=True)
            records = scaffold(cases,manifest,args.split) if args.command == "scaffold" else runner_inputs(cases,args.split)
            args.out.write_text("".join(json.dumps(r)+"\n" for r in records),encoding="utf-8")
            print(f"{args.command} records written to {args.out}. No system was executed.");return 0
        if args.command=="review-scaffold":
            write_json(args.out, review_scaffold(read_jsonl(args.results)))
            print(f"Pending reviews written to {args.out}. No review was performed.");return 0
        if args.command=="demo":
            args.out.mkdir(parents=True,exist_ok=True)
            evidence=args.out.resolve()/"MOCK_EVIDENCE.txt"
            evidence.write_text("Mock-only harness diagnostic. Not a system test.\n",encoding="utf-8")
            result=evaluate(cases,fixture,manifest,list(mock_results(cases,manifest,evidence)),
                            split="all",root=args.root)
        else:
            reviews=read_reviews(args.reviews) if args.reviews else []
            result=evaluate(cases,fixture,manifest,read_jsonl(args.results),reviews,
                            split=args.split,root=args.root)
            args.out.mkdir(parents=True,exist_ok=True)
        write_json(args.out/"summary.json",result["summary"])
        write_json(args.out/"case_results.json",result["cases"])
        with (args.out/"case_results.csv").open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f);w.writerow(["case_id","split","critical","status","failures","missing"])
            for r in result["cases"]:w.writerow([r[k] if k not in {"failures","missing"} else
                " | ".join(r[k]) for k in ["case_id","split","critical","status","failures","missing"]])
        inputs = {}
        if args.command == "evaluate":
            for label, path in [("results", args.results), ("reviews", args.reviews)]:
                if path is not None:
                    inputs[label] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        write_json(args.out/"evaluation_manifest.json", dict(
            pack_version=manifest["pack_version"], dataset_id=manifest["dataset_id"],
            case_sha256=manifest["case_sha256"], fixture_sha256=manifest["fixture_sha256"],
            result_kind=result["summary"]["result_kind"], scope=result["summary"]["scope"],
            run_metadata=result["summary"]["run_metadata"], inputs=inputs,
            outputs={name: hashlib.sha256((args.out/name).read_bytes()).hexdigest()
                     for name in ["summary.json", "case_results.json", "case_results.csv"]},
            project_acceptance="NOT_DETERMINED_BY_HARNESS"))
        print(json.dumps(result["summary"],indent=2))
        if result["summary"]["result_kind"]=="MOCK_ONLY":return 3
        if result["summary"]["fail_cases"]:return 1
        if any(r["status"]!="PASS" for r in result["cases"]):return 2
        return 0
    except (ValueError,KeyError,TypeError,OSError) as err:
        print(f"QA input error: {err}",file=sys.stderr);return 4

if __name__=="__main__":
    raise SystemExit(main())
