GROUP 42 TESTING AND ACCEPTANCE PACK 1.2

Open 00_Start_Here.html for commands and 06_QA_Owner_Playbook.html for your next actions.
All materials are English. Actual system testing and UAT remain NOT_RUN.

New in 1.2
- Owner meeting agenda, working procedure and eight exact UAT scripts.
- Separate participant cards and 16 blank participant/task planning rows.
- UAT clarity scores enforce integers from 1 to 5. Incomplete defects remain visible.
- Duplicate request IDs and empty trace files cannot support a passing result.
- Existing exports, reviews and evaluation folders are protected from replacement.
- Every evaluation includes an input/output hash manifest and run configuration.

The formal plan, report template and presentation retain their version 1.1 baseline.
Their proposed criteria remain unchanged. The package, workbook, evaluator,
handoff and working guides are version 1.2. Cases and fixtures retain the frozen
G42-SYNTH-20261010-v1 identifiers and hashes.

Use the workbook for decisions, cases, UAT, defects and acceptance gates.
Share only 05_Developer_Handoff.zip for routine development integration.
QA retains holdout inputs and gold answers until the agreed final evaluation.
The participant cards reuse evaluation scenarios. Release them only for the
agreed final evaluation and UAT, and record earlier exposure.

Python 3.10+ standard library is sufficient. No API keys are needed.
Dataset check: python3 scripts/qa.py validate
Evaluator self-tests: python3 -m unittest discover -s tests -v
Use a new output path for every run, human review and evaluation.
The checker makes no model calls, sends no messages and books no calendars.
