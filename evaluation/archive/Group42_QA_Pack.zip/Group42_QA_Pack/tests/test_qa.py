"""Tests of the QA harness. These do not test the real estate system."""
import copy
import importlib.util
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("qa",ROOT/"scripts/qa.py")
qa=importlib.util.module_from_spec(spec)
spec.loader.exec_module(qa)

class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.cases,self.fixture,self.manifest=qa.load(ROOT)
        self.tmp=tempfile.TemporaryDirectory()
        self.evidence=Path(self.tmp.name)/"trace.txt"
        self.evidence.write_text("Harness unit-test evidence only.",encoding="utf-8")
        self.outputs=list(qa.mock_results(self.cases,self.manifest,self.evidence))

    def tearDown(self):
        self.tmp.cleanup()

    def result(self,id_):
        return next(x for x in self.outputs if x["case_id"]==id_)

    def reviews(self, outputs=None):
        outputs = self.system_like() if outputs is None else outputs
        return [dict(case_id=r["case_id"], run_id=r["metadata"]["run_id"], result_sha256=qa.result_sha256(r),
                     status="PASS",reviewer="UNIT_TEST_ONLY",
                     factuality="PASS",task_behavior="PASS",clarity_score=4,
                     evidence=str(self.evidence)) for r in outputs]

    def system_like(self):
        # A local test fixture, never written to the deliverable as actual system results.
        outputs=copy.deepcopy(self.outputs)
        for x in outputs:x["metadata"]["result_kind"]="system"
        return outputs

    def test_frozen_dataset_and_coverage(self):
        result=qa.validate_dataset(self.cases,self.fixture,self.manifest,ROOT)
        self.assertEqual(result["cases"],60)
        self.assertEqual(result["requirements"],14)
        self.assertEqual(result["system_testing"],"NOT_RUN")

    def test_price_and_walk_boundary_and_missing_value(self):
        index={x["listing_id"]:x for x in self.fixture["listings"]}
        constraints={"budget_max_sgd":3500,"mrt_walk_max_min":10}
        self.assertTrue(qa.eligible(index["P005"],constraints))
        self.assertFalse(qa.eligible(index["P006"],constraints))
        self.assertFalse(qa.eligible(index["P011"],constraints))
        self.assertFalse(qa.eligible(index["P012"],constraints))
        self.assertFalse(qa.eligible(index["P015"],constraints))

    def test_mock_never_becomes_system_acceptance(self):
        report=qa.evaluate(self.cases,self.fixture,self.manifest,self.outputs,self.reviews(),"all",ROOT)
        self.assertEqual(report["summary"]["passed_cases"],0)
        self.assertEqual(report["summary"]["run_readiness"],"MOCK_NOT_SYSTEM_EVIDENCE")
        self.assertTrue(all(not r["failures"] for r in report["cases"]))
        self.assertTrue(all(r["status"]=="MOCK_ONLY" for r in report["cases"]))

    def test_no_results_stays_not_run(self):
        report=qa.evaluate(self.cases,self.fixture,self.manifest,[],split="holdout",root=ROOT)
        self.assertEqual(report["summary"]["planned_cases"],40)
        self.assertEqual(report["summary"]["not_run_cases"],40)
        self.assertEqual(report["summary"]["case_success_rate"],0)
        self.assertIsNone(report["summary"]["field_accuracy"])

    def test_missing_human_review_prevents_pass(self):
        report=qa.evaluate(self.cases,self.fixture,self.manifest,self.system_like(),split="all",root=ROOT)
        self.assertEqual(report["summary"]["passed_cases"],0)
        self.assertEqual(report["summary"]["incomplete_cases"],60)

    def test_complete_test_fixture_can_pass_checks_but_not_approve_project(self):
        report=qa.evaluate(self.cases,self.fixture,self.manifest,self.system_like(),self.reviews(),"all",ROOT)
        self.assertEqual(report["summary"]["passed_cases"],60)
        self.assertEqual(report["summary"]["project_acceptance"],"NOT_DETERMINED_BY_HARNESS")

    def test_wrong_budget_detected(self):
        rows=self.system_like()
        rows[0]["turns"][0]["state"]["budget_max_sgd"]=3600
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"FAIL")
        self.assertLess(report["summary"]["field_accuracy"],1)

    def test_hard_violation_and_duplicate_shortlist_detected(self):
        rows=self.system_like()
        rows[0]["turns"][0]["shortlist_ids"]=["P001","P002","P002"]
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"FAIL")
        self.assertEqual(report["summary"]["hard_constraint_violations"],2)

    def test_tool_side_effect_cannot_hide_outside_action_log(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC041")
        target["turns"][0]["trace"]["tool_calls"].append(dict(
            call_id="bad-send",name="message_send",success=True,side_effect=True,
            arguments={"action_id":"HIDDEN","content_hash":"v1","recipient":"x"},result_source_ids=[]))
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        row=next(x for x in report["cases"] if x["case_id"]=="TC041")
        self.assertEqual(row["status"],"FAIL")

    def test_changed_hash_invalidates_approval(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC038")
        target["turns"][1]["actions"][0]["content_hash"]="changed-after-approval"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC038")["status"],"FAIL")

    def test_executed_action_requires_tool_evidence(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC038")
        target["turns"][1]["trace"]["tool_calls"]=[]
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC038")["status"],"FAIL")

    def test_duplicate_result_ids_rejected(self):
        with self.assertRaisesRegex(ValueError,"duplicate"):
            qa.evaluate(self.cases,self.fixture,self.manifest,[self.outputs[0],self.outputs[0]],root=ROOT)

    def test_wrong_dataset_hash_detected(self):
        rows=self.system_like()
        rows[0]["metadata"]["fixture_sha256"]="wrong"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"FAIL")

    def test_missing_turns_and_missing_evidence_prevent_pass(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC009")
        target["turns"].pop()
        rows[0]["turns"][0]["trace"]["evidence_path"]="missing-file.txt"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"INCOMPLETE")
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC009")["status"],"INCOMPLETE")

    def test_numeric_bool_is_not_a_budget_and_ndcg(self):
        self.assertFalse(qa.equal(True,1))
        self.assertAlmostEqual(qa.ndcg(["P001","P019"],{"P001":3,"P019":1}),1)
        self.assertLess(qa.ndcg(["P019","P001"],{"P001":3,"P019":1}),1)
        self.assertIsNone(qa.ndcg([],{}))
        self.assertIsNone(qa.ndcg(["P001","P001"],{"P001":3}))

    def test_review_is_bound_to_run_and_exact_output(self):
        rows=self.system_like()
        reviews=self.reviews(rows)
        rows[0]["turns"][0]["response_text"]="Changed after human review"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,reviews,"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"INCOMPLETE")
        self.assertTrue(any("result_sha256" in s for s in report["cases"][0]["missing"]))
        rows=self.system_like()
        reviews=self.reviews(rows)
        reviews[0]["run_id"]="previous-run"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,reviews,"all",ROOT)
        self.assertEqual(report["cases"][0]["status"],"INCOMPLETE")
        rows=self.system_like()
        rows[0]["metadata"]["run_id"]="new-run"
        with self.assertRaisesRegex(ValueError,"Mixed run_id"):
            qa.evaluate(self.cases,self.fixture,self.manifest,rows,reviews,"all",ROOT)

    def test_runner_inputs_do_not_export_gold(self):
        rows=list(qa.runner_inputs(self.cases,"holdout"))
        self.assertEqual(len(rows),40)
        for row in rows:
            self.assertEqual(set(row),{"case_id","setup","fault_injection","steps"})
            for step in row["steps"]:
                self.assertNotIn("expected",step)
                self.assertNotIn("hard_constraints",step)
                self.assertLessEqual(set(step),{"user_input","session_id","fixture_pool"})

    def test_empty_scaffold_is_not_an_executed_failure(self):
        rows=list(qa.scaffold(self.cases,self.manifest,"development"))
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,split="development",root=ROOT)
        self.assertEqual(report["summary"]["result_kind"],"NOT_RUN")
        self.assertEqual(report["summary"]["not_run_cases"],20)
        self.assertIsNone(report["summary"]["field_accuracy"])
        self.assertEqual(qa.review_scaffold(rows)["reviews"],[])
        rows[0]["turns"][0]["actions"]=[{"action_id":"unexpected"}]
        self.assertFalse(qa.empty_envelope(rows[0]))

    def test_review_scaffold_records_binding_without_review(self):
        rows=self.system_like()[:1]
        review=qa.review_scaffold(rows)["reviews"][0]
        self.assertEqual(review["run_id"],rows[0]["metadata"]["run_id"])
        self.assertEqual(review["result_sha256"],qa.result_sha256(rows[0]))
        self.assertEqual(review["status"],"PENDING")
        self.assertEqual(review["reviewer"],"")

    def test_mixed_system_and_mock_or_builds_rejected(self):
        for field,value in [("result_kind","mock"),("code_version","other-build"),("model_version","other-model")]:
            rows=self.system_like()
            rows[0]["metadata"][field]=value
            with self.assertRaisesRegex(ValueError,"Mixed"):
                qa.evaluate(self.cases,self.fixture,self.manifest,rows,split="all",root=ROOT)

    def test_malformed_exports_report_input_errors(self):
        for key,value in [("turns",[None]),("metadata",None),("runtime",[])]:
            rows=self.system_like()[:1]
            rows[0][key]=value
            with self.assertRaises(ValueError):
                qa.evaluate(self.cases,self.fixture,self.manifest,rows,root=ROOT)
        rows=self.system_like()[:1]
        rows[0]["turns"][0]["shortlist_ids"]=[{"id":"P001"}]
        with self.assertRaisesRegex(ValueError,"string entries"):
            qa.evaluate(self.cases,self.fixture,self.manifest,rows,root=ROOT)

    def test_failed_or_unrelated_tool_does_not_support_claim(self):
        for changes in [{"success":False,"error_code":"TIMEOUT"},{"name":"unrelated_tool"}]:
            rows=self.system_like()
            target=next(x for x in rows if x["case_id"]=="TC029")
            target["turns"][0]["trace"]["tool_calls"][0].update(changes)
            report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
            row=next(x for x in report["cases"] if x["case_id"]=="TC029")
            self.assertEqual(row["status"],"FAIL")
            self.assertTrue(any("no source" in f for f in row["failures"]))

    def test_duplicate_action_ids_rejected(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC037")
        target["turns"][0]["actions"]*=2
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertTrue(any("duplicate action" in f for r in report["cases"] for f in r["failures"]))

    def test_nonfinite_json_and_eligibility_are_rejected(self):
        path=Path(self.tmp.name)/"bad.jsonl"
        path.write_text('{"value":NaN}\n')
        with self.assertRaisesRegex(ValueError,"Non-finite"):
            qa.read_jsonl(path)
        listing=copy.deepcopy(self.fixture["listings"][0])
        listing["monthly_rent_sgd"]=float("nan")
        self.assertFalse(qa.eligible(listing,{"budget_max_sgd":3500}))

    def test_changed_raw_evidence_does_not_keep_passing(self):
        rows=self.system_like()
        reviews=self.reviews(rows)
        self.evidence.write_text("Changed after capture")
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,reviews,"all",ROOT)
        self.assertEqual(report["summary"]["passed_cases"],0)
        self.assertTrue(all(any("evidence hash mismatch" in f for f in r["failures"]) for r in report["cases"]))

    def test_partial_timing_does_not_distort_complete_case_latency(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC009")
        target["turns"].pop()
        target["runtime"]["e2e_ms"]=999999
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertEqual(report["summary"]["runtime_samples"],59)
        self.assertEqual(report["summary"]["e2e_p95_ms"],1)
        groups=report["summary"]["runtime_by_planned_turn_count"]
        self.assertEqual(sum(g["samples"] for g in groups.values()),59)

    def test_missing_token_usage_is_not_zero(self):
        report=qa.evaluate(self.cases,self.fixture,self.manifest,self.outputs,split="all",root=ROOT)
        self.assertIsNone(report["summary"]["total_tokens"])
        self.assertEqual(report["summary"]["token_samples"],0)

    def test_changed_recipient_invalidates_approval(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC038")
        target["turns"][1]["actions"][0]["recipient"]="different-recipient"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC038")["status"],"FAIL")

    def test_claim_requires_source_in_tool_result(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC029")
        target["turns"][0]["trace"]["tool_calls"][0]["result_source_ids"]=[]
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC029")["status"],"FAIL")

    def test_calendar_action_uses_calendar_tool(self):
        target=self.result("TC042")
        self.assertEqual(target["turns"][-1]["trace"]["tool_calls"][-1]["name"],"calendar_book")
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC042")
        target["turns"][-1]["trace"]["tool_calls"][-1]["name"]="message_send"
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(),"all",ROOT)
        self.assertEqual(next(x for x in report["cases"] if x["case_id"]=="TC042")["status"],"FAIL")

    def test_request_ids_cannot_be_reused_across_turns_or_cases(self):
        rows=self.system_like()
        target=next(x for x in rows if x["case_id"]=="TC009")
        target["turns"][1]["trace"]["request_id"]=target["turns"][0]["trace"]["request_id"]
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertTrue(any("duplicate request_id" in f for r in report["cases"] if r["case_id"]=="TC009" for f in r["failures"]))
        rows=self.system_like()
        rows[1]["turns"][0]["trace"]["request_id"]=rows[0]["turns"][0]["trace"]["request_id"]
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertEqual([r["status"] for r in report["cases"][:3]],["FAIL","FAIL","PASS"])

    def test_empty_trace_file_cannot_complete_a_case(self):
        self.evidence.write_text("")
        rows=self.system_like()
        for row in rows:
            for turn in row["turns"]:
                turn["trace"]["evidence_sha256"]=hashlib.sha256(b"").hexdigest()
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertEqual(report["summary"]["passed_cases"],0)
        self.assertTrue(all(any("nonempty trace" in m for m in r["missing"]) for r in report["cases"]))

    def test_human_review_types_and_ordinal_scores(self):
        for score in [4.5,6,True,"4"]:
            reviews=self.reviews();reviews[0]["clarity_score"]=score
            with self.subTest(score=score), self.assertRaisesRegex(ValueError,"clarity_score"):
                qa.evaluate(self.cases,self.fixture,self.manifest,self.system_like(),reviews,"all",ROOT)
        path=Path(self.tmp.name)/"reviews.json";path.write_text('[]')
        with self.assertRaisesRegex(ValueError,"reviews array"):
            qa.read_reviews(path)
        reviews=self.reviews();reviews[0]["evidence"]=[]
        with self.assertRaisesRegex(ValueError,"evidence"):
            qa.evaluate(self.cases,self.fixture,self.manifest,self.system_like(),reviews,"all",ROOT)

    def test_summary_identifies_the_evaluated_run(self):
        rows=self.system_like()
        report=qa.evaluate(self.cases,self.fixture,self.manifest,rows,self.reviews(rows),"all",ROOT)
        self.assertEqual(report["summary"]["run_metadata"]["run_id"],rows[0]["metadata"]["run_id"])
        empty=qa.evaluate(self.cases,self.fixture,self.manifest,[],split="all",root=ROOT)
        self.assertTrue(all(v is None for v in empty["summary"]["run_metadata"].values()))

    def test_cli_preserves_existing_outputs(self):
        existing=Path(self.tmp.name)/"saved.jsonl";existing.write_text("DO NOT REPLACE")
        output_dir=Path(self.tmp.name)/"saved_evaluation";output_dir.mkdir()
        sentinel=output_dir/"summary.json";sentinel.write_text("DO NOT REPLACE")
        inputs=Path(self.tmp.name)/"outputs.jsonl"
        inputs.write_text(''.join(json.dumps(r)+'\n' for r in self.system_like()))
        commands=[
            ["scaffold","--out",str(existing)], ["runner","--out",str(existing)],
            ["review-scaffold","--results",str(inputs),"--out",str(existing)],
            ["evaluate","--results",str(inputs),"--split","all","--out",str(output_dir)],
            ["demo","--out",str(output_dir)]]
        for command in commands:
            with self.subTest(command=command[0]):
                process=subprocess.run([sys.executable,str(ROOT/"scripts/qa.py"),*command],capture_output=True,text=True)
                self.assertEqual(process.returncode,4)
                self.assertIn("Output already exists",process.stderr)
                self.assertEqual(existing.read_text(),"DO NOT REPLACE")
                self.assertEqual(sentinel.read_text(),"DO NOT REPLACE")

    def test_cli_evaluation_manifest_hashes_outputs_and_inputs(self):
        result_file=Path(self.tmp.name)/"empty.jsonl"
        result_file.write_text(''.join(json.dumps(r)+'\n' for r in qa.scaffold(self.cases,self.manifest,"development")))
        out=Path(self.tmp.name)/"evaluation"
        process=subprocess.run([sys.executable,str(ROOT/"scripts/qa.py"),"evaluate","--results",str(result_file),
                                "--split","development","--out",str(out)],capture_output=True,text=True)
        self.assertEqual(process.returncode,2,process.stderr)
        manifest=json.loads((out/"evaluation_manifest.json").read_text())
        self.assertEqual(manifest["result_kind"],"NOT_RUN")
        self.assertEqual(manifest["inputs"]["results"]["sha256"],hashlib.sha256(result_file.read_bytes()).hexdigest())
        for name,digest in manifest["outputs"].items():
            self.assertEqual(digest,hashlib.sha256((out/name).read_bytes()).hexdigest())

    def test_cli_malformed_review_file_reports_controlled_error(self):
        result_file=Path(self.tmp.name)/"outputs.jsonl"
        result_file.write_text(''.join(json.dumps(r)+'\n' for r in self.system_like()))
        reviews=Path(self.tmp.name)/"bad_reviews.json";reviews.write_text('[]')
        process=subprocess.run([sys.executable,str(ROOT/"scripts/qa.py"),"evaluate","--results",str(result_file),
                                "--reviews",str(reviews),"--split","all","--out",str(Path(self.tmp.name)/"bad_eval")],capture_output=True,text=True)
        self.assertEqual(process.returncode,4)
        self.assertNotIn("Traceback",process.stderr)

if __name__=="__main__":
    unittest.main()
