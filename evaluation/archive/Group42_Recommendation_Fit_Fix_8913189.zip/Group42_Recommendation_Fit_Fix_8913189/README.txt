GROUP 42 TESTING AND ACCEPTANCE PACK VERSION 3.6

The local recommendation-fit remediation passed all 44 unchanged frozen cases:
24 structured matches, 8 projection checks and 12 actual model dialogue turns.
The eight original failed turns now pass. Independent checks found zero hard
requirement violations in 36 verified dialogue occurrences. This is an authored
contract-fit regression sample, not a population accuracy or satisfaction score.

01_Latest_Testing_and_Acceptance_Report.docx is the 14-page English report.
02_Latest_Acceptance_Tracker.xlsx has current results, formulas, fix dispositions,
the eight original failure rows and untouched human-review fields.
03_Recommendation_Fit_Catalogue.txt retains the original v3.5 baseline.
04_Recommendation_Fit_Retest_Catalogue.txt contains the current 44-case retest.
code/recommendation-fit-fix.patch and code/patched contain the verified local fix.
evidence/recommendation_fit is the unchanged original 36/44 baseline.
evidence/recommendation_fit_fix is the separate 44/44 retest and code-check evidence.
Earlier evidence, including the 140-case extension, retains its historical scope.

Source base: 89131897f56bbc176c30246a451f118f7de0209f. Six existing files changed
and four were added. Patch application was checked on a clean baseline and the
resulting files match the tested checkout. The original upstream manifest stays
intact; one exact downstream controller patch is separately declared and checked.
The local changes have not been pushed to GitHub.

Code regression: TypeScript 168 passed / 19 skipped; Python 216 passed / 3 skipped.
Two typechecks and the standard TypeScript build passed. The 26 added regressions
are supporting code checks, not additional cases in the 44-case fit catalogue.

DEF09-DEF12 are VERIFIED_LOCAL_FIX. Five earlier issues, DEF04-DEF08, remain open.
Repository integration, participant UAT, agreed performance acceptance, Windows
verification and final team signoff remain pending. No external message was sent.
User relevance ratings and human review/signature fields remain blank.

The latest model phase recorded 86 attempts, 85 HTTP 200 responses and one
transport timeout followed by retry. Reported usage was 264,915 tokens and provider
reference cost USD 0.020249052. This is not a verified subscription charge.
Owned services and QA database containers were stopped. Credentials, .env files,
database files, model weights, owner tokens and rendering intermediates are excluded.

This focused package includes the original failed dialogue evidence; the complete earlier evidence is in Group42_Latest_Acceptance_8913189.zip.
