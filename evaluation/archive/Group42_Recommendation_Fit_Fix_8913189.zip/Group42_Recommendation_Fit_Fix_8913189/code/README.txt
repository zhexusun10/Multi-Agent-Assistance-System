GROUP 42 RECOMMENDATION FIT FIX

Base: 89131897f56bbc176c30246a451f118f7de0209f
The local patch passed all 44 frozen recommendation-fit cases. It has not been
pushed to GitHub. Review it before merging into the team branch.

From a clean checkout of the base revision, create a codex/recommendation-fit-fixes
branch, then run git apply --check and git apply with recommendation-fit-fix.patch.
The patched/ folder provides the same ten files for direct review. Do not combine
manual file replacement with applying the patch to the same checkout.

Validation commands after installing the project dependencies:
  node node_modules/typescript/lib/tsc.js --noEmit
  node node_modules/typescript/lib/tsc.js --noEmit -p tsconfig.recommendation.json
  node --import tsx --test tests/*.test.ts
  python -m pytest data/tests recommendation/tests tests/test_api.py tests/test_webhook_gateway.py tests/test_native_transport.py tests/test_recommendation_provenance.py -q
  python scripts/import-recommendation-upstream.py --check

The upstream port manifest is unchanged. A separate downstream manifest declares
the controller fix with both original and patched hashes. The provenance checker
rejects undeclared changes, wrong bases and a reverted patch.

The frozen real-data/model harness and execution receipts are in
tools/recommendation_fit_fix and evidence/recommendation_fit_fix. Reproducing that
profile requires the fixed snapshot, PostgreSQL/Neo4j, Chroma/embedding cache and
the configured ClinePass transport and private environment; no credentials or
database files are supplied. The 44-case catalogue and oracle assertions are unchanged.

Earlier issues DEF04 to DEF08, participant UAT, formal performance acceptance,
Windows deployment verification and team signoff remain pending.
