from pathlib import Path
from zipfile import ZipFile
import json
from lxml import etree as E
from docx import Document

B=Path(__file__).resolve().parent
S=json.loads((B/'acceptance-summary.json').read_text());O=Path(S['output'])
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def workbook(p):
    result={}
    with ZipFile(p) as z:
        assert z.testzip() is None
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(si.itertext()) for si in E.fromstring(z.read('xl/sharedStrings.xml'))]
        names=[n.get('name') for n in E.fromstring(z.read('xl/workbook.xml')).find('m:sheets',NS)]
        for i,name in enumerate(names,1):
            root=E.fromstring(z.read(f'xl/worksheets/sheet{i}.xml'));cells={}
            for c in root.findall('.//m:c',NS):
                value=c.find('m:v',NS);value=value.text if value is not None else ''
                if c.get('t')=='s':value=strings[int(value)]
                elif c.get('t')=='inlineStr':value=''.join(c.find('m:is',NS).itertext())
                f=c.find('m:f',NS)
                cells[c.get('r')]=(value or '',f.text if f is not None else '')
                assert c.get('t')!='e',(name,c.get('r'),value)
            pane=root.find('m:sheetViews/m:sheetView/m:pane',NS)
            validations=[(v.get('sqref'),v.get('type'),v.findtext('m:formula1',namespaces=NS)) for v in root.findall('m:dataValidations/m:dataValidation',NS)]
            result[name]={'cells':cells,'pane':dict(pane.attrib) if pane is not None else None,'validations':validations}
        tables={E.fromstring(z.read(name)).get('name'):E.fromstring(z.read(name)).get('ref') for name in z.namelist() if name.startswith('xl/tables/table') and name.endswith('.xml')}
    return result,tables

old,old_tables=workbook(B/'before_update/02_Latest_Acceptance_Tracker.xlsx')
new,new_tables=workbook(O/'02_Latest_Acceptance_Tracker.xlsx')
assert list(new)==list(old)
def allowed(sheet,address):
    col=''.join(c for c in address if c.isalpha());row=int(''.join(c for c in address if c.isdigit()))
    if sheet=='Review':return address in ['A3','D9','D10','D20'] or col in ['C','D'] and 46<=row<=48
    if sheet=='Evidence':return address=='B192'
    if sheet=='Recommendation Fit':return address in ['A2','A3','A9','A58'] or 12<=row<=55 and col in 'ABCDEFG' or 62<=row<=65 and col in 'CDEFG'
    return False
unchanged=0
for sheet,data in old.items():
    assert new[sheet]['pane']==data['pane'],sheet+' panes'
    assert new[sheet]['validations']==data['validations'],sheet+' validation'
    for address,value in data['cells'].items():
        if sheet=='Recommendation Fit' and address in ['D8','E8','F8']:
            assert new[sheet]['cells'][address][1]==value[1]
            continue
        if allowed(sheet,address):continue
        assert new[sheet]['cells'].get(address,('',''))==value,(sheet,address,value,new[sheet]['cells'].get(address))
        unchanged+=1
assert all(new_tables.get(k)==v for k,v in old_tables.items())
fit=new['Recommendation Fit']['cells'];review=new['Review']['cells']
assert all(fit['F'+str(row)][0]=='PASS' for row in range(12,56))
assert all(fit['F'+str(row)][0]=='FAIL' for row in range(73,81))
assert all(fit['F'+str(row)][0]=='FIX VERIFIED' for row in range(62,66))
assert all(review['C'+str(row)][0]=='PASS' for row in range(46,49))
assert review['C4'][0]=='OPEN_CHECKS' and review['C5'][0]=='FINAL_ACCEPTANCE_PENDING'
assert len(list((B/'report-render-final').glob('page-*.png')))==14
doc=Document(O/'01_Latest_Testing_and_Acceptance_Report.docx')
text='\n'.join(p.text for p in doc.paragraphs)
assert 'Version 3.6' in text and 'passed all 44 frozen cases' in text
assert 'participant signature' in text and doc.paragraphs[-1].text.count('___')>0
result={'status':'PASS','report_version':'3.6','report_pages':14,'all_report_pages_visually_reviewed':True,'workbook_changed_views_visually_reviewed':True,'workbook_sheets':list(new),'unrelated_existing_cells_preserved':unchanged,'original_tables_panes_and_validations_preserved':True,'formula_errors':0,'current_case_statuses':{'PASS':44,'FAIL':0},'original_failure_rows_retained':8,'human_acceptance':'PENDING'}
(B/'artifact-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
