// QA transport for the ClinePass success/data envelope. No answer is invented.
import {appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';

const nativeFetch = globalThis.fetch;
let attempted = 0;
const sha = value => createHash('sha256').update(value).digest('hex');
const audit = entry => {
  if (!process.env.G42_CLINE_AUDIT) return;
  let serialized = JSON.stringify({...entry, recorded_at: new Date().toISOString()});
  if (process.env.OPENAI_API_KEY) serialized = serialized.replaceAll(process.env.OPENAI_API_KEY, '[REDACTED]');
  appendFileSync(process.env.G42_CLINE_AUDIT, serialized + '\n', {mode: 0o600});
};

globalThis.fetch = async (input, init) => {
  const url = new URL(input instanceof Request ? input.url : String(input));
  if (url.hostname !== 'api.cline.bot' || url.pathname !== '/api/v1/chat/completions') {
    return nativeFetch(input, init);
  }
  if (++attempted > Number(process.env.G42_CLINE_MAX_REQUESTS || 350)) throw Error('QA_CLINE_REQUEST_LIMIT');
  const bodyText = typeof init?.body === 'string' ? init.body : input instanceof Request ? await input.clone().text() : '{}';
  const original = JSON.parse(bodyText);
  if (original.model !== 'cline-pass/deepseek-v4.1-flash') throw Error('QA_UNEXPECTED_CLINE_MODEL');
  if (original.stream) throw Error('QA_TRANSPORT_SUPPORTS_NONSTREAMING_ONLY');
  const payload = process.env.G42_CLINE_NONTHINKING === '1'
    ? {...original, thinking: {type: 'disabled'}, reasoning: {enabled: false}}
    : original;
  const requestId = `${process.pid}-${attempted}`;
  const parameters = Object.fromEntries(Object.entries(payload).filter(([key]) => key !== 'messages'));
  const record = {request_id: requestId, profile: process.env.G42_CLINE_NONTHINKING === '1' ? 'explicit_nonthinking' : 'repository_default',
    requested_model: payload.model, parameters, messages_sha256: sha(JSON.stringify(payload.messages))};
  audit({...record, event: 'request'});
  const started = performance.now();
  try {
    const response = await nativeFetch(input, {...init, body: JSON.stringify(payload)});
    const rawText = await response.text();
    let raw;
    try { raw = JSON.parse(rawText); } catch { raw = {}; }
    const unwrapped = raw.success === true && raw.data?.object === 'chat.completion';
    const data = unwrapped ? raw.data : raw;
    const choice = data.choices?.[0];
    audit({...record, event: 'response', http_status: response.status, latency_ms: Math.round(performance.now() - started),
      envelope_unwrapped: unwrapped, returned_model: data.model ?? null, usage: data.usage ?? null,
      finish_reason: choice?.finish_reason ?? null, content: choice?.message?.content ?? null,
      tool_calls: choice?.message?.tool_calls ?? [],
      error: data.error ?? null});
    if (response.ok && data.choices && data.model !== 'deepseek/deepseek-v4.1-flash') throw Error('QA_UNEXPECTED_RETURNED_MODEL');
    const headers = new Headers(response.headers);
    headers.delete('content-length'); headers.delete('content-encoding');
    return new Response(unwrapped ? JSON.stringify(data) : rawText, {status: response.status, statusText: response.statusText, headers});
  } catch (error) {
    audit({...record, event: 'transport_error', latency_ms: Math.round(performance.now() - started), error_type: error?.name || 'Error'});
    throw error;
  }
};
