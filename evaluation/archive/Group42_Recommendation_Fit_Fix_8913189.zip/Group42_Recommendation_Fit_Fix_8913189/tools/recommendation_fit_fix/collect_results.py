"""Read-only collection of the frozen fit retest and declared local patch evidence."""
from collections import Counter
from datetime import datetime
from decimal import Decimal
from pathlib import Path
import hashlib
import json
import re
import sqlite3

from dotenv import dotenv_values
import psycopg2
from oracle import Oracle

B = Path(__file__).resolve().parent
R = B / 'runtime'
OLD = B.parent / 'qa_recommendation_fit_8913189'
SOURCE = B.parent / 'qa_latest_8913189/source'
OUTPUT = B.parents[1] / 'outputs/01a1244e-75b8-7e40-a695-9805a996e104/Group42_Latest_Acceptance_8913189'
def read(name, root=B):
    return json.loads((root / (name + '.json')).read_text())
def write(name, value):
    (B / (name + '.json')).write_text(json.dumps(value, indent=2, ensure_ascii=False))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

catalog = read('frozen-fit-cases')
fingerprint = sha(B / 'frozen-fit-cases.json')
assert fingerprint == (B / 'frozen-fit-cases.sha256').read_text().strip()
assert (B / 'frozen-fit-cases.json').read_bytes() == (OLD / 'frozen-fit-cases.json').read_bytes()
suites = {name: read(name + '-result') for name in ['structured', 'projection', 'natural']}
assert all(s['catalog_sha256'] == fingerprint for s in suites.values())
assert sum(s['cases'] for s in suites.values()) == 44
assert all(s['passed'] + s['failed'] == s['cases'] for s in suites.values())
baseline = {row['id']: row for name in suites for row in read(name + '-result', OLD)['rows']}
oracle = Oracle()
assert oracle.summary['normalized_source_sha256'] == read('oracle-source-summary', OLD)['normalized_source_sha256']

violations = []
verified = 0
for row in suites['natural']['rows']:
    if not row['checks'].get('operation_completed'):
        continue
    for item in (row['state'].get('recommendation') or {}).get('recommendations', []):
        verified += 1
        failed = []
        for c in row['expected_criteria']:
            native = {**c, 'field': {'district':'district_code', 'place_proximity':'distance'}.get(c['field'], c['field'])}
            if c.get('target_id'):
                native.update(destination_id=c['target_id'], distance_type='straight_line')
            if c['strength'] == 'hard' and oracle.outcome(oracle.by_id[item['listing']['listing_id']], native) != 'pass':
                failed.append(c)
        if failed:
            violations.append({'case_id':row['id'], 'listing':item['listing'], 'violated_user_requirements':failed})
write('user-expectation-violations', {'unit':'Displayed verified recommendation occurrences in completed authored persona turns; repeated listings are separate occurrences.', 'displayed_verified_occurrences':verified, 'violating_occurrences':len(violations), 'rows':violations, 'scope':'Contract-fit regression sample, not population precision or participant satisfaction.'})

events = []
audit_files = []
for filename in ['app-model-audit.jsonl', 'native-model-audit.jsonl']:
    records = [json.loads(line, parse_float=Decimal) for line in (B / filename).read_text().splitlines() if line.strip()]
    requests = [r for r in records if r['event'] == 'request']
    responses = [r for r in records if r['event'] == 'response']
    audit_files.append({'path':filename, 'attempts':len(requests), 'http_200':sum(r.get('http_status') == 200 for r in responses)})
    events.extend(records)
requests = [r for r in events if r['event'] == 'request']
responses = [r for r in events if r['event'] == 'response']
assert len({r['request_id'] for r in requests}) == len(requests)
assert {r['request_id'] for r in requests} == {r['request_id'] for r in events if r['event'] != 'request'}
usage = {k:sum((r.get('usage') or {}).get(k, 0) for r in responses) for k in ['prompt_tokens','completion_tokens','total_tokens']}
cost = sum(((r.get('usage') or {}).get('cost') or Decimal(0) for r in responses), Decimal(0))
previous = read('before_update/Manifest_SHA256')
account = {'external_chat_api_attempts':len(requests), 'http_200_model_responses':sum(r.get('http_status') == 200 for r in responses), 'http_status_counts':dict(Counter(str(r.get('http_status')) for r in responses)), 'transport_errors':sum(r['event'] not in ['request','response'] for r in events), 'usage':usage, 'provider_reference_cost_usd':str(cost), 'audit_files':audit_files, 'cost_interpretation':'Provider reference amount, not an invoice or a verified subscription charge.', 'combined_attempts':previous['real_model_calls']+len(requests), 'combined_http_200':previous['successful_chat_model_responses']+sum(r.get('http_status') == 200 for r in responses), 'combined_reported_tokens':previous['chat_model_usage']['total_tokens']+usage['total_tokens'], 'combined_reference_cost_usd':str(Decimal(previous['chat_model_usage']['provider_reference_cost_usd'])+cost)}
write('request-accounting', account)

base_files = read('baseline-manifest')['files']
modified = [name for name, digest in base_files.items() if sha(R / name) != digest]
expected_modified = ['src/domain/rental-language.ts','src/domain/geo-intake.ts','src/domain/requirements.ts','src/adapters/locations.ts','recommendation/agent/controller.py','scripts/import-recommendation-upstream.py']
assert set(modified) == set(expected_modified), modified
added = ['tests/recommendation-fit-regression.test.ts','recommendation/tests/test_fit_controller_regression.py','tests/test_recommendation_provenance.py','contracts/releases/recommendation-downstream-patches.json']
assert all((R / name).is_file() for name in added)
tests = [n for n in base_files if '/tests/' in '/'+n or n.startswith('tests/')]
assert all(sha(R / n) == base_files[n] for n in tests)
assert all(sha(R / n) == digest for n, digest in read('tested-business-source')['files'].items())
assert sha(R / 'contracts/releases/recommendation-upstream-907cfa8.json') == base_files['contracts/releases/recommendation-upstream-907cfa8.json']
sources = {'status':'PASS','base_commit':catalog['baseline_commit'],'baseline_files':len(base_files),'unchanged_baseline_files':len(base_files)-len(modified),'modified_existing_files':modified,'added_files':added,'existing_test_files_unchanged':len(tests),'business_source_unchanged_during_deployed_retest':True,'original_upstream_manifest_unchanged':True,'files':{name:{'before_sha256':base_files.get(name),'after_sha256':sha(R / name)} for name in modified+added}}
write('source-parity', sources)

for filename in ['oracle.py','run_natural.py','run_projection.ts','run_structured.py']:
    expected = (OLD / filename).read_text().replace("R=B.parent/'qa_live_cline_8913189/runtime'", "R=B/'runtime'").replace('../qa_live_cline_8913189/runtime/','./runtime/')
    if filename == 'run_structured.py':
        expected = expected.replace('Run unchanged production recommendation service','Run the patched recommendation service').replace('Unchanged production service in process;','Patched production service in process;')
    assert (B / filename).read_text() == expected, filename
write('catalogue-preservation', {'status':'PASS','catalogue_sha256':fingerprint,'catalogue_bytes_unchanged':True,'oracle_and_assertion_logic_unchanged':True,'harness_differences':'Runtime import/profile paths; structured run description identifies the patched service. No outcome assertion changed.'})

natural_by_id = {r['id']:r for r in suites['natural']['rows']}
issues = read('open-fit-issues', OLD)
for issue in issues['issues']:
    issue['baseline_status'] = issue['status']
    issue['status'] = 'VERIFIED_LOCAL_FIX' if all(natural_by_id[c]['status'] == 'PASS' for c in issue['cases']) else 'OPEN'
    issue['fix_locations'] = {'DEF09':['src/domain/rental-language.ts:comparison'], 'DEF10':['src/domain/geo-intake.ts:cleanLocationName','src/adapters/locations.ts:resolve','src/domain/requirements.ts:pendingQuestions','src/domain/rental-language.ts:furnishing/lease'], 'DEF11':['src/domain/rental-language.ts:district preference','recommendation/agent/controller.py:LiveController.propose'], 'DEF12':['src/domain/rental-language.ts:district removal']}[issue['id']]
    issue['retest_receipt'] = 'recommendation_fit_fix/natural-result.json'
    issue['next_action'] = 'Review and integrate the local patch; preserve the frozen regression checks. Overall acceptance still requires the earlier open issues and participant review.'
verified_issues = sum(i['status'] == 'VERIFIED_LOCAL_FIX' for i in issues['issues'])
issues.update(status='VERIFIED_LOCAL_FIX' if verified_issues == 4 else 'OPEN', product_fixes_made=True, local_verified_issue_groups=verified_issues, total_open_issue_groups=5+4-verified_issues, upstream_repository_updated=False)
write('fit-issue-dispositions', issues)

rows = []
for name, suite in suites.items():
    for r in suite['rows']:
        before = baseline[r['id']]['status']
        if name == 'structured':
            expected = 'Independent full-pool counts, exact top four, hard constraints, scores and evidence coverage'
            observed = f"{r['envelope']['response']['status']}; {len(r['envelope']['response']['recommendations'])} verified; {r['expected_counts']['eligible']} eligible"
            profile, scenario = 'Structured', r['name']
        elif name == 'projection':
            expected = 'Hard unknowns remain unverified; soft unknowns remain visible; native response preserved'
            observed = f"{len(r['output']['recommendations'])} verified; {len(r['output']['unverified_candidates'])} pending; unknown criterion preserved"
            profile, scenario = 'Projection', r['name']
        else:
            expected = 'Preserve intended values, operators, preference strengths and cancellations; independently validate listings'
            rec = r['state'].get('recommendation') or {}
            observed = f"Baseline {before}; retest {r['status']}; {len(rec.get('recommendations',[]))} verified; {len(rec.get('unverified_candidates',[]))} pending"
            profile, scenario = 'Persona turn', r['persona']+' / turn '+str(r['turn'])
        failed = [k for k, v in r['checks'].items() if not v]
        if failed:
            observed = 'Failed checks: '+'; '.join(failed)+'; '+observed
        rows.append([r['id'],profile,scenario,expected,observed,r['status'],f'recommendation_fit_fix/{name}-result.json#{r["id"]}'])
write('english-case-rows', {'columns':['Case ID','Profile','Scenario','Expected outcome','Observed outcome','Status','Receipt'],'rows':rows})

settings = dotenv_values(R / '.env')
connection = psycopg2.connect(settings['DATABASE_URL'])
connection.set_session(readonly=True)
with connection.cursor() as cursor:
    cursor.execute('SELECT count(*) FROM message_outbox')
    outbox = cursor.fetchone()[0]
    cursor.execute('SELECT status,count(*) FROM domain_operations GROUP BY status')
    operations = dict(cursor.fetchall())
connection.close()
assert outbox == 0
state_path = Path(settings['RECOMMENDATION_STATE_PATH'])
if not state_path.is_absolute():
    state_path = R / state_path
db = sqlite3.connect(state_path.resolve().as_uri()+'?mode=ro',uri=True)
traces = []
for row in suites['natural']['rows']:
    exchange = row.get('native_exchange')
    if not exchange:
        continue
    execution = exchange['response']['execution']
    record = db.execute('SELECT content FROM traces WHERE trace_id=?',(execution['trace_id'],)).fetchone()
    assert record
    trace = json.loads(record[0])
    gates = [s for s in trace['steps'] if s['kind']=='final_gate']
    traces.append({'case_id':row['id'],'status':exchange['response']['status'],'execution':execution,'controller_completion':trace.get('controller_completion'),'final_gate_passed':bool(gates and gates[-1]['passed']),'tools':[{'name':s['result']['tool'],'status':s['result']['status'],'verified_count':s['result']['verified_count']} for s in trace['steps'] if s['kind']=='tool']})
db.close()
write('runtime-observation', {'external_messages_sent':0,'message_outbox_rows':outbox,'domain_operation_status_counts':operations,'native_turns':traces,'action_mode':'simulation','source_base_commit':catalog['baseline_commit'],'local_patch':True})
assert all(t['final_gate_passed'] for t in traces)

def count_log(name, pattern):
    matches = re.findall(pattern,(B / name).read_text())
    assert matches, name
    return int(matches[-1])
code_checks = {'typescript':{'passed':count_log('typescript-full.log',r'ℹ pass (\d+)'),'skipped':count_log('typescript-full.log',r'ℹ skipped (\d+)'),'failed':count_log('typescript-full.log',r'ℹ fail (\d+)')},'python':{'passed':count_log('python-full.log',r'(\d+) passed'),'skipped':count_log('python-full.log',r'(\d+) skipped')},'new_regressions':{'typescript':19,'native_controller':3,'provenance':4,'total':26},'typecheck':'PASS','recommendation_typecheck':'PASS','upstream_provenance':json.loads((B/'upstream-patch-check.log').read_text())}
assert (B / 'typecheck.log').read_text() == ''
assert (B / 'typecheck-recommendation.log').read_text() == ''
assert code_checks['typescript']['failed'] == 0
write('code-checks',code_checks)

summary = {'version':'3.6','source_base_commit':catalog['baseline_commit'],'catalog_sha256':fingerprint,'frozen_at':catalog['frozen_at'],'output':str(OUTPUT),'recommendation_fit_cases':44,'passed':sum(s['passed'] for s in suites.values()),'failed':sum(s['failed'] for s in suites.values()),'baseline_passed':36,'baseline_failed':8,'suites':{name:{k:s[k] for k in ['status','cases','passed','failed','profile']} for name,s in suites.items()},'structured_verified_occurrences':sum(len(r['envelope']['response']['recommendations']) for r in suites['structured']['rows']),'natural_verified_occurrences_in_completed_turns':verified,'natural_user_hard_violation_occurrences':len(violations),'original_failed_turns':[{ 'id':r['id'],'before':'FAIL','after':r['status']} for r in suites['natural']['rows'] if baseline[r['id']]['status']=='FAIL'],'local_verified_issue_groups':verified_issues,'total_open_issue_groups':issues['total_open_issue_groups'],'upstream_integration':'PENDING','participant_uat':'NOT_RUN','final_acceptance':'PENDING','code_checks':code_checks,'model_accounting':account,'completed_at':datetime.now().astimezone().isoformat()}
write('acceptance-summary',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['model_accounting','code_checks','suites']},indent=2))
