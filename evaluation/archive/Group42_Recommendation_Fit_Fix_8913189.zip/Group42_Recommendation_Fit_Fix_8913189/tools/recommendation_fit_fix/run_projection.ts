import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {projectNative} from './runtime/src/adapters/native-recommendation.js';
import {recommendationRequestSchema} from './runtime/src/contracts/recommendation-v1.js';
const base=path.dirname(fileURLToPath(import.meta.url)),bytes=await readFile(path.join(base,'frozen-fit-cases.json'));
const hash=createHash('sha256').update(bytes).digest('hex');assert.equal(hash,(await readFile(path.join(base,'frozen-fit-cases.sha256'),'utf8')).trim());
const catalog=JSON.parse(bytes.toString()),fixture=JSON.parse(await readFile(path.join(base,'projection-native-fixture.json'),'utf8')),rows=[];
for(const c of catalog.projection){
 let output:any=null,checks:Record<string,boolean>={},error_type=null;
 try{
  const native=fixture.response,req=recommendationRequestSchema.parse({contract_version:'1.0',request_id:native.request_id,conversation_id:native.conversation_id,
   requirements_version:native.requirements_version-1,result_limit:4,requirements:{listing_type:'RENT',criteria:[{criterion_id:'budget',field:'price',operator:'lte',value:1800,unit:'SGD/month',strength:'hard'},c.extra_criterion]}});
  let saved:any;output=await projectNative(req,{sessionId:req.conversation_id,operationId:'00000000-0000-4000-8000-000000000001',agent:'b',dataset:'2026-10-09',deadline:Date.now()+30000,calls:0},structuredClone(fixture),async(_ctx,body)=>{saved=body;return '00000000-0000-4000-8000-000000000002';});
  const hard=c.extra_criterion.strength==='hard',items=[...output.recommendations,...output.unverified_candidates];
  checks={expected_group:hard?output.recommendations.length===0&&output.unverified_candidates.length===4:output.recommendations.length===4,
   unknown_preserved:items.every(x=>x.criterion_results.find(r=>r.criterion_id==='extra-fit')?.status==='unknown'),
   source_unchanged:JSON.stringify(saved.response)===JSON.stringify(fixture.response),
   hard_budget_holds:items.every(x=>x.listing.price!==null&&x.listing.price<=1800),
   contract_gap_visible:output.warnings.some(w=>w.code==='NATIVE_CONTRACT_GAP'),
   no_current_vacancy_claim:items.every(x=>x.listing.availability_status==='unknown')};
 }catch(error){error_type=error instanceof Error?error.name:'unknown';checks.execution=false;}
 const row={id:c.id,name:c.name,criterion:c.extra_criterion,status:Object.values(checks).every(Boolean)?'PASS':'FAIL',checks,output,error_type};rows.push(row);console.log(c.id,row.status);
}
await writeFile(path.join(base,'projection-result.json'),JSON.stringify({status:rows.every(r=>r.status==='PASS')?'PASS':'FAIL',catalog_sha256:hash,
 profile:'Real production TypeScript projection over the RF01 full-database native response; no additional model calls',cases:rows.length,passed:rows.filter(r=>r.status==='PASS').length,failed:rows.filter(r=>r.status==='FAIL').length,rows},null,2));
