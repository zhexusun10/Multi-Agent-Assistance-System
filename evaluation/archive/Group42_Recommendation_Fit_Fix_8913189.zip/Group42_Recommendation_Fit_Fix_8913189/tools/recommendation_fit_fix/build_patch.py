from pathlib import Path
from tempfile import TemporaryDirectory
import difflib
import hashlib
import json
import shutil
import subprocess

B=Path(__file__).resolve().parent
R=B/'runtime'
S=B.parent/'qa_latest_8913189/source'
summary=json.loads((B/'acceptance-summary.json').read_text())
out=Path(summary['output'])/'code'
out.mkdir(exist_ok=True)
parity=json.loads((B/'source-parity.json').read_text())
names=parity['modified_existing_files']+parity['added_files']
chunks=[]
for name in sorted(names):
    before=(S/name).read_bytes().decode('utf-8') if (S/name).exists() else ''
    after=(R/name).read_bytes().decode('utf-8')
    chunks.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+name if (S/name).exists() else '/dev/null',tofile='b/'+name))
    target=out/'patched'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(R/name,target)
patch=out/'recommendation-fit-fix.patch'
patch.write_bytes(''.join(chunks).encode('utf-8'))
with TemporaryDirectory(prefix='patch-check-',dir=B) as folder:
    root=Path(folder)
    for name in parity['modified_existing_files']:
        target=root/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(S/name,target)
    subprocess.run(['git','init','--quiet'],cwd=root,check=True,capture_output=True)
    for args in [['--check'],[]]:
        result=subprocess.run(['git','apply',*args,str(patch.resolve())],cwd=root,capture_output=True,text=True)
        if result.returncode:
            raise RuntimeError('Clean-baseline patch application failed: '+result.stderr)
    assert all((root/name).read_bytes()==(R/name).read_bytes() for name in names)
record={'status':'PASS','base_commit':summary['source_base_commit'],'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'modified_existing_files':parity['modified_existing_files'],'added_files':parity['added_files'],'patch_files':len(names),'clean_baseline_apply_check':True,'applied_files_match_tested_runtime':True,'upstream_original_manifest_retained':True,'github_updated':False}
(B/'patch-validation.json').write_text(json.dumps(record,indent=2))
(out/'Patch_Manifest.json').write_text(json.dumps(record,indent=2))
(out/'README.txt').write_text('''GROUP 42 RECOMMENDATION FIT FIX

Base: 89131897f56bbc176c30246a451f118f7de0209f
The local patch passed all 44 frozen recommendation-fit cases. It has not been
pushed to GitHub. Review it before merging into the team branch.

From a clean checkout of the base revision, create a codex/recommendation-fit-fixes
branch, then run git apply --check and git apply with recommendation-fit-fix.patch.
The patched/ folder provides the same ten files for direct review. Do not combine
manual file replacement with applying the patch to the same checkout.

Validation commands after installing the project dependencies:
  node node_modules/typescript/lib/tsc.js --noEmit
  node node_modules/typescript/lib/tsc.js --noEmit -p tsconfig.recommendation.json
  node --import tsx --test tests/*.test.ts
  python -m pytest data/tests recommendation/tests tests/test_api.py tests/test_webhook_gateway.py tests/test_native_transport.py tests/test_recommendation_provenance.py -q
  python scripts/import-recommendation-upstream.py --check

The upstream port manifest is unchanged. A separate downstream manifest declares
the controller fix with both original and patched hashes. The provenance checker
rejects undeclared changes, wrong bases and a reverted patch.

The frozen real-data/model harness and execution receipts are in
tools/recommendation_fit_fix and evidence/recommendation_fit_fix. Reproducing that
profile requires the fixed snapshot, PostgreSQL/Neo4j, Chroma/embedding cache and
the configured ClinePass transport and private environment; no credentials or
database files are supplied. The 44-case catalogue and oracle assertions are unchanged.

Earlier issues DEF04 to DEF08, participant UAT, formal performance acceptance,
Windows deployment verification and team signoff remain pending.
''')
print(json.dumps(record,indent=2))
