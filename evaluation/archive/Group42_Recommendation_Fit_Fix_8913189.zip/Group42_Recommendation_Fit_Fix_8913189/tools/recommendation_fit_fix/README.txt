EXECUTED RECOMMENDATION FIT HARNESS

The frozen catalogue, independent oracle and assertions are the same as the v3.5
baseline. Runtime imports/profile paths and the structured profile description
identify the local fixed checkout. All 44 cases passed in the recorded retest.

These are the exact executed harness sources. Their runtime/ location is the
patched project checkout, with its dependencies and private .env. For another
machine, provide that checkout at runtime/ beside the scripts or adjust only the
runtime import/profile paths. The service URLs are loopback ports 8010 (public),
3001 (graph), 8092 (native), 8089 (data), 18091 (retrieval) and 18002 (Chroma).

Use a separate workflow database and native SQLite state for each new evaluation.
Keep the fixed 21,431-row rental snapshot, NUS graph data and the 8-document,
40-chunk, 42-template retrieval generation. Configure the real ClinePass transport
with an existing private environment. The supplied transport records no headers
or keys, unwraps the observed success/data envelope and disables reasoning.

Run run_structured.py first with the project Python dependencies, then
node --import tsx run_projection.ts. Finally run run_natural.py against healthy
deployed services; it waits for terminal database operation status. Keep each
attempt in a separate evidence folder and never edit the frozen expectations.

The result collector is tied to this retained QA workspace and its historical
receipts; adapt its environment and artifact paths when reproducing elsewhere.
Do not export private .env files, database files, model weights or owner tokens.
