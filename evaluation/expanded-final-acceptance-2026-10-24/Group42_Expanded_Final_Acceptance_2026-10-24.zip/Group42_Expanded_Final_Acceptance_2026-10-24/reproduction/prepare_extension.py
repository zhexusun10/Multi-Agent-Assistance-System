"""Author and freeze twenty source-grounded scenarios before any new model call.

The independent relevance rule below uses raw source fields and user-stated
targets. It never imports native ranking, reads a production score or observes
new recommendations. Corpus grades are frozen in advance, including identities
which might later be returned outside the 30-item review pools.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import copy, csv, gzip, hashlib, json, math, sqlite3

B=Path(__file__).resolve().parent
P=json.loads((B/'paths.json').read_text());O=Path(P['output'])


def dump(p,v):
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(4194304),b''):h.update(block)
    return h.hexdigest()


def rule(field,op,value):return {'field':field,'operator':op,'value':value}
def le(f,v):return rule(f,'lte',v)
def ge(f,v):return rule(f,'gte',v)
def eq(f,v):return rule(f,'eq',v)
def isin(f,v):return rule(f,'in',v)


def source_test(row,clause):
    v=row.get(clause['field']);target=clause['value'];op=clause['operator']
    if v is None:return None
    if op=='lte':return v<=target
    if op=='gte':return v>=target
    if op=='eq':return v==target
    if op=='in':return v in target
    if op=='between':return target[0]<=v<=target[1]
    raise ValueError(op)


def grade(row,sc):
    hard=[source_test(row,c) for c in sc['rubric']['hard']]
    if False in hard:return 0
    if None in hard:return 'U'
    primary=[source_test(row,c) for c in sc['rubric']['primary_preferences']]
    if False in primary:return 1
    if None in primary:return 'U'
    secondary=[source_test(row,c) for c in sc['rubric']['secondary_preferences']]
    if False in secondary:return 2
    if None in secondary:return 'U'
    return 3


def native_requirements(sid,hard,primary,secondary):
    criteria=[]
    for strength,clauses,weight in [('hard',hard,1),('soft',primary,3),('soft',secondary,1)]:
        for c in clauses:
            field=c['field']
            criteria.append({'criterion_id':f'{sid}-R{len(criteria)+1:02d}',**c,
                'unit':{'price':'SGD/month','floor_area_sqft':'sqft'}.get(field),
                'strength':strength,'weight':float(weight),'utility':'threshold'})
    return {'listing_type':'RENT','criteria':criteria}


scenarios=[]


def add(n,title,category,prompt,hard,primary,secondary,initial=None,paired=None):
    sid=f'S{n:02d}'
    sc={'scenario_id':sid,'title':title,'category':category,'turns':prompt if isinstance(prompt,list) else [prompt],
        'user_prompt':'\n'.join(prompt) if isinstance(prompt,list) else prompt,
        'analysis_group':'primary','paired_scenario':paired,
        'requirements':native_requirements(sid,hard,primary,secondary),
        'rubric':{'hard':hard,'primary_preferences':primary,'secondary_preferences':secondary},
        'acceptance_criteria':[
            'Every recommended identity exists in the frozen source and passes every known mandatory condition.',
            'The native final gate passes, and returned identifiers are unique and remain in the actual service order.',
            'Relevance follows the pre-registered ordinal rubric, independently of the production score.',
            'A short qualifying pool is returned without duplicate or nonqualifying padding.']}
    if initial:
        sc['initial_requirements']=native_requirements(sid+'-INITIAL',*initial)
        sc['acceptance_criteria'].append('The second structured request references prior native state and preserves all unchanged final requirements.')
    scenarios.append(sc)


add(21,'Inclusive monthly rent ceiling','Hard-condition boundaries',
    'My rent must not exceed SGD 1,500 per month, including a listing priced exactly at that amount. I need at least one reported bedroom and at least 200 sqft. Prefer rent of SGD 1,200 or less first; 350 sqft or more is a bonus.',
    [le('price',1500),ge('bedrooms',1),ge('floor_area_sqft',200)], [le('price',1200)],[ge('floor_area_sqft',350)])
add(22,'Inclusive minimum floor area','Hard-condition boundaries',
    'I need at least two reported bedrooms and at least 700 sqft, with monthly rent no higher than SGD 4,000. A home of exactly 700 sqft is acceptable. Prefer at least 900 sqft first, then rent of SGD 3,500 or less.',
    [le('price',4000),ge('bedrooms',2),ge('floor_area_sqft',700)], [ge('floor_area_sqft',900)],[le('price',3500)])
add(23,'Exactly two reported bedrooms','Hard-condition boundaries',
    'Please find exactly two reported bedrooms in D18 or D19, for at most SGD 4,500 per month. I prefer at least 800 sqft first, and rent of SGD 3,500 or less second.',
    [le('price',4500),eq('bedrooms',2),isin('district_code',['D18','D19'])], [ge('floor_area_sqft',800)],[le('price',3500)])
add(24,'Both ends of a rent range','Hard-condition boundaries',
    'My monthly rent range is SGD 2,500 through SGD 3,500, both inclusive. I need at least two reported bedrooms in D23 or D25. Prefer 900 sqft or more first, then rent no higher than SGD 3,000.',
    [rule('price','between',[2500,3500]),ge('bedrooms',2),isin('district_code',['D23','D25'])], [ge('floor_area_sqft',900)],[le('price',3000)])
add(25,'Property type with family requirements','Hard-condition boundaries',
    'I need an HDB flat with at least three reported bedrooms, for no more than SGD 4,000 per month. Prefer D18 or D19 first, then at least 1,000 sqft.',
    [le('price',4000),ge('bedrooms',3),eq('property_type','hdb flat')], [isin('district_code',['D18','D19'])],[ge('floor_area_sqft',1000)])
add(26,'Several mandatory limits in one district','Hard-condition boundaries',
    'Keep every listing in D05, with at least two reported bedrooms and rent at most SGD 3,500 per month. I prefer rent at most SGD 3,000 first, and at least 750 sqft second.',
    [le('price',3500),ge('bedrooms',2),eq('district_code','D05')], [le('price',3000)],[ge('floor_area_sqft',750)])
add(27,'Preferred district before extra space','Preference trade-offs',
    'I can pay up to SGD 4,500 per month and need at least two reported bedrooms. I can consider any district, but D03 or D05 is my first preference. At least 900 sqft is my second preference.',
    [le('price',4500),ge('bedrooms',2)], [isin('district_code',['D03','D05'])],[ge('floor_area_sqft',900)],paired='S28')
add(28,'Extra space before preferred district','Preference trade-offs',
    'I can pay up to SGD 4,500 per month and need at least two reported bedrooms. At least 1,000 sqft is my first preference. D03 or D05 is a secondary preference; other districts are acceptable.',
    [le('price',4500),ge('bedrooms',2)], [ge('floor_area_sqft',1000)],[isin('district_code',['D03','D05'])],paired='S27')
add(29,'Savings before extra space','Preference trade-offs',
    'I need at least two reported bedrooms in D18, D19, D20 or D23, and my absolute monthly limit is SGD 4,200. My first preference is rent at most SGD 2,800. At least 900 sqft is a secondary preference.',
    [le('price',4200),ge('bedrooms',2),isin('district_code',['D18','D19','D20','D23'])], [le('price',2800)],[ge('floor_area_sqft',900)])
add(30,'Family space before savings','Preference trade-offs',
    'I need at least three reported bedrooms for no more than SGD 4,800 per month. My first preference is at least 1,100 sqft. Rent at most SGD 3,600 is my second preference.',
    [le('price',4800),ge('bedrooms',3)], [ge('floor_area_sqft',1100)],[le('price',3600)])
add(31,'Preferred property type is optional','Preference trade-offs',
    'I need at least two reported bedrooms in D18, D19, D23 or D25, at no more than SGD 4,500 per month. I prefer an HDB flat first, but other property types are acceptable. At least 900 sqft is a secondary preference.',
    [le('price',4500),ge('bedrooms',2),isin('district_code',['D18','D19','D23','D25'])], [eq('property_type','hdb flat')],[ge('floor_area_sqft',900)])
add(32,'Preference within an allowed district set','Preference trade-offs',
    'I need at least two reported bedrooms in D09, D10 or D11, at no more than SGD 6,500 per month. Within those districts, D10 is my first preference, followed by rent at most SGD 5,500.',
    [le('price',6500),ge('bedrooms',2),isin('district_code',['D09','D10','D11'])], [eq('district_code','D10')],[le('price',5500)])
add(33,'Three-bedroom search with very few matches','Sparse and no-match inventory',
    'My family needs at least three reported bedrooms in D05, with rent no higher than SGD 3,800 per month. Prefer rent at most SGD 3,600 first, then at least 900 sqft. If only a few homes qualify, show those without filling the list with other districts.',
    [le('price',3800),ge('bedrooms',3),eq('district_code','D05')], [le('price',3600)],[ge('floor_area_sqft',900)])
add(34,'No affordable two-bedroom match in D09','Sparse and no-match inventory',
    'I need at least two reported bedrooms in D09, for no more than SGD 2,200 per month. Prefer rent at most SGD 2,000 first, then at least 700 sqft. If nothing qualifies, explain that rather than offering a more expensive listing as a verified match.',
    [le('price',2200),ge('bedrooms',2),eq('district_code','D09')], [le('price',2000)],[ge('floor_area_sqft',700)])
add(35,'Four-bedroom search with two qualifying homes','Sparse and no-match inventory',
    'I need exactly four reported bedrooms in D20, at least 1,200 sqft, and rent at most SGD 4,500 per month. Prefer rent at most SGD 4,300 first, then at least 1,300 sqft. A short list is fine.',
    [le('price',4500),eq('bedrooms',4),eq('district_code','D20'),ge('floor_area_sqft',1200)], [le('price',4300)],[ge('floor_area_sqft',1300)])
add(36,'No match for a restricted family budget','Sparse and no-match inventory',
    'I need at least three reported bedrooms in D10, with monthly rent capped at SGD 2,500. Prefer rent at most SGD 2,200 first, then at least 1,000 sqft. Tell me when the current data has no qualifying home.',
    [le('price',2500),ge('bedrooms',3),eq('district_code','D10')], [le('price',2200)],[ge('floor_area_sqft',1000)])
add(37,'Budget reduction preserves the district set','Multi-turn requirement changes',
    ['I need at least two reported bedrooms in D18 or D19, for at most SGD 4,500 per month. Prefer at least 1,000 sqft first, and rent at most SGD 3,000 second.',
     'Reduce my maximum monthly rent to SGD 3,500. Keep the district choices, bedroom requirement and both preferences.'],
    [le('price',3500),ge('bedrooms',2),isin('district_code',['D18','D19'])], [ge('floor_area_sqft',1000)],[le('price',3000)],
    initial=([le('price',4500),ge('bedrooms',2),isin('district_code',['D18','D19'])],[ge('floor_area_sqft',1000)],[le('price',3000)]))
add(38,'Expand the allowed district set','Multi-turn requirement changes',
    ['I need at least two reported bedrooms in D05, with rent at most SGD 4,000 per month. Prefer rent at most SGD 3,500 first, then at least 900 sqft.',
     'Also include D03. Keep D05 as an option and retain the same rent, bedroom and size requirements.'],
    [le('price',4000),ge('bedrooms',2),isin('district_code',['D03','D05'])], [le('price',3500)],[ge('floor_area_sqft',900)],
    initial=([le('price',4000),ge('bedrooms',2),eq('district_code','D05')],[le('price',3500)],[ge('floor_area_sqft',900)]))
add(39,'Relax only the minimum floor area','Multi-turn requirement changes',
    ['I need at least two reported bedrooms in D23 or D25, at least 1,000 sqft, and rent at most SGD 4,200 per month. Prefer rent at most SGD 3,500 first, then at least 1,100 sqft.',
     'A minimum of 700 sqft is enough now. Keep the rent limit, bedroom count and districts. I still prefer 1,100 sqft when available.'],
    [le('price',4200),ge('bedrooms',2),isin('district_code',['D23','D25']),ge('floor_area_sqft',700)], [le('price',3500)],[ge('floor_area_sqft',1100)],
    initial=([le('price',4200),ge('bedrooms',2),isin('district_code',['D23','D25']),ge('floor_area_sqft',1000)],[le('price',3500)],[ge('floor_area_sqft',1100)]))
add(40,'Make a district preference mandatory','Multi-turn requirement changes',
    ['I need at least two reported bedrooms in D15, D16 or D18, with rent at most SGD 5,000 per month. Prefer D15 first, then at least 900 sqft and rent at most SGD 4,500.',
     'D15 is essential now. Within D15, put at least 900 sqft first, followed by rent at most SGD 4,500. Keep the original bedroom requirement and maximum budget.'],
    [le('price',5000),ge('bedrooms',2),eq('district_code','D15')], [ge('floor_area_sqft',900)],[le('price',4500)],
    initial=([le('price',5000),ge('bedrooms',2),isin('district_code',['D15','D16','D18'])],[eq('district_code','D15')],[ge('floor_area_sqft',900),le('price',4500)]))


def read_source():
    db=Path(P['database']);assert sha(db)=='3fb6bdd8bc1b677d44abf1b3bb036692a00ccfa002613970bf5860529b82a2e5'
    con=sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True);con.row_factory=sqlite3.Row
    fields=['listing_id','listing_type','title','price','bedrooms','floor_area_sqft','property_type','district_code','url']
    rows=[]
    for r in con.execute('SELECT '+','.join(fields)+" FROM properties WHERE listing_type='RENT' ORDER BY listing_id"):
        row=dict(r);row['listing_id']=str(row['listing_id'])
        for k in ['price','floor_area_sqft','bedrooms']:
            v=row[k]
            row[k]=float(v) if v is not None and math.isfinite(float(v)) and float(v)>=0 and (k=='bedrooms' or float(v)>0) else None
        for k in ['property_type','district_code']:
            v=row[k];row[k]=v.strip().lower() if k=='property_type' and v else v.strip().upper() if v else None
        rows.append(row)
    con.close();assert len(rows)==21431 and len({r['listing_id'] for r in rows})==21431
    return rows


def main():
    assert not (O/'inputs/Extension_Freeze_EN.json').exists(),'Frozen extension already exists'
    rows=read_source();byid={r['listing_id']:r for r in rows};all_grades=[];pools=[];summaries=[]
    for sc in scenarios:
        sid=sc['scenario_id'];grade_map={r['listing_id']:grade(r,sc) for r in rows}
        eligible=[lid for lid,g in grade_map.items() if type(g) is int and g>0]
        known_hard=[r['listing_id'] for r in rows if all(source_test(r,c) is True for c in sc['rubric']['hard'])]
        sc['expected_eligible_count']=len(known_hard)
        sc['expected_native_status']='success' if known_hard else 'no_match'
        if not known_hard:sc['analysis_group']='control'
        assert len(known_hard)>=len(eligible)
        for lid,g in grade_map.items():all_grades.append([sid,lid,g])
        # Fixed, source-only stratification. No score or returned identity is available here.
        strata={g:[lid for lid,x in grade_map.items() if x==g] for g in [3,2,1,0,'U']}
        def key(lid):return hashlib.sha256(f'G42-EXT-20261024|{sid}|{lid}'.encode()).hexdigest()
        for ids in strata.values():ids.sort(key=key)
        selected=[]
        for g,quota in [(3,6),(2,8),(1,6),(0,8),('U',2)]:selected.extend(strata[g][:quota])
        if len(known_hard)<=10:
            # Include the complete scarce inventory to prevent sampling it out of its own test.
            selected=list(dict.fromkeys(known_hard+selected))
        fill=sorted((lid for lid in byid if lid not in selected),key=key)
        selected=(selected+fill)[:30];assert len(selected)==30 and len(set(selected))==30
        for lid in selected:
            r=byid[lid];pools.append({'scenario_id':sid,'listing_id':lid,'grade':grade_map[lid],
                'source_facts':r,'source':'Immutable SQLite rental snapshot 2026-10-09',
                'hard_checks':[{'requirement':c,'observed':r[c['field']],'pass':source_test(r,c)} for c in sc['rubric']['hard']],
                'primary_checks':[{'requirement':c,'observed':r[c['field']],'pass':source_test(r,c)} for c in sc['rubric']['primary_preferences']],
                'secondary_checks':[{'requirement':c,'observed':r[c['field']],'pass':source_test(r,c)} for c in sc['rubric']['secondary_preferences']]})
        summaries.append({'scenario_id':sid,'expected_native_status':sc['expected_native_status'],
            'known_hard_eligible':len(known_hard),'full_corpus_grade_counts':dict(Counter(str(g) for g in grade_map.values())),
            'frozen_review_pool_size':30,'frozen_review_pool_grade_counts':dict(Counter(str(grade_map[lid]) for lid in selected))})
    dump(O/'inputs/Extension_Scenarios_EN.json',{'dataset_id':'G42-EXT20-20261024-v1','scenarios':scenarios})
    dump(O/'inputs/Frozen_Review_Pools_EN.json',{'metadata':{'pair_count':600,'pool_size_per_scenario':30,
        'selection':'Source-only grade stratification and deterministic SHA256 sampling. Sparse qualifying inventories included in full.'},'ratings':pools})
    dump(O/'inputs/Source_Facts_EN.json',{'snapshot_date':'2026-10-09','row_count':len(rows),'listings':rows})
    with (O/'inputs/Frozen_Corpus_Grades_EN.jsonl.gz').open('wb') as f:
        with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:
            for item in all_grades:z.write((json.dumps(item,separators=(',',':'))+'\n').encode())
    rubric={'version':'source-rubric-v1','created_before_new_model_calls':True,
        'grade_0':'At least one known mandatory condition fails.',
        'grade_U':'A mandatory fact is unknown without a known failure, or missing preference evidence prevents assigning one exact ordinal grade.',
        'grade_1':'All mandatory conditions pass, but at least one principal preference is known not to be met.',
        'grade_2':'All mandatory and principal preferences pass, but a secondary preference is known not to be met.',
        'grade_3':'All mandatory, principal and secondary preferences pass.',
        'relevant_grades':[2,3],'numeric_gains':{'0':0,'1':1,'2':3,'3':7},
        'precision':'Hits / K; missing positions have no hit. Unknown returned judgments keep the exact value unavailable and have explicit bounds.',
        'pool_recall':'Hits in a common judged pool / all grade-2/3 identities in that pool. Zero denominator is N/A.',
        'ndcg':'DCG / ideal DCG from numeric grades in the same pool. Discount log2(rank+1). Missing positions have zero gain.',
        'main_pool_policy':'Original 619 records unchanged. New 600-record pre-run pools plus every newly returned identity across registered runs, using its already frozen corpus grade. Retain the original-600 view separately.',
        'repeat_policy':'S27 and S29 each have five runs: the main evaluated request plus four pre-registered fresh-session repeat requests. One common extended pool is used for all repeats.',
        'full_corpus_recall':'Additional new-scenario-only diagnostic using all frozen numeric grade-2/3 identities among 21,431 listings; distinct from headline pool Recall.',
        'label_provenance':'Transparent provisional source-fact rubric prepared before outputs; no independent human rating or paid relevance-judge call.',
        'benchmark_design':'Schema-aware extension based on realistic rent, reported bedrooms, advertised area, district and property-type needs. Not a new blind set.',
        'source_quality_limit':'Advertised floor area and reported bedroom count can describe a whole dwelling even when an advert concerns a room. No verified occupancy, availability, furnishing or lease claims.'}
    dump(O/'inputs/Relevance_Rubric_EN.json',rubric)
    dump(O/'inputs/Source_Preflight_EN.json',{'scenario_summaries':summaries,'new_pair_count':len(pools),
        'corpus_grade_rows':len(all_grades),'new_primary_scenarios':[s['scenario_id'] for s in scenarios if s['analysis_group']=='primary'],
        'new_controls':[s['scenario_id'] for s in scenarios if s['analysis_group']=='control']})
    fields=['scenario_id','title','category','user_prompt','expected_native_status','expected_eligible_count','analysis_group']
    with (O/'inputs/Extension_Scenario_Register_EN.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        writer.writerows({k:s[k] for k in fields} for s in scenarios)
    freeze={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'new_scenarios':20,'new_source_review_pairs':600,
        'corpus_grade_rows':len(all_grades),'model_calls_before_freeze':0,
        'source_commit':P['commit'],'snapshot_date':'2026-10-09','source_rows':21431,
        'database_sha256':'3fb6bdd8bc1b677d44abf1b3bb036692a00ccfa002613970bf5860529b82a2e5',
        'artifact_sha256':{p.name:sha(p) for p in sorted((O/'inputs').iterdir()) if p.is_file()},
        'registered_repeats':{'S27':list(range(1,6)),'S29':list(range(1,6))},
        'previous_twenty_reused_without_new_calls':True,'paid_api_request_cap':220,'reported_usage_cap_usd':2,
        'full_complex_suite_rerun':False,'complex_results_source':'Prior completed 60-case local-timeout-repair experiment; retain date and build explicitly.'}
    dump(O/'inputs/Extension_Freeze_EN.json',freeze)
    (O/'inputs/Scoring_Instructions_EN.txt').write_text('''RECOMMENDATION RELEVANCE SCORING INSTRUCTIONS

Read each English user need and its priority order. Check the original source
facts before assigning a grade. The rubric and all corpus grades were frozen
before the new service responses were observed. A grade does not use the native
score, rank, exploration decision, explanation, or any expected model output.

0: A known mandatory condition fails.
U: Required evidence is unknown and no known failure settles the grade.
1: All mandatory conditions pass, but a principal preference is not met.
2: Mandatory and principal preferences pass; a secondary preference is not met.
3: Mandatory, principal and secondary preferences all pass.
Grades 2 and 3 count as binary relevance. Gain for NDCG is 0, 1, 3 and 7.
If missing preference evidence can change the exact grade, keep U.

Record a human review in a separate field; preserve the frozen grade and note
the source fact or interpretation behind any disagreement. Current labels are
provisional and have not been approved by an independent human reviewer.

Advertised area and reported bedrooms are source fields, not confirmation that
the user rents an entire dwelling or a private room. Missing lease, furnishing,
occupancy and availability evidence must not be inferred as verified.

The new 30-item review pools use source-only deterministic stratification. Any
returned identity outside its pool uses the corpus grade already frozen before
execution and is included in a separately traceable extension. The pre-run-pool
results are retained. New primary results and the historical 20-scenario results
are reported separately as well as together, because their label construction
and candidate-pool histories differ.
''')
    print(json.dumps({'freeze':'COMPLETE','scenarios':20,'pre_run_pairs':600,
        'full_corpus_grades':len(all_grades),'cases':summaries},indent=2))


if __name__=='__main__':main()
