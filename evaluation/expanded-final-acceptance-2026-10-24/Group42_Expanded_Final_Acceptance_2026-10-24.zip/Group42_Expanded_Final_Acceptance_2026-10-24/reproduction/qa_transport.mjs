// Evaluation-only provider-envelope compatibility, SDK retries and usage audit.
// Product source, prompts, semantic repair loops and native tools are unchanged.
import {appendFileSync,existsSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {AsyncCaller} from '@langchain/core/utils/async_caller';
const retry=AsyncCaller.prototype.callWithRetries;
AsyncCaller.prototype.callWithRetries=function(_count,fn,args){return retry.call(this,0,fn,args);};
const realFetch=globalThis.fetch;
const digest=x=>createHash('sha256').update(x).digest('hex');
const audit=x=>{
 if(!process.env.G42_CLINE_AUDIT)return;
 let s=JSON.stringify({...x,recorded_at_utc:new Date().toISOString()});
 if(process.env.OPENAI_API_KEY)s=s.replaceAll(process.env.OPENAI_API_KEY,'[REDACTED]');
 appendFileSync(process.env.G42_CLINE_AUDIT,s+'\n',{mode:0o600});
};
const stop=x=>{if(process.env.G42_PAID_STOP)writeFileSync(process.env.G42_PAID_STOP,JSON.stringify(x));};
globalThis.fetch=async(input,init)=>{
 const url=new URL(input instanceof Request?input.url:String(input));
 if(url.hostname!=='api.cline.bot'||url.pathname!=='/api/v1/chat/completions')return realFetch(input,init);
 if(process.env.G42_PAID_STOP&&existsSync(process.env.G42_PAID_STOP))throw Error('EVALUATION_PAID_STOP');
 let records=[];
 if(process.env.G42_CLINE_AUDIT&&existsSync(process.env.G42_CLINE_AUDIT))records=readFileSync(process.env.G42_CLINE_AUDIT,'utf8').trim().split('\n').filter(Boolean).map(s=>JSON.parse(s));
 const calls=records.filter(x=>x.event==='request').length,cost=records.reduce((n,x)=>n+(Number(x.usage?.cost)||0),0);
 if(calls>=Number(process.env.G42_MAX_API_REQUESTS||1500)||cost>=Number(process.env.G42_MAX_API_COST_USD||5)){stop({reason:'registered_api_cap',calls,cost});throw Error('EVALUATION_API_CAP');}
 const body=JSON.parse(typeof init?.body==='string'?init.body:input instanceof Request?await input.clone().text():'{}');
 if(body.model!=='cline-pass/deepseek-v4.1-flash')throw Error('UNREGISTERED_MODEL');
 if(body.stream)throw Error('UNREGISTERED_STREAMING');
 const originalMaxTokens=body.max_tokens;
 const floor=Number(process.env.G42_MIN_PLAIN_TOKENS||0);
 if(!body.tools?.length&&Number.isFinite(body.max_tokens)&&body.max_tokens<floor)body.max_tokens=floor;
 if(process.env.G42_REASONING_DISABLED==='1'){body.thinking={type:'disabled'};body.reasoning={enabled:false};}
 const requestId=`${process.pid}-${calls+1}`,started=performance.now();
 audit({event:'request',request_id:requestId,request_sha256:digest(JSON.stringify(body)),original_max_tokens:originalMaxTokens,request:body});
 try{
  const response=await realFetch(input,{...init,body:JSON.stringify(body)}),text=await response.text();let parsed;
  try{parsed=JSON.parse(text);}catch{parsed={};}
  const unwrapped=parsed.success===true&&parsed.data?.object==='chat.completion',data=unwrapped?parsed.data:parsed;
  audit({event:'response',request_id:requestId,http_status:response.status,latency_ms:Math.round(performance.now()-started),envelope_unwrapped:unwrapped,returned_model:data.model??null,usage:data.usage??null,response:data});
  if([401,402,403].includes(response.status))stop({reason:'provider_auth_or_credit_error',http_status:response.status,request_id:requestId});
  const headers=new Headers(response.headers);headers.delete('content-length');headers.delete('content-encoding');
  return new Response(unwrapped?JSON.stringify(data):text,{status:response.status,statusText:response.statusText,headers});
 }catch(error){audit({event:'transport_error',request_id:requestId,error_type:error?.name||'Error',latency_ms:Math.round(performance.now()-started)});throw error;}
};
