READ-ONLY INDEPENDENT REPRODUCTION

From the extracted package root, run:
  python3 reproduction/verify_expanded_metrics.py

Python 3 standard library only. No API key, model, database server or network
is required. The verifier reads the original evidence ZIPs directly, checks
their hashes and the seven pre-run frozen input hashes, independently reapplies
the new rubric to 428,620 scenario/source identities, verifies 1,382 common-pool
grades, and recomputes 440 scenario/K rows, 90 macro metric values, source checks
and the repeated-selection summaries. It prints JSON and writes nothing.
The completed output is reports/Independent_Verification_EN.json.

The other scripts are records of the executed capture and analysis harnesses.
They are not a one-command live rerun. Live reproduction requires a separate
checkout of the pinned GitHub commit, its Node/Python dependencies, the original
listing/OSM snapshots, and a configured local paths.json. Analysis references
the retained run and preceding NDCG summary recorded on the original host.
Absolute paths in saved run metadata document that host; the independent
verifier uses package-relative paths instead. Native code and prompts were
unchanged. Freeze and run-progress guards prevent overwriting recorded runs.
Credentials are not provided. Running the live script would incur new model
usage and is outside the read-only command above.

The report and workbook preserve the frozen results. Optional human overrides
in the workbook recalculate its metrics; they do not rewrite the recorded JSON,
raw evidence or PDF. Reviewers should record disagreements in the review fields
and agree any revised evaluation before replacing an official metric snapshot.
