"""Snapshot adapters and observation-only capture reused from the preceding real-model evaluation.

Business source remains unchanged. SQLite/OSM adapters read the same immutable real
snapshot as the original benchmark. CaptureController only observes super().propose.
No relevance labels or scoring records are given to the model or native dispatcher.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, copy, gc, gzip, hashlib, json, os, shutil, sqlite3, subprocess, sys, time

B = Path(__file__).resolve().parent
P = json.loads((B / 'paths.json').read_text())
S, O, DB = (Path(P[x]) for x in ('source', 'output', 'database'))

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4194304), b''): h.update(chunk)
    return h.hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=str) + '\n')

def gz(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('wb') as f:
        with gzip.GzipFile(filename='', fileobj=f, mode='wb', mtime=0) as z:
            z.write(json.dumps(value, ensure_ascii=False, allow_nan=False, default=str).encode())

sys.path.insert(0, str(S))
from recommendation.service import RecommendationService
from recommendation.agent.controller import LiveController, ScriptedController
from recommendation.config import RecommendationConfig
from recommendation.contracts.request import RecommendationRequest
from recommendation.repositories.listing_repository import normalize, deduplicate, COLUMNS
from recommendation.repositories.geographic_repository import GeographicBase
from recommendation.geography import catalog as geo_catalog
from recommendation.state.store import StateStore
from recommendation.tracing.trace import digest

SQLITE_SHA = '3fb6bdd8bc1b677d44abf1b3bb036692a00ccfa002613970bf5860529b82a2e5'
FIELDS = list(COLUMNS)

class SnapshotListings:
    mode = 'full_real_snapshot_sqlite_immutable'
    def __init__(self):
        self.db = sqlite3.connect(DB.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA query_only=ON')
        self.reads = 0
        self._fingerprint = {'format': 'immutable-sqlite-rent-v1', 'row_count': 21431,
                             'database_sha256': SQLITE_SHA, 'columns': FIELDS}
    def _rows(self, where='', params=()):
        return deduplicate([normalize(dict(row), 'sqlite:properties:snapshot-2026-10-09')
            for row in self.db.execute('SELECT ' + ','.join(FIELDS) +
                " FROM properties WHERE listing_type='RENT'" + where + ' ORDER BY listing_id', params)])
    def retrieve(self):
        self.reads += 1
        rows = self._rows()
        assert len(rows) == 21431
        return rows
    def fingerprint(self): return copy.deepcopy(self._fingerprint)
    def retrieve_versioned(self): return self.retrieve(), self.fingerprint()
    def lookup(self, ids):
        if not ids: return []
        return self._rows(' AND listing_id IN (' + ','.join('?' for _ in ids) + ')', list(ids))
    def lookup_versioned(self, ids): return self.lookup(ids), self.fingerprint()
    def close(self): self.db.close()

class SnapshotGeography(GeographicBase):
    source = 'frozen-real-osm-place-snapshot-2026-10-09'
    def __init__(self):
        path = S / 'data/datasets/singapore_places.json'
        self.places = json.loads(path.read_text())['places']
        self.version = sha(path)
    def places_version(self): return self.version, self.source
    def place_catalog(self):
        return geo_catalog.place_catalog(self.source, self.version, lambda: self.places, ('OSM:',))
    def close(self): pass

class CaptureController(LiveController):
    def __init__(self):
        super().__init__()
        self.dispatcher = None
    def propose(self, dispatcher, context, trace):
        self.dispatcher = dispatcher
        return super().propose(dispatcher, context, trace)

def source_hashes():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=S).decode().split('\0')
    return {name: sha(S / name) for name in names if name and (S / name).is_file()}

def audit_size():
    path = O / 'raw/Model_API_Audit.jsonl'
    return path.stat().st_size if path.exists() else 0

