"""Registered real-model extension; never repeat an already saved execution."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, copy, gc, gzip, hashlib, json, os, shutil, subprocess, time
import native_harness_base as n

B=Path(__file__).resolve().parent
P=json.loads((B/'paths.json').read_text());O=Path(P['output']);S=Path(P['source'])
SCENARIOS=json.loads((O/'inputs/Extension_Scenarios_EN.json').read_text())['scenarios']
FREEZE=json.loads((O/'inputs/Extension_Freeze_EN.json').read_text())


def now():return datetime.now(timezone.utc).isoformat()
def dump(p,v):n.dump(p,v)
def audit_size():
    p=O/'raw/Model_API_Audit.jsonl';return p.stat().st_size if p.exists() else 0


def assert_inputs():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==P['commit']
    assert subprocess.check_output(['git','diff','--binary'],cwd=S)==b''
    assert n.sha(Path(P['database']))==FREEZE['database_sha256']
    for name,digest in FREEZE['artifact_sha256'].items():assert n.sha(O/'inputs'/name)==digest,name
    for sc in SCENARIOS:
        n.RecommendationRequest(request_id='schema-'+sc['scenario_id'],conversation_id='schema',
            requirements_version=1,requirements=sc['requirements'],result_limit=10)
        if sc.get('initial_requirements'):
            n.RecommendationRequest(request_id='schema-initial-'+sc['scenario_id'],conversation_id='schema',
                requirements_version=1,requirements=sc['initial_requirements'],result_limit=10)


def preflight(config):
    assert_inputs();results=[]
    for sc in SCENARIOS:
        service=n.RecommendationService(n.SnapshotListings(),n.SnapshotGeography(),n.StateStore(':memory:'),
            n.ScriptedController(),config=config)
        try:
            req=n.RecommendationRequest(request_id='offline-'+sc['scenario_id'],conversation_id='offline',
                requirements_version=1,requirements=sc['requirements'],result_limit=10)
            r=service.recommend(req)
            assert r.execution.model_calls==0
            assert r.status==sc['expected_native_status'],(sc['scenario_id'],r.model_dump())
            assert len(r.recommendations)==min(10,sc['expected_eligible_count'])
            results.append({'scenario_id':sc['scenario_id'],'status':r.status,'returned':len(r.recommendations),
                'model_calls':0,'expected_hard_eligible':sc['expected_eligible_count']})
            print(json.dumps(results[-1]),flush=True)
        finally:service.close()
    dump(O/'reports/Offline_Preflight_EN.json',{'status':'PASS','cases':results,'model_calls':0,
        'all_initial_and_final_request_schemas_valid':True,'frozen_inputs_unchanged':True})


def plan():
    jobs=[]
    for sc in SCENARIOS:jobs.append((sc,1))
    for sid in ['S27','S29']:
        sc=next(s for s in SCENARIOS if s['scenario_id']==sid)
        for trial in range(2,6):jobs.append((sc,trial))
    return jobs


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--offline-preflight',action='store_true');args=ap.parse_args()
    config=n.RecommendationConfig.from_file(S/'config/recommendation-full.json')
    assert_inputs()
    if args.offline_preflight:preflight(config);return
    assert (O/'reports/Offline_Preflight_EN.json').exists()
    assert not (O/'Run_Progress.json').exists(),'Paid work already recorded; do not restart'
    private=B/'private/cline_key';key=private.read_text().strip();assert key
    os.environ.update({'CHAT_MODEL':'openai:cline-pass/deepseek-v4.1-flash',
        'OPENAI_BASE_URL':'https://api.cline.bot/api/v1','OPENAI_API_KEY':key,
        'NODE_OPTIONS':'--import='+(S/'qa_transport.mjs').as_uri(),
        'G42_CLINE_AUDIT':str(O/'raw/Model_API_Audit.jsonl'),'G42_PAID_STOP':str(B/'paid-stop.json'),
        'G42_MAX_API_REQUESTS':'220','G42_MAX_API_COST_USD':'2','G42_REASONING_DISABLED':'1',
        'G42_MIN_PLAIN_TOKENS':'1024','LANGCHAIN_TRACING':'false','LANGCHAIN_TRACING_V2':'false',
        'LANGSMITH_TRACING':'false','PATH':'/opt/homebrew/bin:'+os.environ.get('PATH','')})
    before=n.source_hashes();dump(O/'inputs/Tracked_Source_SHA256.json',before)
    dump(O/'inputs/Recommendation_Config.json',config.to_data())
    jobs=plan();request_plan=[]
    for sc,trial in jobs:
        sid=sc['scenario_id'];run_id=f'{sid}-T{trial:02d}'
        if trial==1 and sc.get('initial_requirements'):
            request_plan.append({'run_id':run_id,'phase':'initial','request_id':run_id+':initial:20261024','conversation_id':'G42-EXT40-'+run_id})
        request_plan.append({'run_id':run_id,'phase':'evaluated','request_id':run_id+':evaluated:20261024','conversation_id':'G42-EXT40-'+run_id})
    registration={'registered_at_utc':now(),'user_authorization':'Explicit instruction to expand recommendation scenarios, obtain final Precision/Recall/NDCG results and consolidate the complex-suite report.',
        'new_scenarios':20,'main_final_runs':20,'repeat_final_runs':8,'setup_requests':4,
        'planned_native_requests':32,'source_commit':P['commit'],'source_changes':False,
        'local_timeout_patch_applied':False,'frozen_extension_sha256':n.sha(O/'inputs/Extension_Freeze_EN.json'),
        'source_snapshot_sha256':FREEZE['database_sha256'],'requested_model':'cline-pass/deepseek-v4.1-flash',
        'controller':'Unchanged native LiveController and full scoring, selection, correction and final-gate logic.',
        'result_limit':10,'cutoffs':list(range(1,11)),
        'cutoff_policy':'Prefixes of each actual result_limit=10 response; no stitching or reranking.',
        'old_twenty_reused':True,'complex_sixty_reused':True,'new_full_workflow_test':False,
        'model_receives_ratings_or_review_pool':False,'serial':True,'actual_http_request_cap':220,
        'reported_usage_cap_usd':2,'sdk_automatic_retries':0,'request_plan':request_plan,
        'repeat_seed_policy':'Fresh session and preregistered request ID. Native select-v1 derives and records its own seed; no seed override.',
        'provider_compatibility':'Existing Cline envelope unwrap, disabled reasoning and minimum plain-response token allowance; no business-code modification.',
        'outside_scope':['Natural-language intake','Explanation generation','Browser UAT','Live SQL and graph servers','Independent human relevance review']}
    dump(O/'inputs/Evaluation_Registration_EN.json',registration)
    for src in [Path(__file__),B/'native_harness_base.py',B/'prepare_extension.py',S/'qa_transport.mjs']:
        shutil.copyfile(src,O/'reproduction'/src.name)
    started=now();finals=[];executions=[];status='RUNNING';failure=None
    def progress():
        dump(O/'Run_Progress.json',{'status':status,'started_at_utc':started,'updated_at_utc':now(),
            'completed_main_scenarios':sum(r['trial']==1 for r in finals),
            'completed_repeat_runs':sum(r['trial']>1 for r in finals),
            'final_runs':finals,'service_executions':executions,'unhandled_exception_type':failure})
    progress()
    try:
        for sc,trial in jobs:
            if (B/'paid-stop.json').exists():status='STOPPED_PROVIDER_OR_CAP';break
            sid=sc['scenario_id'];run_id=f'{sid}-T{trial:02d}';folder=O/'raw'/run_id
            assert not folder.exists();folder.mkdir();previous_state=None
            store=n.StateStore(str(B/'native-state.sqlite'));controller=n.CaptureController()
            service=n.RecommendationService(n.SnapshotListings(),n.SnapshotGeography(),store,controller,config=config)
            def execute(requirements,phase,version):
                req=n.RecommendationRequest(request_id=run_id+':'+phase+':20261024',conversation_id='G42-EXT40-'+run_id,
                    requirements_version=version,previous_state_id=previous_state,requirements=requirements,result_limit=10)
                dump(folder/(phase+'.request.json'),req.model_dump(mode='json'));start=audit_size()
                response=service.recommend(req);end=audit_size();dump(folder/(phase+'.response.json'),response.model_dump(mode='json'))
                raw=store.db.execute('SELECT content FROM traces WHERE conversation_id=? AND request_id=? ORDER BY rowid DESC LIMIT 1',
                    (req.conversation_id,req.request_id)).fetchone();trace=json.loads(raw[0]);n.gz(folder/(phase+'.trace.json.gz'),trace)
                gates=[x for x in trace['steps'] if x['kind']=='final_gate' and x.get('passed')]
                d=controller.dispatcher;capture=None
                if d is not None and d.scored is not None:
                    scored=d.scored;ordering=[{'rank':i,'listing_id':scored.ids[int(j)],'combined_score':float(scored.fused.combined[int(j)])}
                        for i,j in enumerate(scored.order,1)];n.gz(folder/(phase+'.full_score_order.json.gz'),ordering)
                    wanted=list(dict.fromkeys(list(d.selected or [])+scored.ranked[:10]));byid={r.listing_id:r for r in scored.rows}
                    capture={'selected_ids':list(d.selected or []),'full_eligible_count':len(scored.ranked),
                        'selection_input':d.selection_input,'native_score_top10':ordering[:10],
                        'listing_facts':{lid:byid[lid].model_dump(mode='json') for lid in wanted},
                        'scores':{lid:scored.breakdown(lid).model_dump(mode='json') for lid in wanted},
                        'criterion_results':{lid:[v.model_dump(mode='json') for v in d.results[lid]] for lid in wanted}}
                    n.gz(folder/(phase+'.selection_capture.json.gz'),capture)
                record={'scenario_id':sid,'run_id':run_id,'trial':trial,'phase':phase,'status':response.status,
                    'returned':len(response.recommendations),'returned_ids':[x.listing.listing_id for x in response.recommendations],
                    'model_calls':response.execution.model_calls,'tool_calls':response.execution.tool_calls,
                    'duration_ms':response.execution.duration_ms,'final_gate_passed':bool(gates),
                    'selection_mode':response.selection.mode if response.selection else None,
                    'error':response.error.model_dump(mode='json') if response.error else None,
                    'requirements_version':version,'previous_state_id':previous_state,
                    'request_id':req.request_id,'model_audit_byte_range':[start,end],
                    'evidence_dir':str(folder.relative_to(O))}
                if response.status!='error':
                    assert gates,'Non-error response did not pass final gate'
                    assert record['returned_ids']==(capture or {}).get('selected_ids',[])
                dump(folder/(phase+'.execution.json'),record);executions.append(record)
                print(json.dumps(record,ensure_ascii=False),flush=True);progress();return response,record
            try:
                if trial==1 and sc.get('initial_requirements'):
                    response,record=execute(sc['initial_requirements'],'initial',1)
                    if response.status!='error':previous_state=response.state.state_id
                    if (B/'paid-stop.json').exists():status='STOPPED_PROVIDER_OR_CAP';break
                response,record=execute(sc['requirements'],'evaluated',2 if previous_state else 1)
                finals.append({**record,'title':sc['title'],'analysis_group':sc['analysis_group'],
                    'expected_status':sc['expected_native_status'],'expected_eligible_count':sc['expected_eligible_count']})
                progress()
            finally:
                service.close();controller.dispatcher=None
                del service,controller,store;gc.collect()
        if len(finals)==28:status='COMPLETE'
    except BaseException as e:
        failure=type(e).__name__;status='STOPPED_UNHANDLED_EXCEPTION';raise
    finally:
        if private.exists():private.unlink()
        os.environ.pop('OPENAI_API_KEY',None);assert n.source_hashes()==before
        assert n.sha(Path(P['database']))==FREEZE['database_sha256']
        for name,d in FREEZE['artifact_sha256'].items():assert n.sha(O/'inputs'/name)==d
        progress();dump(O/'inputs/Source_And_Data_Final_Check_EN.json',{'status':'PASS','source_unchanged':True,
            'frozen_inputs_unchanged':True,'database_unchanged':True,'credential_file_removed':not private.exists()})
        dump(O/'Run_Manifest.json',{**registration,'status':status,'started_at_utc':started,'finished_at_utc':now(),
            'completed_main_scenarios':sum(r['trial']==1 for r in finals),'completed_repeat_runs':sum(r['trial']>1 for r in finals),
            'actual_native_requests':len(executions),'credential_file_removed':not private.exists(),
            'new_github_upload':False,'unhandled_exception_type':failure})
        if (B/'native-state.sqlite').exists():
            with (B/'native-state.sqlite').open('rb') as src:
                with (O/'raw/Native_State.sqlite.gz').open('wb') as raw:
                    with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as dest:shutil.copyfileobj(src,dest)
        print(json.dumps({'status':status,'main_scenarios':sum(r['trial']==1 for r in finals),
            'repeat_runs':sum(r['trial']>1 for r in finals),'credential_removed':not private.exists()}),flush=True)


if __name__=='__main__':main()
