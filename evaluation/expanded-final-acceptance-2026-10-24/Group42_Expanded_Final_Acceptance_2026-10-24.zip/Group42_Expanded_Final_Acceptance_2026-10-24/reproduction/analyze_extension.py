"""Recompute expanded metrics from saved native responses and frozen labels only."""
from pathlib import Path
from collections import Counter,defaultdict
from statistics import mean,pstdev
from itertools import combinations
from datetime import datetime,timezone
import csv,gzip,hashlib,json,math,shutil
from prepare_extension import grade,source_test

B=Path(__file__).resolve().parent;P=json.loads((B/'paths.json').read_text());O=Path(P['output']);OLD=Path(P['previous_output'])


def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def numeric(g):return type(g) is int and 0<=g<=3


def calculate(run,labels,primary,corpus_counts):
    sid=run['scenario_id'];ids=run['returned_ids'];rows=[]
    pool={lid:g for (s,lid),g in labels.items() if s==sid}
    relevant={lid for lid,g in pool.items() if numeric(g) and g>=2}
    ideal=sorted([g for g in pool.values() if numeric(g)],reverse=True)
    for k in range(1,11):
        selected=ids[:k];grades=[pool.get(lid,'U') for lid in selected]
        unknown=sum(not numeric(g) for g in grades);hits=sum(numeric(g) and g>=2 for g in grades)
        dcg=sum(((2**g)-1)/math.log2(i+2) for i,g in enumerate(grades) if numeric(g))
        idcg=sum(((2**g)-1)/math.log2(i+2) for i,g in enumerate(ideal[:k]))
        corpus=corpus_counts.get(sid)
        rows.append({'run_id':run['run_id'],'scenario_id':sid,'cohort':run['cohort'],'trial':run['trial'],
            'primary':sid in primary,'k':k,'returned':len(selected),'empty_slots':k-len(selected),
            'known_relevant_hits':hits,'unknown_returned':unknown,'relevant_pool_size':len(relevant),
            'precision':hits/k if not unknown else None,'precision_lower_bound':hits/k,
            'precision_upper_bound':(hits+unknown)/k,'judged_pool_recall':sum(lid in relevant for lid in selected)/len(relevant) if relevant else None,
            'dcg':dcg,'ideal_dcg':idcg,'ndcg':dcg/idcg if idcg and not unknown else None,
            'filled_slot_precision':hits/len(selected) if selected and not unknown else None,
            'full_corpus_relevant':corpus,'full_corpus_recall':hits/corpus if corpus and not unknown else None,
            'returned_ids':selected,'grades':grades})
    return rows


def aggregate(rows):
    result=[]
    for k in range(1,11):
        rr=[r for r in rows if r['k']==k];p=[r['precision'] for r in rr if r['precision'] is not None]
        rec=[r['judged_pool_recall'] for r in rr if r['judged_pool_recall'] is not None]
        nd=[r['ndcg'] for r in rr if r['ndcg'] is not None];filled=[r['filled_slot_precision'] for r in rr if r['filled_slot_precision'] is not None]
        full=[r['full_corpus_recall'] for r in rr if r['full_corpus_recall'] is not None]
        result.append({'k':k,'primary_scenarios':len(rr),'macro_precision':mean(p) if len(p)==len(rr) else None,
            'macro_precision_lower_bound':mean(r['precision_lower_bound'] for r in rr),
            'macro_precision_upper_bound':mean(r['precision_upper_bound'] for r in rr),
            'macro_pool_recall':mean(rec) if rec else None,'recall_scenarios':len(rec),
            'macro_ndcg':mean(nd) if len(nd)==len(rr) else None,'ndcg_scenarios':len(nd),
            'macro_filled_slot_precision':mean(filled) if len(filled)==len(rr) else None,
            'returned_positions':sum(r['returned'] for r in rr),'empty_slots':sum(r['empty_slots'] for r in rr),
            'relevant_hits':sum(r['known_relevant_hits'] for r in rr),'unknown_returned':sum(r['unknown_returned'] for r in rr),
            'macro_full_corpus_recall':mean(full) if full else None,'full_corpus_recall_scenarios':len(full)})
    return result


def main():
    run=load(O/'Run_Progress.json');assert run['status']=='COMPLETE',run['status']
    assert (run['completed_main_scenarios'],run['completed_repeat_runs'])==(20,8)
    sc_new=load(O/'inputs/Extension_Scenarios_EN.json')['scenarios'];sc_old=load(OLD/'inputs/Scenarios.json')['scenarios']
    scenarios={s['scenario_id']:dict(s,cohort='Retained') for s in sc_old}
    scenarios.update({s['scenario_id']:dict(s,cohort='Extension') for s in sc_new})
    source={r['listing_id']:r for r in load(O/'inputs/Source_Facts_EN.json')['listings']}
    corpus={};corpus_counts=Counter()
    with gzip.open(O/'inputs/Frozen_Corpus_Grades_EN.jsonl.gz','rt') as f:
        for line in f:
            sid,lid,g=json.loads(line);corpus[sid,lid]=g
            if numeric(g) and g>=2:corpus_counts[sid]+=1
    assert len(corpus)==428620
    labels={};rating_records=[]
    def add_rating(sid,lid,g,origin,note=''):
        assert (sid,lid) not in labels,(sid,lid)
        labels[sid,lid]=g;rating_records.append({'scenario_id':sid,'listing_id':lid,'grade':g,
            'origin':origin,'source_facts':source[lid],'rationale':note})
    for r in load(OLD/'inputs/Frozen_577_Ratings.json')['ratings']:
        add_rating(r['scenario_id'],str(r['listing_id']),r['ai_grade'],'Retained original 577',r.get('ai_rationale',''))
    for r in load(OLD/'inputs/Supplemental_Ratings_EN.json')['ratings']:
        add_rating(r['scenario_id'],str(r['listing_id']),r['grade'],'Retained supplemental 42',r.get('rationale',''))
    assert len(labels)==619
    frozen_new=load(O/'inputs/Frozen_Review_Pools_EN.json')['ratings']
    for r in frozen_new:
        sid,lid=r['scenario_id'],str(r['listing_id']);assert r['grade']==corpus[sid,lid]
        add_rating(sid,lid,r['grade'],'Extension pre-run 600','Pre-registered source-rubric-v1; grade applied before outputs.')
    frozen_labels=dict(labels)
    old_progress=load(OLD/'Run_Progress.json');all_runs=[];returned_rows=[];hard_checks=[];fact_checks=[];workflow_checks=[]
    for r in old_progress['scenarios']:
        sid=r['scenario_id'];all_runs.append(dict(r,run_id=sid+'-T01',trial=1,cohort='Retained',
            response_file=str(OLD/'raw'/sid/'evaluated.response.json'),
            request_file=str(OLD/'raw'/sid/'evaluated.request.json')))
    for r in run['final_runs']:
        all_runs.append(dict(r,cohort='Extension' if r['trial']==1 else 'Repeat',
            response_file=str(O/'raw'/r['run_id']/'evaluated.response.json'),
            request_file=str(O/'raw'/r['run_id']/'evaluated.request.json')))
    for r in all_runs:
        sid=r['scenario_id'];response=load(Path(r['response_file']));request=load(Path(r['request_file']))
        capture=Path(r['response_file']).with_name('evaluated.selection_capture.json.gz')
        if capture.exists():
            with gzip.open(capture,'rt') as f:captured=json.load(f)
            r['selection_seed_base']=(captured.get('selection_input') or {}).get('seeds',{}).get('base')
        ids=[str(x['listing']['listing_id']) for x in response['recommendations']]
        assert ids==r['returned_ids'] and len(ids)==len(set(ids)) and len(ids)<=10
        if r['cohort']!='Retained':
            sc=scenarios[sid]
            # Defaults added by the native contract do not alter the authored clauses.
            for authored,actual in zip(sc['requirements']['criteria'],request['requirements']['criteria']):
                for field,value in authored.items():assert actual[field]==value,(r['run_id'],field)
            assert len(sc['requirements']['criteria'])==len(request['requirements']['criteria'])
            workflow_checks.append({'run_id':r['run_id'],'check':'expected_status','passed':response['status']==sc['expected_native_status'],
                'expected':sc['expected_native_status'],'actual':response['status']})
            workflow_checks.append({'run_id':r['run_id'],'check':'expected_result_count','passed':len(ids)==min(10,sc['expected_eligible_count']),
                'expected':min(10,sc['expected_eligible_count']),'actual':len(ids)})
            if r['trial']==1 and sc.get('initial_requirements'):
                initial=load(O/'raw'/r['run_id']/'initial.response.json')
                workflow_checks.append({'run_id':r['run_id'],'check':'prior_native_state_referenced',
                    'passed':request['previous_state_id']==initial['state']['state_id'] and request['requirements_version']==2})
        for rank,item in enumerate(response['recommendations'],1):
            lid=str(item['listing']['listing_id']);facts=source[lid]
            if sid in {s['scenario_id'] for s in sc_new}:
                g=corpus[sid,lid];assert grade(facts,scenarios[sid])==g
                if (sid,lid) not in labels:
                    add_rating(sid,lid,g,'Extension pre-frozen corpus addition','Identity added to the common review pool after return; grade unchanged from the pre-run corpus freeze.')
                for c in scenarios[sid]['rubric']['hard']:
                    check={'run_id':r['run_id'],'scenario_id':sid,'listing_id':lid,'criterion':c,
                        'observed':facts[c['field']],'passed':source_test(facts,c) is True}
                    hard_checks.append(check)
                for field in ['price','bedrooms','floor_area_sqft','district_code','property_type','url']:
                    v=item['listing'][field];expected=facts[field]
                    match=v==expected or (v is None and expected is None)
                    fact_checks.append({'run_id':r['run_id'],'listing_id':lid,'field':field,'passed':match})
            g=labels.get((sid,lid),'U')
            returned_rows.append({'run_id':r['run_id'],'scenario_id':sid,'cohort':r['cohort'],'trial':r['trial'],
                'rank':rank,'listing_id':lid,'grade':g,'rating_key':sid+'|'+lid,'listing':item['listing'],
                'selection_mode':r['selection_mode']})
    assert all(x['passed'] for x in hard_checks),[x for x in hard_checks if not x['passed']]
    assert all(x['passed'] for x in fact_checks),[x for x in fact_checks if not x['passed']]
    # Status/count problems are outcomes, not reasons to erase a run.
    primary={sid for sid,s in scenarios.items() if s['analysis_group']=='primary'}
    assert len(primary)==36
    cases=[];frozen_cases=[]
    for r in all_runs:
        if r['scenario_id'] in primary:
            cases.extend(calculate(r,labels,primary,corpus_counts))
            if r['trial']==1 and r['cohort']=='Extension':
                frozen_cases.extend(calculate(r,frozen_labels,primary,corpus_counts))
    groups={}
    for name,cohort in [('combined',None),('retained','Retained'),('extension','Extension')]:
        rr=[r for r in cases if r['trial']==1 and (cohort is None or r['cohort']==cohort)]
        groups[name]={'scenario_count':40 if name=='combined' else 20,'primary_count':len({r['scenario_id'] for r in rr}),
            'aggregate':aggregate(rr),'per_scenario':rr}
    original=load(Path(P['previous_final'])/'metrics/Recommendation_Metrics_With_NDCG_EN.json')
    for a,old in zip(groups['retained']['aggregate'],original['current']['aggregate']):
        for f,g in [('macro_precision','macro_precision'),('macro_pool_recall','macro_judged_pool_recall'),('macro_ndcg','macro_ndcg')]:
            assert abs(a[f]-old[g])<1e-12,(f,a,old)
    repeats=[];repeat_details=[]
    for sid in ['S27','S29']:
        rr=[r for r in all_runs if r['scenario_id']==sid];assert len(rr)==5
        assert [r['trial'] for r in rr]==list(range(1,6))
        for k in [5,10]:
            cc=[r for r in cases if r['scenario_id']==sid and r['k']==k];assert len(cc)==5
            stats={}
            for f in ['precision','judged_pool_recall','ndcg']:
                v=[r[f] for r in cc]
                stats[f]={'mean':mean(v),'minimum':min(v),'maximum':max(v),'population_sd':pstdev(v)} if all(x is not None for x in v) else None
            sets=[set(r['returned_ids'][:k]) for r in rr];jac=[len(a&b)/len(a|b) if a|b else None for a,b in combinations(sets,2)]
            repeats.append({'scenario_id':sid,'k':k,'trials':5,'metrics':stats,
                'unique_returned_identities':len(set.union(*sets)),
                'mean_pairwise_jaccard':mean(x for x in jac if x is not None),
                'selection_modes':dict(Counter(r['selection_mode'] for r in rr))})
            for c in cc:
                sc=scenarios[sid];rows=[source[lid] for lid in c['returned_ids']]
                coverage=sum(all(source_test(row,x) is True for x in sc['rubric']['primary_preferences']) for row in rows)/k
                repeat_details.append({**c,'primary_preference_coverage':coverage,
                    'selection_mode':next(x['selection_mode'] for x in rr if x['run_id']==c['run_id'])})
    api=[json.loads(l) for l in (O/'raw/Model_API_Audit.jsonl').read_text().splitlines() if l]
    requests=[r for r in api if r['event']=='request'];terminal=[r for r in api if r['event']!='request']
    assert len(requests)==len(terminal)
    usage={'actual_http_requests':len(requests),'http_status_counts':dict(Counter(str(r['http_status']) for r in terminal if r['event']=='response')),
        'transport_errors':dict(Counter(r['error_type'] for r in terminal if r['event']=='transport_error')),
        'provider_reported_cost_usd':sum(float((r.get('usage') or {}).get('cost') or 0) for r in terminal),
        'calls_without_usage':sum(not r.get('usage') for r in terminal),
        'calls_without_cost':sum((r.get('usage') or {}).get('cost') is None for r in terminal),
        'returned_model_routes':sorted({r['returned_model'] for r in terminal if r.get('returned_model')}),
        'paid_relevance_judge_calls':0,'sdk_automatic_retries':0}
    main_runs=[r for r in all_runs if r['trial']==1]
    new_main=[r for r in main_runs if r['cohort']=='Extension']
    summary={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),'source_commit':P['commit'],
        'snapshot_date':'2026-10-09','total_basic_scenarios':40,'ranking_scenarios':36,
        'controls':[sid for sid,s in scenarios.items() if s['analysis_group']!='primary'],
        'retained_scenarios':20,'new_scenarios':20,'registered_extra_repeat_runs':8,
        'new_native_requests':len(run['service_executions']),'total_native_requests_in_evidence':22+len(run['service_executions']),
        'main_returned_positions':sum(r['returned'] for r in main_runs),
        'new_main_returned_positions':sum(r['returned'] for r in new_main),
        'repeat_returned_positions':sum(r['returned'] for r in all_runs if r['trial']>1),
        'main_final_statuses':dict(Counter(r['status'] for r in main_runs)),
        'new_main_final_statuses':dict(Counter(r['status'] for r in new_main)),
        'new_selection_modes':dict(Counter(r['selection_mode'] for r in new_main)),
        'new_final_gate_passes':sum(r['final_gate_passed'] for r in run['service_executions']),
        'new_expectation_checks_passed':sum(x['passed'] for x in workflow_checks),'new_expectation_checks':len(workflow_checks),
        'new_hard_source_comparisons':len(hard_checks),'new_hard_source_failures':sum(not r['passed'] for r in hard_checks),
        'new_returned_source_field_comparisons':len(fact_checks),'new_source_fact_failures':sum(not r['passed'] for r in fact_checks),
        'retained_rating_records':619,'new_pre_run_review_pairs':600,'new_pre_frozen_corpus_additions':len(labels)-1219,
        'combined_judged_pool_records':len(labels),'numeric_judged_pool_records':sum(numeric(g) for g in labels.values()),
        'U_judged_pool_records':sum(not numeric(g) for g in labels.values()),
        'precomputed_new_corpus_grade_rows':len(corpus),'new_corpus_grade_rows_are_not_independent_users':True,
        'all_current_returned_positions_have_numeric_grade':all(numeric(r['grade']) for r in returned_rows),
        'groups':groups,'extension_original_600_view':{'aggregate':aggregate(frozen_cases),'per_scenario':frozen_cases},
        'repeat_summary':repeats,'usage':usage,
        'provisional_labels':True,'independent_human_review_completed':False,
        'complex_suite_reused_without_new_execution':True,'overall_system_acceptance':'DEFERRED',
        'limitations':['Retained and extension cohorts use different documented label-construction methods.',
            'Pool Recall depends on the reviewed candidate identities and is not source-wide Recall.',
            'Pre-run corpus rule labels are exhaustive automatic applications of twenty rubrics, not 428,620 independent annotations.',
            'Unknown facts are not negative labels. No unsupported occupancy, lease, furnishing or availability claims are verified.',
            'The structured native requests do not exercise natural-language extraction, explanation or browser UAT.',
            'The complex suite remains on main plus a local timeout patch; it is not the same build as the structured suite.']}
    for name,data in [('Expanded_Metrics_Summary_EN.json',summary),('All_Ratings_EN.json',rating_records),
        ('All_Final_Runs_EN.json',all_runs),('Returned_Rankings_EN.json',returned_rows),('Case_Metrics_EN.json',cases),
        ('Repeat_Details_EN.json',repeat_details),('New_Source_Hard_Checks_EN.json',hard_checks),
        ('New_Source_Field_Checks_EN.json',fact_checks),('New_Workflow_Checks_EN.json',workflow_checks)]:dump(O/'metrics'/name,data)
    dump(O/'metrics/Combined_Scenario_Register_EN.json',list(scenarios.values()))
    added=[r for r in rating_records if r['origin']=='Extension pre-frozen corpus addition']
    dump(O/'inputs/Returned_Pool_Additions_EN.json',{'metadata':{'count':len(added),'grades_changed_after_outputs':0,
        'source':'Pre-run frozen corpus grades. Only pool membership is extended.'},'ratings':added})
    with (O/'metrics/Final_TopK_Metrics_EN.csv').open('w',newline='') as f:
        columns=['cohort','k','primary_scenarios','macro_precision','macro_pool_recall','macro_ndcg','recall_scenarios','ndcg_scenarios','returned_positions','empty_slots','unknown_returned']
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
        for name,g in groups.items():w.writerows({'cohort':name,**{k:a[k] for k in columns if k!='cohort'}} for a in g['aggregate'])
    for name in ['Execution_Summary.json','Case_Tracker_EN.json','Outcome_Interpretation_EN.json','Requirement_Timeout_Recovery_EN.json','Paired_Case_Comparison_EN.json','Model_Usage_Summary.json']:
        shutil.copyfile(Path(P['hard'])/'reports'/name,O/'evidence'/('Complex_'+name))
    shutil.copyfile(Path(P['hard'])/'inputs/Local_Timeout_Fix.patch',O/'evidence/Local_Timeout_Fix.patch')
    dump(O/'reports/Analysis_Check_EN.json',{'status':'PASS','original_619_metrics_unchanged':True,
        'new_original_corpus_grades_unchanged':True,'new_source_hard_comparisons_passed':len(hard_checks),
        'new_source_fields_passed':len(fact_checks),'case_k_rows':len(cases),
        'new_expectation_failures':[x for x in workflow_checks if not x['passed']],
        'model_calls_for_analysis':0})
    print(json.dumps({'analysis':'COMPLETE','judged_records':len(labels),'new_pool_additions':len(added),
        'main_cases':len(main_runs),'main_positions':summary['main_returned_positions'],
        'usage':usage,'combined':groups['combined']['aggregate'],'repeats':repeats},indent=2))


if __name__=='__main__':main()
