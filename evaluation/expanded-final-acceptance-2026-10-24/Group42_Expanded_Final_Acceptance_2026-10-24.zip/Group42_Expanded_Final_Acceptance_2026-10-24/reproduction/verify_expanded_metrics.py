#!/usr/bin/env python3
"""Independent, read-only metric replay. Requires only the Python standard library.

The saved script belongs in reproduction/ within the delivered report package.
It reconstructs native result order, checks frozen grading and source facts,
recalculates every scenario/K value and verifies both preserved source archives.
It never calls a model, accesses a credential or writes a file.
"""
from pathlib import Path
from collections import Counter,defaultdict
from statistics import mean,pstdev
from itertools import combinations
import gzip,hashlib,json,math,zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='reproduction' else Path(json.loads((HERE/'paths.json').read_text())['output'])
GAIN={0:0,1:1,2:3,3:7}


def load(path):return json.loads(path.read_text())
def numeric(x):return type(x) is int and x in GAIN
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def equal(x,y,label):
    assert (x is None and y is None) or (x is not None and y is not None and abs(x-y)<1e-12),(label,x,y)


def condition(row,c):
    x=row.get(c['field']);v=c['value']
    if x is None:return None
    if c['operator']=='lte':return x<=v
    if c['operator']=='gte':return x>=v
    if c['operator']=='eq':return x==v
    if c['operator']=='in':return x in v
    assert c['operator']=='between'
    return v[0]<=x<=v[1]


def rubric_grade(row,sc):
    outcomes=[[condition(row,c) for c in sc['rubric'][key]]
              for key in ['hard','primary_preferences','secondary_preferences']]
    for level,results in enumerate(outcomes):
        if any(x is False for x in results):return [0,1,2][level]
        if any(x is None for x in results):return 'U'
    return 3


def zip_json(z,suffix):
    name=[s for s in z.namelist() if s.endswith('/'+suffix)]
    assert len(name)==1,suffix
    return json.loads(z.read(name[0]))


def main():
    expected={
        'Group42_20_Scenario_Live_Main_2026-10-24.zip':'5cfe10eb150023076728d49ed09d068db30617f9cab6f7b16603cdd6280b4c70',
        'Group42_Blind_Evaluation_Timeout_Fixed_2026-10-24.zip':'75d8f7f973bdd5e96958c0f50431138cd9c86b269b24311c527dea73e5deedf9'}
    for name,h in expected.items():assert digest(ROOT/'evidence'/name)==h,name
    freeze=load(ROOT/'inputs/Extension_Freeze_EN.json')
    for name,h in freeze['artifact_sha256'].items():assert digest(ROOT/'inputs'/name)==h,name
    scenarios=load(ROOT/'inputs/Extension_Scenarios_EN.json')['scenarios'];new={s['scenario_id']:s for s in scenarios}
    facts={r['listing_id']:r for r in load(ROOT/'inputs/Source_Facts_EN.json')['listings']}
    assert len(facts)==21431
    corpus={};corpus_relevant=Counter()
    with gzip.open(ROOT/'inputs/Frozen_Corpus_Grades_EN.jsonl.gz','rt') as f:
        for line in f:
            sid,lid,g=json.loads(line)
            assert (sid,lid) not in corpus
            assert rubric_grade(facts[lid],new[sid])==g,(sid,lid,'rubric mismatch')
            corpus[sid,lid]=g
            if numeric(g) and g>=2:corpus_relevant[sid]+=1
    assert len(corpus)==428620
    with zipfile.ZipFile(ROOT/'evidence/Group42_20_Scenario_Live_Main_2026-10-24.zip') as z:
        frozen=zip_json(z,'inputs/Frozen_577_Ratings.json')['ratings']
        supplemental=zip_json(z,'inputs/Supplemental_Ratings_EN.json')['ratings']
        retained=zip_json(z,'inputs/Scenarios.json')['scenarios']
        old_summary=zip_json(z,'metrics/Metrics_Summary_EN.json')
        old_responses={s['scenario_id']:zip_json(z,'raw/'+s['scenario_id']+'/evaluated.response.json') for s in retained}
    assert len(frozen)==577 and len(supplemental)==42
    labels={(r['scenario_id'],str(r['listing_id'])):r['ai_grade'] for r in frozen}
    for r in supplemental:
        k=(r['scenario_id'],str(r['listing_id']));assert k not in labels;labels[k]=r['grade']
    assert len(labels)==619
    for r in load(ROOT/'inputs/Frozen_Review_Pools_EN.json')['ratings']:
        k=(r['scenario_id'],r['listing_id']);assert k not in labels and corpus[k]==r['grade'];labels[k]=r['grade']
    fixed=dict(labels)
    for r in load(ROOT/'inputs/Returned_Pool_Additions_EN.json')['ratings']:
        k=(r['scenario_id'],r['listing_id']);assert k not in labels and corpus[k]==r['grade'];labels[k]=r['grade']
    saved_labels={(r['scenario_id'],r['listing_id']):r['grade'] for r in load(ROOT/'metrics/All_Ratings_EN.json')}
    assert labels==saved_labels and len(labels)==1382
    native_run=load(ROOT/'Run_Progress.json');assert native_run['status']=='COMPLETE'
    assert len(native_run['service_executions'])==32 and len(native_run['final_runs'])==28
    primary={s['scenario_id'] for s in retained+scenarios if s['analysis_group']=='primary'}
    assert len(primary)==36
    runs=[];source_fields_checked=0;hard_checked=0
    for sid,response in old_responses.items():
        runs.append({'scenario_id':sid,'run_id':sid+'-T01','cohort':'Retained','trial':1,
                     'ids':[str(r['listing']['listing_id']) for r in response['recommendations']]})
    for r in native_run['final_runs']:
        sid=r['scenario_id'];response=load(ROOT/'raw'/r['run_id']/'evaluated.response.json')
        ids=[str(x['listing']['listing_id']) for x in response['recommendations']]
        assert ids==r['returned_ids'] and len(set(ids))==len(ids)
        for item in response['recommendations']:
            row=facts[str(item['listing']['listing_id'])]
            for field in ['price','bedrooms','floor_area_sqft','district_code','property_type','url']:
                assert row[field]==item['listing'][field],(r['run_id'],field);source_fields_checked+=1
            for c in new[sid]['rubric']['hard']:
                assert condition(row,c) is True,(r['run_id'],c);hard_checked+=1
        runs.append({'scenario_id':sid,'run_id':r['run_id'],'cohort':'Extension' if r['trial']==1 else 'Repeat',
                     'trial':r['trial'],'ids':ids})
    cases={(r['run_id'],r['k']):r for r in load(ROOT/'metrics/Case_Metrics_EN.json')}
    assert len(cases)==440
    recomputed=[]
    for run in runs:
        sid=run['scenario_id']
        if sid not in primary:continue
        pool={lid:g for (s,lid),g in labels.items() if s==sid}
        histogram=Counter(g for g in pool.values() if numeric(g));rel=histogram[2]+histogram[3]
        ideal=[g for g in [3,2,1,0] for _ in range(histogram[g])]
        for k in range(1,11):
            selected=run['ids'][:k];grades=[pool.get(lid,'U') for lid in selected];assert all(numeric(g) for g in grades)
            hit=sum(g>=2 for g in grades)
            dcg=sum(GAIN[g]/math.log2(i+2) for i,g in enumerate(grades))
            ideal_dcg=sum(GAIN[g]/math.log2(i+2) for i,g in enumerate(ideal[:k]))
            values={'precision':hit/k,'judged_pool_recall':hit/rel if rel else None,
                    'dcg':dcg,'ideal_dcg':ideal_dcg,'ndcg':dcg/ideal_dcg if ideal_dcg else None,
                    'filled_slot_precision':hit/len(selected) if selected else None,
                    'full_corpus_recall':hit/corpus_relevant[sid] if corpus_relevant[sid] else None}
            record=cases[run['run_id'],k]
            for f,x in values.items():equal(record[f],x,(run['run_id'],k,f))
            assert record['returned_ids']==selected and record['grades']==grades
            assert record['relevant_pool_size']==rel and record['known_relevant_hits']==hit
            recomputed.append({**run,'k':k,**values})
    summary=load(ROOT/'metrics/Expanded_Metrics_Summary_EN.json');macro_count=0
    for group,cohort in [('combined',None),('retained','Retained'),('extension','Extension')]:
        for k in range(1,11):
            rr=[r for r in recomputed if r['k']==k and r['trial']==1 and (cohort is None or r['cohort']==cohort)]
            target=summary['groups'][group]['aggregate'][k-1]
            for f,out in [('precision','macro_precision'),('judged_pool_recall','macro_pool_recall'),('ndcg','macro_ndcg')]:
                values=[r[f] for r in rr if r[f] is not None]
                equal(target[out],mean(values),(group,k,out));macro_count+=1
            if group=='retained':
                for f,out in [('macro_precision','macro_precision'),('macro_pool_recall','macro_judged_pool_recall')]:
                    equal(target[f],old_summary['evaluation']['aggregate'][k-1][out],('retained unchanged',k,f))
    assert summary['controls']==['S19','S20','S34','S36']
    for saved in summary['repeat_summary']:
        sid,k=saved['scenario_id'],saved['k'];rr=[r for r in recomputed if r['scenario_id']==sid and r['k']==k];assert len(rr)==5
        for f in ['precision','judged_pool_recall','ndcg']:
            values=[r[f] for r in rr]
            for key,x in [('mean',mean(values)),('minimum',min(values)),('maximum',max(values)),('population_sd',pstdev(values))]:
                equal(saved['metrics'][f][key],x,(sid,k,f,key))
        sets=[set(r['ids'][:k]) for r in rr]
        equal(saved['mean_pairwise_jaccard'],mean(len(a&b)/len(a|b) for a,b in combinations(sets,2)),(sid,k,'Jaccard'))
        assert saved['unique_returned_identities']==len(set.union(*sets))
    assert source_fields_checked==1470 and hard_checked==677
    return {'status':'PASS','archives_sha256_verified':2,'frozen_input_hashes_verified':len(freeze['artifact_sha256']),
            'corpus_rule_grades_recomputed':len(corpus),'combined_pool_records':len(labels),
            'scenario_k_rows_verified':len(cases),'macro_metric_values_verified':macro_count,
            'repeat_summary_rows_verified':len(summary['repeat_summary']),
            'new_source_field_comparisons_verified':source_fields_checked,
            'new_hard_conditions_verified':hard_checked,'model_calls':0,'file_writes':0}


if __name__=='__main__':print(json.dumps(main(),indent=2))
